package com.example.dmnperf.dmn;

public record DmnMetadata(
        String resource,
        String decisionKey,
        int ruleCount,
        int inputColumnCount,
        long fileSizeBytes,
        double parseMilliseconds) {
}
