package com.example.dmnperf.benchmark;

import com.example.dmnperf.dmn.DmnMetadata;

import java.time.Instant;
import java.util.List;

public record BenchmarkResponse(
        Instant startedAt,
        int transactionsLoaded,
        double databaseReadMilliseconds,
        int warmupIterations,
        int measuredIterations,
        DmnMetadata dmn,
        List<ModeResult> results,
        String benchmarkWarning) {
}
