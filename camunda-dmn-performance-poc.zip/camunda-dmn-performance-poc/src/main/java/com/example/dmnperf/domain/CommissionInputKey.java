package com.example.dmnperf.domain;

public record CommissionInputKey(
        String insuranceType,
        String coverageType,
        String stateCode,
        String registrationCode,
        String productCode,
        String agentCategory,
        String channel,
        String customerSegment,
        String policyTerm,
        String riskBand,
        String premiumBand,
        String vehicleClass) {
}
