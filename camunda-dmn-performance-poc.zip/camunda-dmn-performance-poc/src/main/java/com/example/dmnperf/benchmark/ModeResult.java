package com.example.dmnperf.benchmark;

import java.util.List;

public record ModeResult(
        BenchmarkMode mode,
        List<IterationResult> iterations,
        double minMilliseconds,
        double medianMilliseconds,
        double maxMilliseconds,
        double averageTransactionsPerSecond) {
}
