package com.example.dmnperf.domain;

import java.math.BigDecimal;

public record CommissionRuleResult(
        String ruleCode,
        BigDecimal commissionPercentage) {
}
