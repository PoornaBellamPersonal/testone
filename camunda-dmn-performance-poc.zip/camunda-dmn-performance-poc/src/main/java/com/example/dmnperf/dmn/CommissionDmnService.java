package com.example.dmnperf.dmn;

import com.example.dmnperf.domain.CommissionRuleResult;
import com.example.dmnperf.domain.CommissionTransaction;
import org.camunda.bpm.dmn.engine.DmnDecision;
import org.camunda.bpm.dmn.engine.DmnDecisionResult;
import org.camunda.bpm.dmn.engine.DmnDecisionResultEntries;
import org.camunda.bpm.dmn.engine.DmnEngine;
import org.camunda.bpm.dmn.engine.DmnEngineConfiguration;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

@Service
public class CommissionDmnService {

    private final DmnEngine dmnEngine;
    private final DmnDecision decision;
    private final DmnMetadata metadata;

    public CommissionDmnService(
            ResourceLoader resourceLoader,
            @Value("${app.dmn.resource:classpath:dmn/commission-performance.dmn}") String dmnResource,
            @Value("${app.dmn.decision-key:commissionDecision}") String decisionKey,
            @Value("${app.dmn.rule-count:2000}") int ruleCount,
            @Value("${app.dmn.input-column-count:12}") int inputColumnCount) throws IOException {

        Resource resource = resourceLoader.getResource(dmnResource);
        if (!resource.exists()) {
            throw new IllegalStateException("DMN resource does not exist: " + dmnResource);
        }

        byte[] dmnBytes;
        try (var inputStream = resource.getInputStream()) {
            dmnBytes = inputStream.readAllBytes();
        }

        this.dmnEngine = DmnEngineConfiguration
                .createDefaultDmnEngineConfiguration()
                .buildEngine();

        long startNanos = System.nanoTime();
        this.decision = dmnEngine.parseDecision(
                decisionKey,
                new ByteArrayInputStream(dmnBytes)
        );
        long parseNanos = System.nanoTime() - startNanos;

        this.metadata = new DmnMetadata(
                dmnResource,
                decisionKey,
                ruleCount,
                inputColumnCount,
                dmnBytes.length,
                parseNanos / 1_000_000.0
        );
    }

    public CommissionRuleResult evaluate(CommissionTransaction transaction) {
        Map<String, Object> variables = new HashMap<>(16);
        variables.put("insuranceType", transaction.insuranceType());
        variables.put("coverageType", transaction.coverageType());
        variables.put("stateCode", transaction.stateCode());
        variables.put("registrationCode", transaction.registrationCode());
        variables.put("productCode", transaction.productCode());
        variables.put("agentCategory", transaction.agentCategory());
        variables.put("channel", transaction.channel());
        variables.put("customerSegment", transaction.customerSegment());
        variables.put("policyTerm", transaction.policyTerm());
        variables.put("riskBand", transaction.riskBand());
        variables.put("premiumBand", transaction.premiumBand());
        variables.put("vehicleClass", transaction.vehicleClass());

        DmnDecisionResult result = dmnEngine.evaluateDecision(decision, variables);
        if (result.isEmpty()) {
            throw new IllegalStateException(
                    "No DMN rule matched transaction " + transaction.externalId());
        }

        DmnDecisionResultEntries entries = result.getSingleResult();
        String ruleCode = Objects.toString(entries.get("ruleCode"), null);
        Object percentageValue = entries.get("commissionPercentage");

        if (ruleCode == null || percentageValue == null) {
            throw new IllegalStateException(
                    "DMN output is incomplete for transaction " + transaction.externalId());
        }

        return new CommissionRuleResult(
                ruleCode,
                new BigDecimal(percentageValue.toString())
        );
    }

    public DmnMetadata metadata() {
        return metadata;
    }
}
