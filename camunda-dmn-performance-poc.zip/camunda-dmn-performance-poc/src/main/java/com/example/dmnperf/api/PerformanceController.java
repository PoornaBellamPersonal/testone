package com.example.dmnperf.api;

import com.example.dmnperf.benchmark.BenchmarkRequest;
import com.example.dmnperf.benchmark.BenchmarkResponse;
import com.example.dmnperf.benchmark.BenchmarkService;
import com.example.dmnperf.data.CommissionTransactionRepository;
import com.example.dmnperf.data.DataSeeder;
import com.example.dmnperf.dmn.CommissionDmnService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class PerformanceController {

    private final CommissionTransactionRepository repository;
    private final CommissionDmnService dmnService;
    private final BenchmarkService benchmarkService;
    private final DataSeeder dataSeeder;
    private final String databaseUrl;

    public PerformanceController(
            CommissionTransactionRepository repository,
            CommissionDmnService dmnService,
            BenchmarkService benchmarkService,
            DataSeeder dataSeeder,
            @Value("${spring.datasource.url}") String databaseUrl) {
        this.repository = repository;
        this.dmnService = dmnService;
        this.benchmarkService = benchmarkService;
        this.dataSeeder = dataSeeder;
        this.databaseUrl = databaseUrl;
    }

    @GetMapping("/status")
    public StatusResponse status() {
        return new StatusResponse(
                repository.count(),
                dmnService.metadata(),
                databaseUrl,
                "http://localhost:8080/",
                "http://localhost:8080/h2-console"
        );
    }

    @PostMapping("/benchmark/run")
    public BenchmarkResponse runBenchmark(
            @RequestBody(required = false) BenchmarkRequest request) {
        int available = Math.toIntExact(repository.count());
        return benchmarkService.run(request, available);
    }

    @PostMapping("/data/reseed")
    @ResponseStatus(HttpStatus.CREATED)
    public DataSeeder.SeedSummary reseed() {
        return dataSeeder.reseed();
    }
}
