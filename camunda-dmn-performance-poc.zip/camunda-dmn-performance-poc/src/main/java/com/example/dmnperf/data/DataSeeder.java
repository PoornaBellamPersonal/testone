package com.example.dmnperf.data;

import com.example.dmnperf.rules.RuleCatalog;
import com.example.dmnperf.rules.RuleProfile;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@Component
public class DataSeeder implements ApplicationRunner {

    private static final String INSERT_SQL = """
            insert into commission_transaction (
                external_id,
                agent_id,
                insurance_type,
                coverage_type,
                state_code,
                registration_code,
                product_code,
                agent_category,
                channel,
                customer_segment,
                policy_term,
                risk_band,
                premium_band,
                vehicle_class,
                commissionable_amount,
                expected_rule_code,
                expected_rate
            ) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """;

    private final JdbcTemplate jdbcTemplate;
    private final CommissionTransactionRepository repository;
    private final int transactionCount;
    private final int ruleCount;
    private final long randomSeed;

    public DataSeeder(
            JdbcTemplate jdbcTemplate,
            CommissionTransactionRepository repository,
            @Value("${app.seed.transaction-count:5000}") int transactionCount,
            @Value("${app.dmn.rule-count:2000}") int ruleCount,
            @Value("${app.seed.random-seed:20260731}") long randomSeed) {
        this.jdbcTemplate = jdbcTemplate;
        this.repository = repository;
        this.transactionCount = transactionCount;
        this.ruleCount = ruleCount;
        this.randomSeed = randomSeed;
    }

    @Override
    public void run(ApplicationArguments args) {
        if (repository.count() == 0) {
            reseed();
        }
    }

    @Transactional
    public SeedSummary reseed() {
        RuleCatalog.validateUnique(ruleCount);
        jdbcTemplate.update("delete from commission_transaction");
        jdbcTemplate.execute("alter table commission_transaction alter column id restart with 1");

        Random random = new Random(randomSeed);
        List<SeedRow> rows = new ArrayList<>(transactionCount);

        for (int i = 0; i < transactionCount; i++) {
            int ruleIndex = random.nextInt(ruleCount);
            RuleProfile profile = RuleCatalog.profile(ruleIndex);

            String externalId = "TX-%05d".formatted(i + 1);
            String agentId = "AGENT-%04d".formatted(1 + random.nextInt(500));

            long amountCents = 10_000L + random.nextLong(990_001L);
            BigDecimal amount = BigDecimal.valueOf(amountCents, 2);

            rows.add(new SeedRow(externalId, agentId, profile, amount));
        }

        jdbcTemplate.batchUpdate(
                INSERT_SQL,
                rows,
                500,
                (PreparedStatement ps, SeedRow row) -> {
                    RuleProfile p = row.profile();
                    ps.setString(1, row.externalId());
                    ps.setString(2, row.agentId());
                    ps.setString(3, p.insuranceType());
                    ps.setString(4, p.coverageType());
                    ps.setString(5, p.stateCode());
                    ps.setString(6, p.registrationCode());
                    ps.setString(7, p.productCode());
                    ps.setString(8, p.agentCategory());
                    ps.setString(9, p.channel());
                    ps.setString(10, p.customerSegment());
                    ps.setString(11, p.policyTerm());
                    ps.setString(12, p.riskBand());
                    ps.setString(13, p.premiumBand());
                    ps.setString(14, p.vehicleClass());
                    ps.setBigDecimal(15, row.amount());
                    ps.setString(16, p.ruleCode());
                    ps.setBigDecimal(17, p.commissionPercentage());
                }
        );

        return new SeedSummary(
                repository.count(),
                ruleCount,
                randomSeed
        );
    }

    private record SeedRow(
            String externalId,
            String agentId,
            RuleProfile profile,
            BigDecimal amount) {
    }

    public record SeedSummary(
            long transactionCount,
            int ruleCount,
            long randomSeed) {
    }
}
