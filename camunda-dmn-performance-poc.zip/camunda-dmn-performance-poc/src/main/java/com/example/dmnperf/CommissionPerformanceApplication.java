package com.example.dmnperf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CommissionPerformanceApplication {

    public static void main(String[] args) {
        SpringApplication.run(CommissionPerformanceApplication.class, args);
    }
}
