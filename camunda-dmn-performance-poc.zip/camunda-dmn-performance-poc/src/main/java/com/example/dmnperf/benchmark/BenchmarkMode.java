package com.example.dmnperf.benchmark;

public enum BenchmarkMode {
    NO_CACHE,
    INPUT_CACHE,
    BOTH
}
