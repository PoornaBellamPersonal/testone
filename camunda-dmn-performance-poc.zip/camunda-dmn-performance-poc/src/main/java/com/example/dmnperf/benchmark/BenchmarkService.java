package com.example.dmnperf.benchmark;

import com.example.dmnperf.data.CommissionTransactionRepository;
import com.example.dmnperf.dmn.CommissionDmnService;
import com.example.dmnperf.domain.CommissionInputKey;
import com.example.dmnperf.domain.CommissionRuleResult;
import com.example.dmnperf.domain.CommissionTransaction;
import org.springframework.stereotype.Service;

import java.lang.management.GarbageCollectorMXBean;
import java.lang.management.ManagementFactory;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class BenchmarkService {

    private final CommissionTransactionRepository repository;
    private final CommissionDmnService dmnService;

    public BenchmarkService(
            CommissionTransactionRepository repository,
            CommissionDmnService dmnService) {
        this.repository = repository;
        this.dmnService = dmnService;
    }

    public BenchmarkResponse run(BenchmarkRequest request, int availableTransactions) {
        Instant startedAt = Instant.now();

        BenchmarkRequest safeRequest = request == null
                ? new BenchmarkRequest(null, null, null, null)
                : request;

        int limit = safeRequest.normalizedTransactionLimit(availableTransactions);
        int warmups = safeRequest.normalizedWarmupIterations();
        int measured = safeRequest.normalizedMeasuredIterations();
        BenchmarkMode requestedMode = safeRequest.normalizedMode();

        long readStart = System.nanoTime();
        List<CommissionTransaction> transactions = repository.findAll(limit);
        double databaseReadMs = nanosToMillis(System.nanoTime() - readStart);

        EnumSet<BenchmarkMode> modes = requestedMode == BenchmarkMode.BOTH
                ? EnumSet.of(BenchmarkMode.NO_CACHE, BenchmarkMode.INPUT_CACHE)
                : EnumSet.of(requestedMode);

        List<ModeResult> modeResults = new ArrayList<>();
        for (BenchmarkMode mode : modes) {
            for (int i = 0; i < warmups; i++) {
                execute(transactions, mode, 0);
            }

            List<IterationResult> iterations = new ArrayList<>(measured);
            for (int i = 1; i <= measured; i++) {
                iterations.add(execute(transactions, mode, i));
            }
            modeResults.add(summarize(mode, iterations));
        }

        return new BenchmarkResponse(
                startedAt,
                transactions.size(),
                databaseReadMs,
                warmups,
                measured,
                dmnService.metadata(),
                List.copyOf(modeResults),
                "This is an application-level throughput test, not a JMH microbenchmark. " +
                        "Run multiple times with a fixed JVM heap and no other workload."
        );
    }

    private IterationResult execute(
            List<CommissionTransaction> transactions,
            BenchmarkMode mode,
            int iteration) {

        Map<CommissionInputKey, CommissionRuleResult> cache =
                mode == BenchmarkMode.INPUT_CACHE ? new HashMap<>() : Map.of();

        long heapBefore = usedHeap();
        GcSnapshot gcBefore = gcSnapshot();
        long startNanos = System.nanoTime();

        long evaluations = 0;
        long cacheHits = 0;
        long mismatches = 0;
        BigDecimal totalCommission = BigDecimal.ZERO;

        for (CommissionTransaction transaction : transactions) {
            CommissionRuleResult result;

            if (mode == BenchmarkMode.INPUT_CACHE) {
                CommissionInputKey key = transaction.inputKey();
                result = cache.get(key);
                if (result == null) {
                    result = dmnService.evaluate(transaction);
                    cache.put(key, result);
                    evaluations++;
                } else {
                    cacheHits++;
                }
            } else {
                result = dmnService.evaluate(transaction);
                evaluations++;
            }

            if (!transaction.expectedRuleCode().equals(result.ruleCode())
                    || transaction.expectedRate().compareTo(result.commissionPercentage()) != 0) {
                mismatches++;
            }

            BigDecimal commission = transaction.commissionableAmount()
                    .multiply(result.commissionPercentage())
                    .divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);

            totalCommission = totalCommission.add(commission);
        }

        long elapsedNanos = System.nanoTime() - startNanos;
        GcSnapshot gcAfter = gcSnapshot();
        long heapAfter = usedHeap();

        double elapsedMs = nanosToMillis(elapsedNanos);
        double throughput = transactions.isEmpty()
                ? 0.0
                : transactions.size() / (elapsedNanos / 1_000_000_000.0);
        double averageMicros = transactions.isEmpty()
                ? 0.0
                : elapsedNanos / 1_000.0 / transactions.size();

        return new IterationResult(
                iteration,
                transactions.size(),
                evaluations,
                cacheHits,
                evaluations,
                mismatches,
                elapsedMs,
                throughput,
                averageMicros,
                heapAfter - heapBefore,
                gcAfter.collections() - gcBefore.collections(),
                gcAfter.timeMilliseconds() - gcBefore.timeMilliseconds(),
                totalCommission
        );
    }

    private ModeResult summarize(
            BenchmarkMode mode,
            List<IterationResult> iterations) {

        List<Double> elapsed = iterations.stream()
                .map(IterationResult::elapsedMilliseconds)
                .sorted()
                .toList();

        double median;
        int size = elapsed.size();
        if (size % 2 == 0) {
            median = (elapsed.get(size / 2 - 1) + elapsed.get(size / 2)) / 2.0;
        } else {
            median = elapsed.get(size / 2);
        }

        double averageThroughput = iterations.stream()
                .mapToDouble(IterationResult::transactionsPerSecond)
                .average()
                .orElse(0.0);

        return new ModeResult(
                mode,
                Collections.unmodifiableList(iterations),
                elapsed.get(0),
                median,
                elapsed.get(elapsed.size() - 1),
                averageThroughput
        );
    }

    private static long usedHeap() {
        Runtime runtime = Runtime.getRuntime();
        return runtime.totalMemory() - runtime.freeMemory();
    }

    private static GcSnapshot gcSnapshot() {
        long collections = 0;
        long time = 0;

        for (GarbageCollectorMXBean bean :
                ManagementFactory.getGarbageCollectorMXBeans()) {
            if (bean.getCollectionCount() >= 0) {
                collections += bean.getCollectionCount();
            }
            if (bean.getCollectionTime() >= 0) {
                time += bean.getCollectionTime();
            }
        }

        return new GcSnapshot(collections, time);
    }

    private static double nanosToMillis(long nanos) {
        return nanos / 1_000_000.0;
    }

    private record GcSnapshot(long collections, long timeMilliseconds) {
    }
}
