package com.example.dmnperf.benchmark;

import java.math.BigDecimal;

public record IterationResult(
        int iteration,
        long transactionsProcessed,
        long dmnEvaluations,
        long cacheHits,
        long cacheMisses,
        long mismatches,
        double elapsedMilliseconds,
        double transactionsPerSecond,
        double averageMicrosecondsPerTransaction,
        long heapDeltaBytes,
        long gcCollectionDelta,
        long gcTimeDeltaMilliseconds,
        BigDecimal totalCommission) {
}
