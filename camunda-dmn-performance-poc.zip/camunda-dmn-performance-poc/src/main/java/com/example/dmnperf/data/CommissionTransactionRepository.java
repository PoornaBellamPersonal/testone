package com.example.dmnperf.data;

import com.example.dmnperf.domain.CommissionTransaction;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class CommissionTransactionRepository {

    private static final String SELECT_COLUMNS = """
            id,
            external_id,
            agent_id,
            insurance_type,
            coverage_type,
            state_code,
            registration_code,
            product_code,
            agent_category,
            channel,
            customer_segment,
            policy_term,
            risk_band,
            premium_band,
            vehicle_class,
            commissionable_amount,
            expected_rule_code,
            expected_rate
            """;

    private final JdbcTemplate jdbcTemplate;

    public CommissionTransactionRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public long count() {
        Long value = jdbcTemplate.queryForObject(
                "select count(*) from commission_transaction",
                Long.class
        );
        return value == null ? 0L : value;
    }

    public List<CommissionTransaction> findAll(int limit) {
        return jdbcTemplate.query(
                "select " + SELECT_COLUMNS +
                        " from commission_transaction order by id fetch first ? rows only",
                (rs, rowNum) -> new CommissionTransaction(
                        rs.getLong("id"),
                        rs.getString("external_id"),
                        rs.getString("agent_id"),
                        rs.getString("insurance_type"),
                        rs.getString("coverage_type"),
                        rs.getString("state_code"),
                        rs.getString("registration_code"),
                        rs.getString("product_code"),
                        rs.getString("agent_category"),
                        rs.getString("channel"),
                        rs.getString("customer_segment"),
                        rs.getString("policy_term"),
                        rs.getString("risk_band"),
                        rs.getString("premium_band"),
                        rs.getString("vehicle_class"),
                        rs.getBigDecimal("commissionable_amount"),
                        rs.getString("expected_rule_code"),
                        rs.getBigDecimal("expected_rate")
                ),
                limit
        );
    }
}
