package com.example.dmnperf.benchmark;

public record BenchmarkRequest(
        BenchmarkMode mode,
        Integer transactionLimit,
        Integer warmupIterations,
        Integer measuredIterations) {

    public BenchmarkMode normalizedMode() {
        return mode == null ? BenchmarkMode.BOTH : mode;
    }

    public int normalizedTransactionLimit(int available) {
        int value = transactionLimit == null ? available : transactionLimit;
        if (value < 1 || value > available) {
            throw new IllegalArgumentException(
                    "transactionLimit must be between 1 and " + available);
        }
        return value;
    }

    public int normalizedWarmupIterations() {
        int value = warmupIterations == null ? 1 : warmupIterations;
        if (value < 0 || value > 10) {
            throw new IllegalArgumentException(
                    "warmupIterations must be between 0 and 10");
        }
        return value;
    }

    public int normalizedMeasuredIterations() {
        int value = measuredIterations == null ? 3 : measuredIterations;
        if (value < 1 || value > 20) {
            throw new IllegalArgumentException(
                    "measuredIterations must be between 1 and 20");
        }
        return value;
    }
}
