package com.example.dmnperf.api;

import com.example.dmnperf.dmn.DmnMetadata;

public record StatusResponse(
        long transactionCount,
        DmnMetadata dmn,
        String databaseUrl,
        String dashboardUrl,
        String h2ConsoleUrl) {
}
