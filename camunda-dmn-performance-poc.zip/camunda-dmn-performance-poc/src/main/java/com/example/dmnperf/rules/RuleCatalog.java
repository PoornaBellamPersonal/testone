package com.example.dmnperf.rules;

import java.math.BigDecimal;
import java.util.LinkedHashSet;
import java.util.Set;

/**
 * Generates deterministic binary combinations for the 12 DMN input columns.
 *
 * 12 binary dimensions provide 4,096 unique combinations. The POC uses the
 * first 2,000 combinations. Each column varies across the rules, and every
 * generated rule is unique.
 */
public final class RuleCatalog {

    public static final int INPUT_COLUMN_COUNT = 12;
    public static final int MAX_UNIQUE_COMBINATIONS = 1 << INPUT_COLUMN_COUNT;

    private static final String[][] VALUES = {
            {"VEHICLE", "HEALTH"},
            {"OWN_DAMAGE", "THIRD_PARTY"},
            {"AP", "AS"},
            {"23", "42"},
            {"PROD_A", "PROD_B"},
            {"STANDARD", "ELITE"},
            {"ONLINE", "BRANCH"},
            {"RETAIL", "SME"},
            {"ANNUAL", "SHORT_TERM"},
            {"LOW", "HIGH"},
            {"LOW", "HIGH"},
            {"PRIVATE", "COMMERCIAL"}
    };

    private RuleCatalog() {
    }

    public static RuleProfile profile(int ruleIndex) {
        if (ruleIndex < 0 || ruleIndex >= MAX_UNIQUE_COMBINATIONS) {
            throw new IllegalArgumentException(
                    "ruleIndex must be between 0 and " + (MAX_UNIQUE_COMBINATIONS - 1));
        }

        String[] values = new String[INPUT_COLUMN_COUNT];
        for (int bit = 0; bit < INPUT_COLUMN_COUNT; bit++) {
            values[bit] = VALUES[bit][(ruleIndex >>> bit) & 1];
        }

        BigDecimal rate = BigDecimal.valueOf(25L + (ruleIndex % 16) * 5L, 1);
        String ruleCode = "COMM-%04d".formatted(ruleIndex + 1);

        return new RuleProfile(
                ruleIndex,
                values[0],
                values[1],
                values[2],
                values[3],
                values[4],
                values[5],
                values[6],
                values[7],
                values[8],
                values[9],
                values[10],
                values[11],
                ruleCode,
                rate
        );
    }

    public static void validateUnique(int ruleCount) {
        if (ruleCount < 1 || ruleCount > MAX_UNIQUE_COMBINATIONS) {
            throw new IllegalArgumentException(
                    "ruleCount must be between 1 and " + MAX_UNIQUE_COMBINATIONS);
        }

        Set<String> combinations = new LinkedHashSet<>();
        for (int i = 0; i < ruleCount; i++) {
            RuleProfile p = profile(i);
            String key = String.join("|",
                    p.insuranceType(),
                    p.coverageType(),
                    p.stateCode(),
                    p.registrationCode(),
                    p.productCode(),
                    p.agentCategory(),
                    p.channel(),
                    p.customerSegment(),
                    p.policyTerm(),
                    p.riskBand(),
                    p.premiumBand(),
                    p.vehicleClass()
            );
            if (!combinations.add(key)) {
                throw new IllegalStateException("Duplicate rule combination at index " + i);
            }
        }
    }
}
