package com.example.dmnperf.rules;

import java.math.BigDecimal;

public record RuleProfile(
        int ruleIndex,
        String insuranceType,
        String coverageType,
        String stateCode,
        String registrationCode,
        String productCode,
        String agentCategory,
        String channel,
        String customerSegment,
        String policyTerm,
        String riskBand,
        String premiumBand,
        String vehicleClass,
        String ruleCode,
        BigDecimal commissionPercentage) {
}
