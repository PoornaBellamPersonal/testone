package com.example.dmnperf.domain;

import java.math.BigDecimal;

public record CommissionTransaction(
        long id,
        String externalId,
        String agentId,
        String insuranceType,
        String coverageType,
        String stateCode,
        String registrationCode,
        String productCode,
        String agentCategory,
        String channel,
        String customerSegment,
        String policyTerm,
        String riskBand,
        String premiumBand,
        String vehicleClass,
        BigDecimal commissionableAmount,
        String expectedRuleCode,
        BigDecimal expectedRate) {

    public CommissionInputKey inputKey() {
        return new CommissionInputKey(
                insuranceType,
                coverageType,
                stateCode,
                registrationCode,
                productCode,
                agentCategory,
                channel,
                customerSegment,
                policyTerm,
                riskBand,
                premiumBand,
                vehicleClass
        );
    }
}
