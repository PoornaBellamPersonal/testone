package com.example.dmnperf.dmn;

import com.example.dmnperf.rules.RuleCatalog;
import com.example.dmnperf.rules.RuleProfile;
import org.camunda.bpm.dmn.engine.DmnDecision;
import org.camunda.bpm.dmn.engine.DmnDecisionResult;
import org.camunda.bpm.dmn.engine.DmnEngine;
import org.camunda.bpm.dmn.engine.DmnEngineConfiguration;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import static org.assertj.core.api.Assertions.assertThat;

class DmnSmokeTest {

    @Test
    void firstAndLastRulesCanBeEvaluated() throws Exception {
        DmnEngine engine = DmnEngineConfiguration
                .createDefaultDmnEngineConfiguration()
                .buildEngine();

        DmnDecision decision;
        try (var input = Objects.requireNonNull(
                getClass().getResourceAsStream("/dmn/commission-performance.dmn"))) {
            decision = engine.parseDecision("commissionDecision", input);
        }

        assertRule(engine, decision, RuleCatalog.profile(0));
        assertRule(engine, decision, RuleCatalog.profile(1999));
    }

    private static void assertRule(
            DmnEngine engine,
            DmnDecision decision,
            RuleProfile p) {

        Map<String, Object> variables = new HashMap<>(16);
        variables.put("insuranceType", p.insuranceType());
        variables.put("coverageType", p.coverageType());
        variables.put("stateCode", p.stateCode());
        variables.put("registrationCode", p.registrationCode());
        variables.put("productCode", p.productCode());
        variables.put("agentCategory", p.agentCategory());
        variables.put("channel", p.channel());
        variables.put("customerSegment", p.customerSegment());
        variables.put("policyTerm", p.policyTerm());
        variables.put("riskBand", p.riskBand());
        variables.put("premiumBand", p.premiumBand());
        variables.put("vehicleClass", p.vehicleClass());

        DmnDecisionResult result = engine.evaluateDecision(decision, variables);

        assertThat(result).hasSize(1);
        assertThat(result.getSingleResult().get("ruleCode"))
                .isEqualTo(p.ruleCode());
        assertThat(result.getSingleResult().get("commissionPercentage").toString())
                .isEqualTo(p.commissionPercentage().toString());
    }
}
