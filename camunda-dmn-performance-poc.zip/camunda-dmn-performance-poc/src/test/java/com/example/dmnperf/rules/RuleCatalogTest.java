package com.example.dmnperf.rules;

import org.junit.jupiter.api.Test;

import java.util.HashSet;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;

class RuleCatalogTest {

    @Test
    void firstTwoThousandRulesAreUnique() {
        Set<String> combinations = new HashSet<>();

        for (int i = 0; i < 2000; i++) {
            RuleProfile p = RuleCatalog.profile(i);
            combinations.add(String.join("|",
                    p.insuranceType(),
                    p.coverageType(),
                    p.stateCode(),
                    p.registrationCode(),
                    p.productCode(),
                    p.agentCategory(),
                    p.channel(),
                    p.customerSegment(),
                    p.policyTerm(),
                    p.riskBand(),
                    p.premiumBand(),
                    p.vehicleClass()
            ));
        }

        assertThat(combinations).hasSize(2000);
    }
}
