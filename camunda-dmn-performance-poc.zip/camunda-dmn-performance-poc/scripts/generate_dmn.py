#!/usr/bin/env python3
"""Regenerate the 2,000-rule, 12-input Camunda DMN file."""

from pathlib import Path
from xml.sax.saxutils import escape

RULE_COUNT = 2000
OUTPUT = Path(__file__).resolve().parents[1] / \
    "src/main/resources/dmn/commission-performance.dmn"

DIMENSIONS = [
    ("insuranceType", "Insurance Type", ("VEHICLE", "HEALTH")),
    ("coverageType", "Coverage Type", ("OWN_DAMAGE", "THIRD_PARTY")),
    ("stateCode", "State Code", ("AP", "AS")),
    ("registrationCode", "Registration Code", ("23", "42")),
    ("productCode", "Product Code", ("PROD_A", "PROD_B")),
    ("agentCategory", "Agent Category", ("STANDARD", "ELITE")),
    ("channel", "Channel", ("ONLINE", "BRANCH")),
    ("customerSegment", "Customer Segment", ("RETAIL", "SME")),
    ("policyTerm", "Policy Term", ("ANNUAL", "SHORT_TERM")),
    ("riskBand", "Risk Band", ("LOW", "HIGH")),
    ("premiumBand", "Premium Band", ("LOW", "HIGH")),
    ("vehicleClass", "Vehicle Class", ("PRIVATE", "COMMERCIAL")),
]


def quote(value: str) -> str:
    return f'"{escape(value)}"'


def rule_values(index: int):
    return [
        values[(index >> bit) & 1]
        for bit, (_, _, values) in enumerate(DIMENSIONS)
    ]


def generate():
    lines = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        '<definitions xmlns="https://www.omg.org/spec/DMN/20191111/MODEL/"',
        '             xmlns:dmndi="https://www.omg.org/spec/DMN/20191111/DMNDI/"',
        '             xmlns:dc="http://www.omg.org/spec/DMN/20180521/DC/"',
        '             xmlns:camunda="http://camunda.org/schema/1.0/dmn"',
        '             id="definitions_commission_performance"',
        '             name="Commission Performance Rules"',
        '             namespace="http://example.com/dmn/commission-performance">',
        '  <decision id="commissionDecision" name="Determine Commission Percentage">',
        '    <decisionTable id="commissionDecisionTable" hitPolicy="UNIQUE">'
    ]

    for i, (name, label, _) in enumerate(DIMENSIONS, start=1):
        lines.extend([
            f'      <input id="input_{i}" label="{escape(label)}">',
            f'        <inputExpression id="input_expression_{i}" typeRef="string">',
            f'          <text>{escape(name)}</text>',
            '        </inputExpression>',
            '      </input>',
        ])

    lines.extend([
        '      <output id="output_rate" label="Commission Percentage" '
        'name="commissionPercentage" typeRef="double"/>',
        '      <output id="output_rule_code" label="Rule Code" '
        'name="ruleCode" typeRef="string"/>',
    ])

    for index in range(RULE_COUNT):
        code = f"COMM-{index + 1:04d}"
        rate = 2.5 + (index % 16) * 0.5

        lines.append(f'      <rule id="rule_{index + 1:04d}">')
        for col, value in enumerate(rule_values(index), start=1):
            lines.extend([
                f'        <inputEntry id="rule_{index + 1:04d}_input_{col}">',
                f'          <text>{quote(value)}</text>',
                '        </inputEntry>',
            ])

        lines.extend([
            f'        <outputEntry id="rule_{index + 1:04d}_output_rate">',
            f'          <text>{rate:.1f}</text>',
            '        </outputEntry>',
            f'        <outputEntry id="rule_{index + 1:04d}_output_code">',
            f'          <text>{quote(code)}</text>',
            '        </outputEntry>',
            '      </rule>',
        ])

    lines.extend([
        '    </decisionTable>',
        '  </decision>',
        '</definitions>',
        ''
    ])

    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_text("\n".join(lines), encoding="utf-8")
    print(f"Wrote {OUTPUT} ({OUTPUT.stat().st_size:,} bytes)")


if __name__ == "__main__":
    generate()
