package com.example.cms.infrastructure.h2;

import org.h2.tools.Server;
import org.springframework.boot.context.event.ApplicationEnvironmentPreparedEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.core.env.Environment;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * Starts the H2 TCP server after Spring has resolved application.properties
 * (including command-line/external overrides) but before the application
 * context creates the DataSource.
 */
public final class H2TcpServerBootstrap
        implements ApplicationListener<ApplicationEnvironmentPreparedEvent> {

    private static Server server;

    @Override
    public void onApplicationEvent(ApplicationEnvironmentPreparedEvent event) {
        Environment environment = event.getEnvironment();
        boolean enabled = environment.getProperty("cms.h2.tcp.enabled", Boolean.class, true);
        if (!enabled) {
            return;
        }
        int port = environment.getProperty("cms.h2.tcp.port", Integer.class, 9093);
        String baseDir = environment.getProperty("cms.h2.base-dir", "./data");
        boolean allowOthers = environment.getProperty("cms.h2.tcp.allow-others", Boolean.class, false);
        start(port, baseDir, allowOthers);
    }

    private static synchronized void start(int port, String baseDir, boolean allowOthers) {
        if (server != null && server.isRunning(false)) {
            return;
        }
        try {
            Files.createDirectories(Path.of(baseDir));
            List<String> args = new ArrayList<>();
            args.add("-tcpPort");
            args.add(Integer.toString(port));
            args.add("-ifNotExists");
            args.add("-baseDir");
            args.add(baseDir);
            if (allowOthers) {
                args.add("-tcpAllowOthers");
            }
            server = Server.createTcpServer(args.toArray(String[]::new)).start();
            Runtime.getRuntime().addShutdownHook(new Thread(H2TcpServerBootstrap::stop, "h2-tcp-shutdown"));
            System.out.printf("H2 TCP server started on port %d with base directory %s%n", port, baseDir);
        } catch (Exception e) {
            throw new IllegalStateException("Unable to start the H2 TCP server", e);
        }
    }

    public static synchronized void stop() {
        if (server != null) {
            server.stop();
            server = null;
        }
    }
}
