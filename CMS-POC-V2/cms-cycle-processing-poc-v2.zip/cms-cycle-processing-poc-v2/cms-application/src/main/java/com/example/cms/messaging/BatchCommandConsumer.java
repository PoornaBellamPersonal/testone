package com.example.cms.messaging;

import com.example.cms.domain.BatchCommand;
import com.example.cms.service.BatchWorkerService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
public class BatchCommandConsumer {

    private static final Logger log = LoggerFactory.getLogger(BatchCommandConsumer.class);

    private final ObjectMapper objectMapper;
    private final BatchWorkerService workerService;

    public BatchCommandConsumer(ObjectMapper objectMapper, BatchWorkerService workerService) {
        this.objectMapper = objectMapper;
        this.workerService = workerService;
    }

    @KafkaListener(
            topics = "${cms.kafka.batch-topic}",
            groupId = "${cms.kafka.consumer-group}",
            concurrency = "${cms.worker.concurrency}")
    public void onMessage(String payload) throws Exception {
        BatchCommand command = objectMapper.readValue(payload, BatchCommand.class);
        log.info("Worker received {} with {} items", command.batchId(), command.itemCount());
        workerService.process(command);
    }
}
