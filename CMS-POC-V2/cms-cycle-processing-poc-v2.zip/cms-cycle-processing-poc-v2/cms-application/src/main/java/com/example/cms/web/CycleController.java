package com.example.cms.web;

import com.example.cms.domain.CycleSummary;
import com.example.cms.service.CycleService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/cycles")
public class CycleController {

    private final CycleService cycleService;
    private final int defaultBatchSize;
    private final int defaultTransactionCount;
    private final String visualizerBaseUrl;

    public CycleController(CycleService cycleService,
                           @Value("${cms.batch.default-size}") int defaultBatchSize,
                           @Value("${cms.cycle.default-transaction-count}") int defaultTransactionCount,
                           @Value("${cms.visualizer.base-url}") String visualizerBaseUrl) {
        this.cycleService = cycleService;
        this.defaultBatchSize = defaultBatchSize;
        this.defaultTransactionCount = defaultTransactionCount;
        this.visualizerBaseUrl = visualizerBaseUrl;
    }

    @GetMapping
    public String list(Model model) {
        if (!model.containsAttribute("cycleStartForm")) {
            CycleStartForm form = new CycleStartForm();
            form.setBatchSize(defaultBatchSize);
            form.setTransactionCount(defaultTransactionCount);
            model.addAttribute("cycleStartForm", form);
        }
        model.addAttribute("cycles", cycleService.recent());
        model.addAttribute("visualizerBaseUrl", visualizerBaseUrl);
        return "cycles";
    }

    @PostMapping
    public String start(@Valid @ModelAttribute CycleStartForm cycleStartForm,
                        BindingResult bindingResult,
                        Authentication authentication,
                        Model model) {
        if (bindingResult.hasErrors()) {
            model.addAttribute("cycles", cycleService.recent());
            model.addAttribute("visualizerBaseUrl", visualizerBaseUrl);
            return "cycles";
        }
        try {
            CycleSummary cycle = cycleService.start(cycleStartForm, authentication.getName());
            return "redirect:/cycles/" + cycle.cycleId();
        } catch (IllegalArgumentException e) {
            bindingResult.reject("cycle.configuration", e.getMessage());
            model.addAttribute("cycles", cycleService.recent());
            model.addAttribute("visualizerBaseUrl", visualizerBaseUrl);
            return "cycles";
        }
    }

    @GetMapping("/{cycleId}")
    public String detail(@PathVariable String cycleId, Model model) {
        model.addAttribute("cycle", cycleService.get(cycleId));
        model.addAttribute("progress", cycleService.progress(cycleId));
        model.addAttribute("visualizerBaseUrl", visualizerBaseUrl);
        return "cycle-detail";
    }
}
