package com.example.cms.process;

import com.example.cms.domain.Stage;
import com.example.cms.service.StageOrchestrationService;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Component;

@Component("prepareTaxStageDelegate")
public class PrepareTaxStageDelegate implements JavaDelegate {

    private final StageOrchestrationService service;

    public PrepareTaxStageDelegate(StageOrchestrationService service) {
        this.service = service;
    }

    @Override
    public void execute(DelegateExecution execution) {
        service.prepareStage((String) execution.getVariable("cycleId"), Stage.TAX);
    }
}
