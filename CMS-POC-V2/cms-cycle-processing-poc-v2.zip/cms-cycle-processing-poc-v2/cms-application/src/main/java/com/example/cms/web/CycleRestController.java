package com.example.cms.web;

import com.example.cms.domain.CycleSummary;
import com.example.cms.domain.StageProgress;
import com.example.cms.service.CycleService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/cycles")
public class CycleRestController {

    public record CycleStatusResponse(CycleSummary cycle, List<StageProgress> stages) {}

    private final CycleService cycleService;

    public CycleRestController(CycleService cycleService) {
        this.cycleService = cycleService;
    }

    @GetMapping("/{cycleId}")
    public CycleStatusResponse status(@PathVariable String cycleId) {
        return new CycleStatusResponse(cycleService.get(cycleId), cycleService.progress(cycleId));
    }
}
