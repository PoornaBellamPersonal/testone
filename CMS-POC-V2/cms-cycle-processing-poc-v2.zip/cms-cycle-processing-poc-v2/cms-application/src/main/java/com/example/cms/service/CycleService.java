package com.example.cms.service;

import com.example.cms.domain.CycleSummary;
import com.example.cms.domain.StageProgress;
import com.example.cms.repository.CycleRepository;
import com.example.cms.repository.StageProgressRepository;
import com.example.cms.web.CycleStartForm;
import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.runtime.ProcessInstance;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Service
public class CycleService {

    private final CycleRepository cycleRepository;
    private final StageProgressRepository stageProgressRepository;
    private final RuntimeService runtimeService;
    private final int maxBatchSize;
    private final int maxTransactionCount;

    public CycleService(CycleRepository cycleRepository,
                        StageProgressRepository stageProgressRepository,
                        RuntimeService runtimeService,
                        @Value("${cms.batch.max-size}") int maxBatchSize,
                        @Value("${cms.cycle.max-transaction-count}") int maxTransactionCount) {
        this.cycleRepository = cycleRepository;
        this.stageProgressRepository = stageProgressRepository;
        this.runtimeService = runtimeService;
        this.maxBatchSize = maxBatchSize;
        this.maxTransactionCount = maxTransactionCount;
    }

    @Transactional
    public CycleSummary start(CycleStartForm form, String username) {
        if (form.getBatchSize() > maxBatchSize) {
            throw new IllegalArgumentException("Batch size exceeds cms.batch.max-size=" + maxBatchSize);
        }
        if (form.getTransactionCount() > maxTransactionCount) {
            throw new IllegalArgumentException("Transaction count exceeds cms.cycle.max-transaction-count=" + maxTransactionCount);
        }

        String cycleId = newCycleId();
        cycleRepository.insert(cycleId, form.getCycleType(), form.getEffectiveDate(), form.getDataCutoff(),
                form.getDescription(), form.getDataFilterExpression(), form.getTransactionCount(), form.getBatchSize(), username);

        Map<String, Object> variables = Map.of(
                "cycleId", cycleId,
                "cycleType", form.getCycleType(),
                "effectiveDate", form.getEffectiveDate().toString(),
                "dataCutoff", form.getDataCutoff().toString(),
                "dataFilterExpression", form.getDataFilterExpression(),
                "transactionCount", form.getTransactionCount(),
                "batchSize", form.getBatchSize(),
                "adminUser", username);

        ProcessInstance instance = runtimeService.startProcessInstanceByKey(
                "cmsCycleProcessing", cycleId, variables);
        cycleRepository.updateProcessInstanceId(cycleId, instance.getProcessInstanceId());
        return cycleRepository.find(cycleId).orElseThrow();
    }

    public List<CycleSummary> recent() {
        return cycleRepository.recent(50);
    }

    public CycleSummary get(String cycleId) {
        return cycleRepository.find(cycleId).orElseThrow(() -> new IllegalArgumentException("Unknown cycle: " + cycleId));
    }

    public List<StageProgress> progress(String cycleId) {
        return stageProgressRepository.findByCycle(cycleId);
    }

    private String newCycleId() {
        return "CMS-" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss")) + "-" +
                UUID.randomUUID().toString().substring(0, 4).toUpperCase();
    }
}
