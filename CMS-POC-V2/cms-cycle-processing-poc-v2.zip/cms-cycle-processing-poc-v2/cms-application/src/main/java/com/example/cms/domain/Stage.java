package com.example.cms.domain;

public enum Stage {
    COMMISSION("COMMISSION_RULES"),
    TAX("TAX_RULES"),
    AGGREGATE_LIMIT("AGGREGATE_LIMIT_RULES");

    private final String ruleKey;

    Stage(String ruleKey) {
        this.ruleKey = ruleKey;
    }

    public String ruleKey() {
        return ruleKey;
    }

    public String completedMessage() {
        return name() + "_STAGE_COMPLETED";
    }

    public String failedMessage() {
        return name() + "_STAGE_FAILED";
    }
}
