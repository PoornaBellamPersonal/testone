package com.example.cms.service;

import com.example.cms.domain.Stage;
import com.example.cms.repository.BatchRepository;
import com.example.cms.repository.CycleRepository;
import com.example.cms.repository.TransactionRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class StageOrchestrationService {

    private final CycleRepository cycleRepository;
    private final TransactionRepository transactionRepository;
    private final BatchRepository batchRepository;

    public StageOrchestrationService(CycleRepository cycleRepository,
                                     TransactionRepository transactionRepository,
                                     BatchRepository batchRepository) {
        this.cycleRepository = cycleRepository;
        this.transactionRepository = transactionRepository;
        this.batchRepository = batchRepository;
    }

    @Transactional
    public void initializeCycle(String cycleId, int transactionCount) {
        cycleRepository.markRunning(cycleId, Stage.COMMISSION.name());
        transactionRepository.seed(cycleId, transactionCount);
    }

    @Transactional
    public void prepareStage(String cycleId, Stage stage) {
        cycleRepository.setCurrentStage(cycleId, stage.name());
        List<String> ids = transactionRepository.eligibleTransactionIds(cycleId, stage);
        batchRepository.createStageBatches(cycleId, stage, ids, cycleRepository.batchSize(cycleId));
    }
}
