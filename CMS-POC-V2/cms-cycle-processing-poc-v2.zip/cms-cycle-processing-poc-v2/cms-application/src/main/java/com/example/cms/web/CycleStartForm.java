package com.example.cms.web;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class CycleStartForm {

    @NotBlank
    private String cycleType = "TRIAL";

    @NotNull
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    private LocalDate effectiveDate = LocalDate.now();

    @NotNull
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    private LocalDateTime dataCutoff = LocalDateTime.now();

    private String description = "POC cycle";

    private String dataFilterExpression = "ALL";

    @Min(1)
    private int transactionCount;

    @Min(1)
    private int batchSize;

    public String getCycleType() { return cycleType; }
    public void setCycleType(String cycleType) { this.cycleType = cycleType; }
    public LocalDate getEffectiveDate() { return effectiveDate; }
    public void setEffectiveDate(LocalDate effectiveDate) { this.effectiveDate = effectiveDate; }
    public LocalDateTime getDataCutoff() { return dataCutoff; }
    public void setDataCutoff(LocalDateTime dataCutoff) { this.dataCutoff = dataCutoff; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getDataFilterExpression() { return dataFilterExpression; }
    public void setDataFilterExpression(String dataFilterExpression) { this.dataFilterExpression = dataFilterExpression; }
    public int getTransactionCount() { return transactionCount; }
    public void setTransactionCount(int transactionCount) { this.transactionCount = transactionCount; }
    public int getBatchSize() { return batchSize; }
    public void setBatchSize(int batchSize) { this.batchSize = batchSize; }
}
