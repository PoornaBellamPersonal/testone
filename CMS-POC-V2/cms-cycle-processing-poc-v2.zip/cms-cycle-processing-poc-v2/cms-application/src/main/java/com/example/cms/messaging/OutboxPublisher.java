package com.example.cms.messaging;

import com.example.cms.repository.OutboxRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;

@Component
public class OutboxPublisher {

    private static final Logger log = LoggerFactory.getLogger(OutboxPublisher.class);

    private final OutboxRepository repository;
    private final KafkaTemplate<String, String> kafkaTemplate;
    private final String topic;
    private final int publishLimit;

    public OutboxPublisher(OutboxRepository repository,
                           KafkaTemplate<String, String> kafkaTemplate,
                           @Value("${cms.kafka.batch-topic}") String topic,
                           @Value("${cms.outbox.publish-limit}") int publishLimit) {
        this.repository = repository;
        this.kafkaTemplate = kafkaTemplate;
        this.topic = topic;
        this.publishLimit = publishLimit;
    }

    @Scheduled(fixedDelayString = "${cms.outbox.poll-ms}")
    public void publishPending() {
        for (OutboxRepository.OutboxEvent event : repository.pending(publishLimit)) {
            try {
                kafkaTemplate.send(topic, event.aggregateId(), event.payload()).get(15, TimeUnit.SECONDS);
                repository.markPublished(event.eventId());
            } catch (Exception e) {
                log.warn("Unable to publish outbox event {}", event.eventId(), e);
                repository.markPublishFailure(event.eventId(), e.getMessage());
            }
        }
    }
}
