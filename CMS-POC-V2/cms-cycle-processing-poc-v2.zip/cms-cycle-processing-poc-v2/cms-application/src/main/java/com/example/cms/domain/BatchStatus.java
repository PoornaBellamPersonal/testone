package com.example.cms.domain;

public enum BatchStatus {
    READY,
    PROCESSING,
    RETRY,
    COMPLETED,
    FAILED
}
