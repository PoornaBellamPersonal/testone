package com.example.cms.repository;

import com.example.cms.domain.Stage;
import com.example.cms.domain.StageProgress;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Repository
public class StageProgressRepository {

    private final JdbcTemplate jdbc;

    public StageProgressRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    @Transactional
    public StageProgress incrementCompleted(String cycleId, Stage stage) {
        jdbc.update("""
                UPDATE CMS_STAGE_PROGRESS
                   SET COMPLETED_BATCHES=COMPLETED_BATCHES+1
                 WHERE CYCLE_ID=? AND STAGE=? AND STATUS='PROCESSING'
                """, cycleId, stage.name());
        StageProgress progress = find(cycleId, stage).orElseThrow();
        if (progress.failedBatches() == 0 && progress.completedBatches() >= progress.totalBatches()) {
            jdbc.update("""
                    UPDATE CMS_STAGE_PROGRESS
                       SET STATUS='COMPLETED', MESSAGE_NAME=?
                     WHERE CYCLE_ID=? AND STAGE=?
                    """, stage.completedMessage(), cycleId, stage.name());
            return find(cycleId, stage).orElseThrow();
        }
        return progress;
    }

    @Transactional
    public StageProgress incrementFailed(String cycleId, Stage stage) {
        jdbc.update("""
                UPDATE CMS_STAGE_PROGRESS
                   SET FAILED_BATCHES=FAILED_BATCHES+1, STATUS='FAILED', MESSAGE_NAME=?
                 WHERE CYCLE_ID=? AND STAGE=? AND STATUS <> 'FAILED'
                """, stage.failedMessage(), cycleId, stage.name());
        return find(cycleId, stage).orElseThrow();
    }

    public Optional<StageProgress> find(String cycleId, Stage stage) {
        return jdbc.query("""
                SELECT * FROM CMS_STAGE_PROGRESS WHERE CYCLE_ID=? AND STAGE=?
                """, this::map, cycleId, stage.name()).stream().findFirst();
    }

    public List<StageProgress> findByCycle(String cycleId) {
        return jdbc.query("""
                SELECT * FROM CMS_STAGE_PROGRESS WHERE CYCLE_ID=?
                 ORDER BY CASE STAGE WHEN 'COMMISSION' THEN 1 WHEN 'TAX' THEN 2 ELSE 3 END
                """, this::map, cycleId);
    }

    public List<StageProgress> pendingCorrelations() {
        return jdbc.query("""
                SELECT * FROM CMS_STAGE_PROGRESS
                 WHERE STATUS IN ('COMPLETED','FAILED') AND CORRELATED=FALSE AND MESSAGE_NAME IS NOT NULL
                 ORDER BY CYCLE_ID, STAGE
                """, this::map);
    }

    public void markCorrelated(String cycleId, String stage) {
        jdbc.update("UPDATE CMS_STAGE_PROGRESS SET CORRELATED=TRUE WHERE CYCLE_ID=? AND STAGE=?", cycleId, stage);
    }

    private StageProgress map(java.sql.ResultSet rs, int rowNum) throws java.sql.SQLException {
        return new StageProgress(
                rs.getString("CYCLE_ID"),
                rs.getString("STAGE"),
                rs.getInt("TOTAL_BATCHES"),
                rs.getInt("COMPLETED_BATCHES"),
                rs.getInt("FAILED_BATCHES"),
                rs.getString("STATUS"),
                rs.getBoolean("CORRELATED"),
                rs.getString("MESSAGE_NAME"));
    }
}
