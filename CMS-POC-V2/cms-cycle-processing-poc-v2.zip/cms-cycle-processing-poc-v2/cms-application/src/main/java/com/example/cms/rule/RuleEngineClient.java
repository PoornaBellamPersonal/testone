package com.example.cms.rule;

import com.example.cms.domain.RuleBatchRequest;
import com.example.cms.domain.RuleBatchResponse;

public interface RuleEngineClient {
    RuleBatchResponse evaluateBatch(RuleBatchRequest request);
}
