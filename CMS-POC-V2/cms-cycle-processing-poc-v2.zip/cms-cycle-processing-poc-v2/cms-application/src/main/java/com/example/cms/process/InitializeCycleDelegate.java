package com.example.cms.process;

import com.example.cms.service.StageOrchestrationService;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Component;

@Component("initializeCycleDelegate")
public class InitializeCycleDelegate implements JavaDelegate {

    private final StageOrchestrationService service;

    public InitializeCycleDelegate(StageOrchestrationService service) {
        this.service = service;
    }

    @Override
    public void execute(DelegateExecution execution) {
        String cycleId = (String) execution.getVariable("cycleId");
        int transactionCount = ((Number) execution.getVariable("transactionCount")).intValue();
        service.initializeCycle(cycleId, transactionCount);
    }
}
