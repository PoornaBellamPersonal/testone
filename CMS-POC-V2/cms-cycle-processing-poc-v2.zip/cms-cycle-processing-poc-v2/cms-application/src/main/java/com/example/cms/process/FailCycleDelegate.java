package com.example.cms.process;

import com.example.cms.repository.CycleRepository;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Component;

@Component("failCycleDelegate")
public class FailCycleDelegate implements JavaDelegate {

    private final CycleRepository repository;

    public FailCycleDelegate(CycleRepository repository) {
        this.repository = repository;
    }

    @Override
    public void execute(DelegateExecution execution) {
        Object reason = execution.getVariable("stageFailureReason");
        repository.markFailed((String) execution.getVariable("cycleId"),
                reason == null ? "A batch stage failed" : reason.toString());
    }
}
