package com.example.cms.repository;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class OutboxRepository {

    public record OutboxEvent(String eventId, String aggregateId, String payload) {
    }

    private final JdbcTemplate jdbc;

    public OutboxRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public List<OutboxEvent> pending(int limit) {
        return jdbc.query("""
                SELECT EVENT_ID, AGGREGATE_ID, PAYLOAD
                  FROM CMS_OUTBOX_EVENT
                 WHERE STATUS='PENDING'
                 ORDER BY CREATED_AT
                 LIMIT ?
                """, (rs, rowNum) -> new OutboxEvent(
                rs.getString("EVENT_ID"), rs.getString("AGGREGATE_ID"), rs.getString("PAYLOAD")), limit);
    }

    public void markPublished(String eventId) {
        jdbc.update("""
                UPDATE CMS_OUTBOX_EVENT
                   SET STATUS='PUBLISHED', ATTEMPTS=ATTEMPTS+1, PUBLISHED_AT=CURRENT_TIMESTAMP, LAST_ERROR=NULL
                 WHERE EVENT_ID=?
                """, eventId);
    }

    public void markPublishFailure(String eventId, String error) {
        jdbc.update("""
                UPDATE CMS_OUTBOX_EVENT
                   SET ATTEMPTS=ATTEMPTS+1, LAST_ERROR=?
                 WHERE EVENT_ID=?
                """, error == null ? null : error.substring(0, Math.min(error.length(), 1900)), eventId);
    }
}
