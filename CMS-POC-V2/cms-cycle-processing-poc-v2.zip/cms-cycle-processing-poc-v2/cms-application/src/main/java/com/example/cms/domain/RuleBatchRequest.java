package com.example.cms.domain;

import java.util.List;

public record RuleBatchRequest(String batchId, String ruleKey, List<RuleBatchItem> items) {
}
