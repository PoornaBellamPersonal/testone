package com.example.cms.repository;

import com.example.cms.domain.BatchCommand;
import com.example.cms.domain.Stage;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

@Repository
public class BatchRepository {

    private final JdbcTemplate jdbc;
    private final ObjectMapper objectMapper;

    public BatchRepository(JdbcTemplate jdbc, ObjectMapper objectMapper) {
        this.jdbc = jdbc;
        this.objectMapper = objectMapper;
    }

    public boolean stageAlreadyPrepared(String cycleId, Stage stage) {
        Integer count = jdbc.queryForObject(
                "SELECT COUNT(*) FROM CMS_STAGE_PROGRESS WHERE CYCLE_ID=? AND STAGE=?",
                Integer.class, cycleId, stage.name());
        return count != null && count > 0;
    }

    @Transactional
    public void createStageBatches(String cycleId, Stage stage, List<String> transactionIds, int batchSize) {
        if (stageAlreadyPrepared(cycleId, stage)) {
            return;
        }

        int totalBatches = transactionIds.isEmpty() ? 0 : (transactionIds.size() + batchSize - 1) / batchSize;
        jdbc.update("""
                INSERT INTO CMS_STAGE_PROGRESS
                (CYCLE_ID, STAGE, TOTAL_BATCHES, COMPLETED_BATCHES, FAILED_BATCHES, STATUS, CORRELATED, MESSAGE_NAME)
                VALUES (?, ?, ?, 0, 0, ?, FALSE, ?)
                """, cycleId, stage.name(), totalBatches,
                totalBatches == 0 ? "COMPLETED" : "PROCESSING",
                totalBatches == 0 ? stage.completedMessage() : null);

        for (int batchNo = 1; batchNo <= totalBatches; batchNo++) {
            int from = (batchNo - 1) * batchSize;
            int to = Math.min(from + batchSize, transactionIds.size());
            List<String> ids = transactionIds.subList(from, to);
            String batchId = "%s-%s-%05d".formatted(cycleId, stage.name(), batchNo);
            jdbc.update("""
                    INSERT INTO CMS_BATCH
                    (BATCH_ID, CYCLE_ID, STAGE, BATCH_NUMBER, ITEM_COUNT, STATUS, ATTEMPT_COUNT, CREATED_AT)
                    VALUES (?, ?, ?, ?, ?, 'READY', 0, CURRENT_TIMESTAMP)
                    """, batchId, cycleId, stage.name(), batchNo, ids.size());

            List<Object[]> itemRows = ids.stream().map(id -> new Object[]{batchId, id}).toList();
            jdbc.batchUpdate("INSERT INTO CMS_BATCH_ITEM (BATCH_ID, TRANSACTION_ID) VALUES (?, ?)", itemRows);

            String eventId = UUID.randomUUID().toString();
            BatchCommand command = new BatchCommand(eventId, cycleId, batchId, stage.name(), stage.ruleKey(), ids.size());
            jdbc.update("""
                    INSERT INTO CMS_OUTBOX_EVENT
                    (EVENT_ID, AGGREGATE_ID, EVENT_TYPE, PAYLOAD, STATUS, ATTEMPTS, CREATED_AT)
                    VALUES (?, ?, 'BATCH_COMMAND', ?, 'PENDING', 0, CURRENT_TIMESTAMP)
                    """, eventId, batchId, json(command));
        }
    }

    public boolean claim(String batchId, String workerId) {
        int updated = jdbc.update("""
                UPDATE CMS_BATCH
                   SET STATUS='PROCESSING', ATTEMPT_COUNT=ATTEMPT_COUNT+1,
                       WORKER_ID=?, STARTED_AT=COALESCE(STARTED_AT, CURRENT_TIMESTAMP), LAST_ERROR=NULL
                 WHERE BATCH_ID=? AND STATUS IN ('READY','RETRY')
                """, workerId, batchId);
        return updated == 1;
    }

    public void markRetry(String batchId, Exception e) {
        jdbc.update("""
                UPDATE CMS_BATCH SET STATUS='RETRY', LAST_ERROR=? WHERE BATCH_ID=? AND STATUS='PROCESSING'
                """, abbreviate(e.getMessage()), batchId);
    }

    public boolean markCompletedIfActive(String batchId) {
        int updated = jdbc.update("""
                UPDATE CMS_BATCH
                   SET STATUS='COMPLETED', COMPLETED_AT=CURRENT_TIMESTAMP, LAST_ERROR=NULL
                 WHERE BATCH_ID=? AND STATUS IN ('PROCESSING','RETRY')
                """, batchId);
        return updated == 1;
    }

    public boolean markFailedIfNotTerminal(String batchId, String error) {
        int updated = jdbc.update("""
                UPDATE CMS_BATCH
                   SET STATUS='FAILED', COMPLETED_AT=CURRENT_TIMESTAMP, LAST_ERROR=?
                 WHERE BATCH_ID=? AND STATUS NOT IN ('COMPLETED','FAILED')
                """, abbreviate(error), batchId);
        return updated == 1;
    }

    /** Reset work that belonged to a JVM which stopped before the listener returned. */
    public int recoverInterruptedBatches() {
        return jdbc.update("""
                UPDATE CMS_BATCH
                   SET STATUS='RETRY', WORKER_ID=NULL,
                       LAST_ERROR=COALESCE(LAST_ERROR, 'Recovered after CMS restart')
                 WHERE STATUS='PROCESSING'
                """);
    }

    public boolean isCompleted(String batchId) {
        String status = jdbc.queryForObject("SELECT STATUS FROM CMS_BATCH WHERE BATCH_ID=?", String.class, batchId);
        return "COMPLETED".equals(status);
    }

    public String stageOf(String batchId) {
        return jdbc.queryForObject("SELECT STAGE FROM CMS_BATCH WHERE BATCH_ID=?", String.class, batchId);
    }

    public String cycleOf(String batchId) {
        return jdbc.queryForObject("SELECT CYCLE_ID FROM CMS_BATCH WHERE BATCH_ID=?", String.class, batchId);
    }

    private String json(BatchCommand command) {
        try {
            return objectMapper.writeValueAsString(command);
        } catch (JsonProcessingException e) {
            throw new IllegalStateException("Unable to serialize batch command", e);
        }
    }

    private String abbreviate(String value) {
        if (value == null) {
            return null;
        }
        return value.length() <= 1900 ? value : value.substring(0, 1900);
    }
}
