package com.example.cms.domain;

public record BatchCommand(
        String eventId,
        String cycleId,
        String batchId,
        String stage,
        String ruleKey,
        int itemCount) {
}
