package com.example.cms.domain;

public enum CycleStatus {
    SUBMITTED,
    RUNNING,
    COMPLETED,
    FAILED
}
