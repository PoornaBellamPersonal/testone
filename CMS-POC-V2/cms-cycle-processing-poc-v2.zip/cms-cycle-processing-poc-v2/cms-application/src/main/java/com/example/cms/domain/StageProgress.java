package com.example.cms.domain;

public record StageProgress(
        String cycleId,
        String stage,
        int totalBatches,
        int completedBatches,
        int failedBatches,
        String status,
        boolean correlated,
        String messageName) {
}
