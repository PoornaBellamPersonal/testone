package com.example.cms.repository;

import com.example.cms.domain.RuleBatchItem;
import com.example.cms.domain.RuleItemResult;
import com.example.cms.domain.Stage;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Repository
public class TransactionRepository {

    private final JdbcTemplate jdbc;

    public TransactionRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public boolean existsForCycle(String cycleId) {
        Integer count = jdbc.queryForObject("SELECT COUNT(*) FROM CMS_TRANSACTION WHERE CYCLE_ID=?", Integer.class, cycleId);
        return count != null && count > 0;
    }

    public void seed(String cycleId, int transactionCount) {
        if (existsForCycle(cycleId)) {
            return;
        }
        final int chunkSize = 1000;
        for (int start = 1; start <= transactionCount; start += chunkSize) {
            int end = Math.min(transactionCount, start + chunkSize - 1);
            List<Object[]> rows = new ArrayList<>(end - start + 1);
            for (int i = start; i <= end; i++) {
                String id = "%s-TX-%07d".formatted(cycleId, i);
                String channel = switch (i % 3) {
                    case 0 -> "AGENCY";
                    case 1 -> "BROKER";
                    default -> "DIRECT";
                };
                String region = switch (i % 4) {
                    case 0 -> "NORTH";
                    case 1 -> "SOUTH";
                    case 2 -> "EAST";
                    default -> "WEST";
                };
                BigDecimal amount = BigDecimal.valueOf(1000L + ((long) i % 200L) * 250L);
                rows.add(new Object[]{id, cycleId, i, channel, region, amount});
            }
            jdbc.batchUpdate("""
                    INSERT INTO CMS_TRANSACTION
                    (TRANSACTION_ID, CYCLE_ID, TX_NO, CHANNEL_TYPE, REGION, AMOUNT)
                    VALUES (?, ?, ?, ?, ?, ?)
                    """, rows);
        }
    }

    public List<String> eligibleTransactionIds(String cycleId, Stage stage) {
        String sql = switch (stage) {
            case COMMISSION -> "SELECT TRANSACTION_ID FROM CMS_TRANSACTION WHERE CYCLE_ID=? ORDER BY TX_NO";
            case TAX -> "SELECT TRANSACTION_ID FROM CMS_TRANSACTION WHERE CYCLE_ID=? AND COMMISSION_AMOUNT IS NOT NULL ORDER BY TX_NO";
            case AGGREGATE_LIMIT -> "SELECT TRANSACTION_ID FROM CMS_TRANSACTION WHERE CYCLE_ID=? AND TAX_AMOUNT IS NOT NULL ORDER BY TX_NO";
        };
        return jdbc.query(sql, (rs, rowNum) -> rs.getString(1), cycleId);
    }

    public List<RuleBatchItem> loadRuleItems(String batchId, Stage stage) {
        return jdbc.query("""
                SELECT T.*
                  FROM CMS_TRANSACTION T
                  JOIN CMS_BATCH_ITEM I ON I.TRANSACTION_ID=T.TRANSACTION_ID
                 WHERE I.BATCH_ID=?
                 ORDER BY T.TX_NO
                """, (rs, rowNum) -> {
            Map<String, Object> inputs = new LinkedHashMap<>();
            switch (stage) {
                case COMMISSION -> {
                    inputs.put("channelType", rs.getString("CHANNEL_TYPE"));
                    inputs.put("amount", rs.getBigDecimal("AMOUNT"));
                }
                case TAX -> {
                    inputs.put("region", rs.getString("REGION"));
                    inputs.put("commissionAmount", rs.getBigDecimal("COMMISSION_AMOUNT"));
                }
                case AGGREGATE_LIMIT -> {
                    inputs.put("commissionAmount", rs.getBigDecimal("COMMISSION_AMOUNT"));
                    inputs.put("taxAmount", rs.getBigDecimal("TAX_AMOUNT"));
                }
            }
            return new RuleBatchItem(rs.getString("TRANSACTION_ID"), inputs);
        }, batchId);
    }

    @org.springframework.transaction.annotation.Transactional
    public void applyResults(Stage stage, List<RuleItemResult> results) {
        List<Object[]> successRows = new ArrayList<>();
        List<Object[]> errorRows = new ArrayList<>();

        for (RuleItemResult result : results) {
            if (!result.success()) {
                errorRows.add(new Object[]{result.errorCode() + ": " + result.errorMessage(), result.transactionId()});
                continue;
            }
            Map<String, Object> out = result.outputs();
            switch (stage) {
                case COMMISSION -> successRows.add(new Object[]{number(out.get("commissionAmount")), result.transactionId()});
                case TAX -> successRows.add(new Object[]{number(out.get("taxAmount")), result.transactionId()});
                case AGGREGATE_LIMIT -> successRows.add(new Object[]{String.valueOf(out.get("limitStatus")), result.transactionId()});
            }
        }

        if (!successRows.isEmpty()) {
            String successSql = switch (stage) {
                case COMMISSION -> "UPDATE CMS_TRANSACTION SET COMMISSION_AMOUNT=?, LAST_ERROR=NULL WHERE TRANSACTION_ID=?";
                case TAX -> "UPDATE CMS_TRANSACTION SET TAX_AMOUNT=?, LAST_ERROR=NULL WHERE TRANSACTION_ID=?";
                case AGGREGATE_LIMIT -> "UPDATE CMS_TRANSACTION SET LIMIT_STATUS=?, LAST_ERROR=NULL WHERE TRANSACTION_ID=?";
            };
            jdbc.batchUpdate(successSql, successRows);
        }
        if (!errorRows.isEmpty()) {
            jdbc.batchUpdate("UPDATE CMS_TRANSACTION SET LAST_ERROR=? WHERE TRANSACTION_ID=?", errorRows);
        }
    }

    private BigDecimal number(Object value) {
        if (value == null) {
            return null;
        }
        if (value instanceof BigDecimal bd) {
            return bd;
        }
        if (value instanceof Number n) {
            return BigDecimal.valueOf(n.doubleValue());
        }
        return new BigDecimal(value.toString());
    }
}
