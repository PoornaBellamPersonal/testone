package com.example.cms.process;

import com.example.cms.repository.CycleRepository;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Component;

@Component("completeCycleDelegate")
public class CompleteCycleDelegate implements JavaDelegate {

    private final CycleRepository repository;

    public CompleteCycleDelegate(CycleRepository repository) {
        this.repository = repository;
    }

    @Override
    public void execute(DelegateExecution execution) {
        repository.markCompleted((String) execution.getVariable("cycleId"));
    }
}
