package com.example.cms.domain;

import java.time.LocalDate;
import java.time.LocalDateTime;

public record CycleSummary(
        String cycleId,
        String processInstanceId,
        String cycleType,
        LocalDate effectiveDate,
        LocalDateTime dataCutoff,
        String description,
        String dataFilterExpression,
        int transactionCount,
        int batchSize,
        String status,
        String currentStage,
        String createdBy,
        LocalDateTime createdAt,
        LocalDateTime completedAt) {
}
