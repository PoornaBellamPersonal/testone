package com.example.cms.rule;

import com.example.cms.domain.RuleBatchRequest;
import com.example.cms.domain.RuleBatchResponse;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;

@Component
public class RemoteRuleEngineClient implements RuleEngineClient {

    private final ObjectMapper objectMapper;
    private final HttpClient httpClient;
    private final URI evaluationUri;
    private final Duration readTimeout;

    public RemoteRuleEngineClient(ObjectMapper objectMapper,
                                  @Value("${cms.rule-engine.base-url}") String baseUrl,
                                  @Value("${cms.rule-engine.batch-evaluation-path}") String path,
                                  @Value("${cms.rule-engine.connect-timeout-ms}") long connectTimeoutMs,
                                  @Value("${cms.rule-engine.read-timeout-ms}") long readTimeoutMs) {
        this.objectMapper = objectMapper;
        this.httpClient = HttpClient.newBuilder()
                .connectTimeout(Duration.ofMillis(connectTimeoutMs))
                .build();
        this.evaluationUri = URI.create(baseUrl + path);
        this.readTimeout = Duration.ofMillis(readTimeoutMs);
    }

    @Override
    public RuleBatchResponse evaluateBatch(RuleBatchRequest request) {
        try {
            String json = objectMapper.writeValueAsString(request);
            HttpRequest httpRequest = HttpRequest.newBuilder(evaluationUri)
                    .timeout(readTimeout)
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(json))
                    .build();
            HttpResponse<String> response = httpClient.send(httpRequest, HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() < 200 || response.statusCode() >= 300) {
                throw new RuleEngineUnavailableException(
                        "Rule engine returned HTTP " + response.statusCode() + ": " + response.body());
            }
            return objectMapper.readValue(response.body(), RuleBatchResponse.class);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new RuleEngineUnavailableException("Rule engine call interrupted", e);
        } catch (RuleEngineUnavailableException e) {
            throw e;
        } catch (Exception e) {
            throw new RuleEngineUnavailableException("Rule engine call failed", e);
        }
    }
}
