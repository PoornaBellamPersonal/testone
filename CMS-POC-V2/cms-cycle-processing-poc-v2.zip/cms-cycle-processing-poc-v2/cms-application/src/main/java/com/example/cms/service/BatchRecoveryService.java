package com.example.cms.service;

import com.example.cms.repository.BatchRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

/**
 * POC restart recovery. Kafka won't commit a record while a listener invocation
 * is still running, but the database may contain PROCESSING from the old JVM.
 * Reset those claims so a redelivered command can claim them again.
 */
@Component
public class BatchRecoveryService {

    private static final Logger log = LoggerFactory.getLogger(BatchRecoveryService.class);
    private final BatchRepository batchRepository;

    public BatchRecoveryService(BatchRepository batchRepository) {
        this.batchRepository = batchRepository;
    }

    @EventListener(ApplicationReadyEvent.class)
    public void recoverInterruptedWork() {
        int recovered = batchRepository.recoverInterruptedBatches();
        if (recovered > 0) {
            log.warn("Recovered {} interrupted CMS batch(es) to RETRY state", recovered);
        }
    }
}
