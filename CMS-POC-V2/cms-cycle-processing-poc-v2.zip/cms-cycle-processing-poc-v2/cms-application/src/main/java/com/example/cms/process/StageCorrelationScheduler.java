package com.example.cms.process;

import com.example.cms.domain.StageProgress;
import com.example.cms.repository.StageProgressRepository;
import org.camunda.bpm.engine.MismatchingMessageCorrelationException;
import org.camunda.bpm.engine.RuntimeService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class StageCorrelationScheduler {

    private static final Logger log = LoggerFactory.getLogger(StageCorrelationScheduler.class);

    private final StageProgressRepository repository;
    private final RuntimeService runtimeService;

    public StageCorrelationScheduler(StageProgressRepository repository, RuntimeService runtimeService) {
        this.repository = repository;
        this.runtimeService = runtimeService;
    }

    @Scheduled(fixedDelayString = "${cms.stage-correlation.poll-ms}")
    public void correlatePendingStageEvents() {
        for (StageProgress progress : repository.pendingCorrelations()) {
            try {
                runtimeService.createMessageCorrelation(progress.messageName())
                        .processInstanceBusinessKey(progress.cycleId())
                        .setVariable("lastCompletedStage", progress.stage())
                        .correlate();
                repository.markCorrelated(progress.cycleId(), progress.stage());
                log.info("Correlated {} for cycle {}", progress.messageName(), progress.cycleId());
            } catch (MismatchingMessageCorrelationException e) {
                // Process may not have reached its message catch event yet. Leave the
                // progress row pending; the next scheduled pass will retry safely.
                log.debug("Message subscription not ready yet for {} / {}", progress.cycleId(), progress.messageName());
            }
        }
    }
}
