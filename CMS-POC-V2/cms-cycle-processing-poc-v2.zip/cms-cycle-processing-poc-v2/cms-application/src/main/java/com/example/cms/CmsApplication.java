package com.example.cms;

import com.example.cms.infrastructure.h2.H2TcpServerBootstrap;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class CmsApplication {

    public static void main(String[] args) {
        SpringApplication application = new SpringApplication(CmsApplication.class);
        application.addListeners(new H2TcpServerBootstrap());
        application.run(args);
    }
}
