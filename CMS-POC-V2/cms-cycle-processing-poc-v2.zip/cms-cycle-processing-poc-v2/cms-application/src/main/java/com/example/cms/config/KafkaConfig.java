package com.example.cms.config;

import org.apache.kafka.common.TopicPartition;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.TopicBuilder;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.listener.DeadLetterPublishingRecoverer;
import org.springframework.kafka.listener.DefaultErrorHandler;
import org.springframework.kafka.support.ExponentialBackOffWithMaxRetries;
import org.apache.kafka.clients.admin.NewTopic;

@Configuration
public class KafkaConfig {

    @Bean
    NewTopic batchTopic(@Value("${cms.kafka.batch-topic}") String topic,
                        @Value("${cms.kafka.partitions}") int partitions,
                        @Value("${cms.kafka.replication-factor}") short replicationFactor) {
        return TopicBuilder.name(topic).partitions(partitions).replicas(replicationFactor).build();
    }

    @Bean
    NewTopic dltTopic(@Value("${cms.kafka.dlt-topic}") String topic,
                      @Value("${cms.kafka.partitions}") int partitions,
                      @Value("${cms.kafka.replication-factor}") short replicationFactor) {
        return TopicBuilder.name(topic).partitions(partitions).replicas(replicationFactor).build();
    }

    @Bean
    DefaultErrorHandler kafkaErrorHandler(KafkaTemplate<String, String> template,
                                           @Value("${cms.kafka.dlt-topic}") String dltTopic,
                                           @Value("${cms.worker.max-attempts}") int maxAttempts,
                                           @Value("${cms.worker.retry-delay-ms}") long retryDelayMs) {
        DeadLetterPublishingRecoverer recoverer = new DeadLetterPublishingRecoverer(
                template, (record, ex) -> new TopicPartition(dltTopic, record.partition()));
        ExponentialBackOffWithMaxRetries backOff = new ExponentialBackOffWithMaxRetries(Math.max(0, maxAttempts - 1));
        backOff.setInitialInterval(retryDelayMs);
        backOff.setMultiplier(1.0);
        backOff.setMaxInterval(retryDelayMs);
        return new DefaultErrorHandler(recoverer, backOff);
    }
}
