package com.example.cms.service;

import com.example.cms.domain.*;
import com.example.cms.repository.BatchRepository;
import com.example.cms.repository.TransactionRepository;
import com.example.cms.rule.RuleEngineClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class BatchWorkerService {

    private final BatchRepository batchRepository;
    private final TransactionRepository transactionRepository;
    private final RuleEngineClient ruleEngineClient;
    private final StageCompletionService stageCompletionService;
    private final String workerId;
    private final int maxItemsPerRequest;

    public BatchWorkerService(BatchRepository batchRepository,
                              TransactionRepository transactionRepository,
                              RuleEngineClient ruleEngineClient,
                              StageCompletionService stageCompletionService,
                              @Value("${cms.worker.instance-id}") String workerId,
                              @Value("${cms.rule-engine.max-items-per-request}") int maxItemsPerRequest) {
        this.batchRepository = batchRepository;
        this.transactionRepository = transactionRepository;
        this.ruleEngineClient = ruleEngineClient;
        this.stageCompletionService = stageCompletionService;
        this.workerId = workerId;
        this.maxItemsPerRequest = maxItemsPerRequest;
    }

    public void process(BatchCommand command) {
        if (batchRepository.isCompleted(command.batchId())) {
            return;
        }
        if (!batchRepository.claim(command.batchId(), workerId + "-" + Thread.currentThread().getName())) {
            return;
        }

        Stage stage = Stage.valueOf(command.stage());
        try {
            List<RuleBatchItem> items = transactionRepository.loadRuleItems(command.batchId(), stage);
            List<RuleItemResult> allResults = new ArrayList<>(items.size());
            for (int from = 0; from < items.size(); from += maxItemsPerRequest) {
                int to = Math.min(from + maxItemsPerRequest, items.size());
                List<RuleBatchItem> slice = items.subList(from, to);
                String requestBatchId = items.size() <= maxItemsPerRequest
                        ? command.batchId()
                        : command.batchId() + "-PART-" + (from / maxItemsPerRequest + 1);
                RuleBatchResponse response = ruleEngineClient.evaluateBatch(
                        new RuleBatchRequest(requestBatchId, command.ruleKey(), slice));
                if (response.results() == null || response.results().size() != slice.size()) {
                    throw new IllegalStateException("Rule engine returned an incomplete result for " + requestBatchId
                            + "; expected " + slice.size() + " item results");
                }
                allResults.addAll(response.results());
            }
            transactionRepository.applyResults(stage, allResults);
            stageCompletionService.completeBatch(command.batchId(), command.cycleId(), stage);
        } catch (Exception e) {
            batchRepository.markRetry(command.batchId(), e);
            throw e;
        }
    }

    public void failPermanently(BatchCommand command, String error) {
        if (batchRepository.isCompleted(command.batchId())) {
            return;
        }
        stageCompletionService.failBatch(
                command.batchId(), command.cycleId(), Stage.valueOf(command.stage()), error);
    }
}
