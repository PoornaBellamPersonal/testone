package com.example.cms.domain;

import java.util.Map;

public record RuleItemResult(
        String transactionId,
        boolean success,
        Map<String, Object> outputs,
        String errorCode,
        String errorMessage) {
}
