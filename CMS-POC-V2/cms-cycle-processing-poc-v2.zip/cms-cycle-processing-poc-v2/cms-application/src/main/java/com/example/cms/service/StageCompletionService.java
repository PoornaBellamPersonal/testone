package com.example.cms.service;

import com.example.cms.domain.Stage;
import com.example.cms.repository.BatchRepository;
import com.example.cms.repository.CycleRepository;
import com.example.cms.repository.StageProgressRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class StageCompletionService {

    private final BatchRepository batchRepository;
    private final StageProgressRepository progressRepository;
    private final CycleRepository cycleRepository;

    public StageCompletionService(BatchRepository batchRepository,
                                  StageProgressRepository progressRepository,
                                  CycleRepository cycleRepository) {
        this.batchRepository = batchRepository;
        this.progressRepository = progressRepository;
        this.cycleRepository = cycleRepository;
    }

    /**
     * Completes the batch and advances stage progress atomically.  This avoids
     * the "batch completed but stage counter not incremented" crash window.
     */
    @Transactional
    public void completeBatch(String batchId, String cycleId, Stage stage) {
        if (batchRepository.markCompletedIfActive(batchId)) {
            progressRepository.incrementCompleted(cycleId, stage);
        }
    }

    /**
     * Marks the DLT batch, stage and cycle failed in one database transaction.
     */
    @Transactional
    public void failBatch(String batchId, String cycleId, Stage stage, String error) {
        if (batchRepository.markFailedIfNotTerminal(batchId, error)) {
            progressRepository.incrementFailed(cycleId, stage);
            cycleRepository.markFailed(cycleId, stage.name() + " batch failed: " + error);
        }
    }
}
