package com.example.cms.rule;

public class RuleEngineUnavailableException extends RuntimeException {
    public RuleEngineUnavailableException(String message) { super(message); }
    public RuleEngineUnavailableException(String message, Throwable cause) { super(message, cause); }
}
