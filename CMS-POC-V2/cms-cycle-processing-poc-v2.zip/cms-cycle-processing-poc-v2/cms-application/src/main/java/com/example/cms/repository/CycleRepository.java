package com.example.cms.repository;

import com.example.cms.domain.CycleSummary;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public class CycleRepository {

    private final JdbcTemplate jdbc;

    public CycleRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public void insert(String cycleId, String cycleType, LocalDate effectiveDate, LocalDateTime dataCutoff,
                       String description, String dataFilterExpression, int transactionCount, int batchSize, String createdBy) {
        jdbc.update("""
                INSERT INTO CMS_CYCLE
                (CYCLE_ID, CYCLE_TYPE, EFFECTIVE_DATE, DATA_CUTOFF, DESCRIPTION, DATA_FILTER_EXPRESSION,
                 TRANSACTION_COUNT, BATCH_SIZE, STATUS, CREATED_BY, CREATED_AT)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'SUBMITTED', ?, CURRENT_TIMESTAMP)
                """, cycleId, cycleType, effectiveDate, Timestamp.valueOf(dataCutoff), description,
                dataFilterExpression, transactionCount, batchSize, createdBy);
    }

    public void updateProcessInstanceId(String cycleId, String processInstanceId) {
        jdbc.update("UPDATE CMS_CYCLE SET PROCESS_INSTANCE_ID=? WHERE CYCLE_ID=?", processInstanceId, cycleId);
    }

    public void markRunning(String cycleId, String stage) {
        jdbc.update("""
                UPDATE CMS_CYCLE
                   SET STATUS='RUNNING', CURRENT_STAGE=?, STARTED_AT=COALESCE(STARTED_AT, CURRENT_TIMESTAMP)
                 WHERE CYCLE_ID=?
                """, stage, cycleId);
    }

    public void setCurrentStage(String cycleId, String stage) {
        jdbc.update("UPDATE CMS_CYCLE SET CURRENT_STAGE=? WHERE CYCLE_ID=?", stage, cycleId);
    }

    public void markCompleted(String cycleId) {
        jdbc.update("""
                UPDATE CMS_CYCLE SET STATUS='COMPLETED', CURRENT_STAGE='COMPLETED', COMPLETED_AT=CURRENT_TIMESTAMP
                 WHERE CYCLE_ID=?
                """, cycleId);
    }

    public void markFailed(String cycleId, String reason) {
        jdbc.update("""
                UPDATE CMS_CYCLE SET STATUS='FAILED', CURRENT_STAGE='FAILED', FAILURE_REASON=COALESCE(FAILURE_REASON, ?), COMPLETED_AT=COALESCE(COMPLETED_AT, CURRENT_TIMESTAMP)
                 WHERE CYCLE_ID=?
                """, reason, cycleId);
    }

    public int batchSize(String cycleId) {
        Integer value = jdbc.queryForObject("SELECT BATCH_SIZE FROM CMS_CYCLE WHERE CYCLE_ID=?", Integer.class, cycleId);
        return value == null ? 0 : value;
    }

    public Optional<CycleSummary> find(String cycleId) {
        List<CycleSummary> rows = jdbc.query("SELECT * FROM CMS_CYCLE WHERE CYCLE_ID=?", this::map, cycleId);
        return rows.stream().findFirst();
    }

    public List<CycleSummary> recent(int limit) {
        return jdbc.query("SELECT * FROM CMS_CYCLE ORDER BY CREATED_AT DESC LIMIT ?", this::map, limit);
    }

    private CycleSummary map(java.sql.ResultSet rs, int rowNum) throws java.sql.SQLException {
        Timestamp cutoff = rs.getTimestamp("DATA_CUTOFF");
        Timestamp created = rs.getTimestamp("CREATED_AT");
        Timestamp completed = rs.getTimestamp("COMPLETED_AT");
        return new CycleSummary(
                rs.getString("CYCLE_ID"),
                rs.getString("PROCESS_INSTANCE_ID"),
                rs.getString("CYCLE_TYPE"),
                rs.getDate("EFFECTIVE_DATE").toLocalDate(),
                cutoff == null ? null : cutoff.toLocalDateTime(),
                rs.getString("DESCRIPTION"),
                rs.getString("DATA_FILTER_EXPRESSION"),
                rs.getInt("TRANSACTION_COUNT"),
                rs.getInt("BATCH_SIZE"),
                rs.getString("STATUS"),
                rs.getString("CURRENT_STAGE"),
                rs.getString("CREATED_BY"),
                created == null ? null : created.toLocalDateTime(),
                completed == null ? null : completed.toLocalDateTime());
    }
}
