package com.example.cms.domain;

import java.util.Map;

public record RuleBatchItem(String transactionId, Map<String, Object> inputs) {
}
