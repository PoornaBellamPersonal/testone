package com.example.cms.messaging;

import com.example.cms.domain.BatchCommand;
import com.example.cms.service.BatchWorkerService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
public class BatchDltConsumer {

    private static final Logger log = LoggerFactory.getLogger(BatchDltConsumer.class);

    private final ObjectMapper objectMapper;
    private final BatchWorkerService workerService;

    public BatchDltConsumer(ObjectMapper objectMapper, BatchWorkerService workerService) {
        this.objectMapper = objectMapper;
        this.workerService = workerService;
    }

    @KafkaListener(topics = "${cms.kafka.dlt-topic}", groupId = "${cms.kafka.dlt-consumer-group}")
    public void onDlt(String payload) throws Exception {
        BatchCommand command = objectMapper.readValue(payload, BatchCommand.class);
        log.error("Batch {} reached DLT", command.batchId());
        workerService.failPermanently(command, "Kafka retries exhausted; batch moved to DLT");
    }
}
