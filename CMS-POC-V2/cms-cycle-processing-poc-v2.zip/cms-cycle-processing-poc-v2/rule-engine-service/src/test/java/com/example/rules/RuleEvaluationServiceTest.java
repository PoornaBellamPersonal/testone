package com.example.rules;

import com.example.rules.api.RuleBatchItem;
import com.example.rules.api.RuleBatchRequest;
import com.example.rules.api.RuleBatchResponse;
import com.example.rules.engine.CamundaDmnRuleEvaluator;
import com.example.rules.service.RuleEvaluationService;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

class RuleEvaluationServiceTest {

    @Test
    void evaluatesCommissionDmn() {
        CamundaDmnRuleEvaluator evaluator = new CamundaDmnRuleEvaluator(
                "dmn/commission-rules.dmn", "commissionDecision",
                "dmn/tax-rules.dmn", "taxDecision",
                "dmn/aggregate-limit-rules.dmn", "aggregateLimitDecision");
        evaluator.load();
        RuleEvaluationService service = new RuleEvaluationService(evaluator);
        RuleBatchResponse response = service.evaluate(new RuleBatchRequest(
                "B1", "COMMISSION_RULES",
                List.of(new RuleBatchItem("T1", Map.of("channelType", "AGENCY", "amount", new BigDecimal("20000"))))));
        assertThat(response.failed()).isZero();
        assertThat(response.results().getFirst().outputs()).containsKey("commissionAmount");
    }
}
