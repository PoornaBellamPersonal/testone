package com.example.rules.engine;

import jakarta.annotation.PostConstruct;
import org.camunda.bpm.dmn.engine.DmnDecision;
import org.camunda.bpm.dmn.engine.DmnDecisionTableResult;
import org.camunda.bpm.dmn.engine.DmnDecisionRuleResult;
import org.camunda.bpm.dmn.engine.DmnEngine;
import org.camunda.bpm.dmn.engine.DmnEngineConfiguration;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import java.io.InputStream;
import java.util.LinkedHashMap;
import java.util.Map;

@Component
public class CamundaDmnRuleEvaluator implements RuleEvaluator {

    private record DmnLocation(String resource, String decisionKey) {}

    private final DmnEngine engine = DmnEngineConfiguration.createDefaultDmnEngineConfiguration().buildEngine();
    private final Map<String, DmnDecision> decisions = new LinkedHashMap<>();

    private final DmnLocation commission;
    private final DmnLocation tax;
    private final DmnLocation aggregateLimit;

    public CamundaDmnRuleEvaluator(
            @Value("${rule.engine.dmn.commission.resource}") String commissionResource,
            @Value("${rule.engine.dmn.commission.decision-key}") String commissionDecision,
            @Value("${rule.engine.dmn.tax.resource}") String taxResource,
            @Value("${rule.engine.dmn.tax.decision-key}") String taxDecision,
            @Value("${rule.engine.dmn.aggregate-limit.resource}") String limitResource,
            @Value("${rule.engine.dmn.aggregate-limit.decision-key}") String limitDecision) {
        this.commission = new DmnLocation(commissionResource, commissionDecision);
        this.tax = new DmnLocation(taxResource, taxDecision);
        this.aggregateLimit = new DmnLocation(limitResource, limitDecision);
    }

    @PostConstruct
    public void load() {
        decisions.put("COMMISSION_RULES", parse(commission));
        decisions.put("TAX_RULES", parse(tax));
        decisions.put("AGGREGATE_LIMIT_RULES", parse(aggregateLimit));
    }

    @Override
    public boolean supports(String ruleKey) {
        return decisions.containsKey(ruleKey);
    }

    @Override
    public Map<String, Object> evaluate(String ruleKey, Map<String, Object> inputs) {
        DmnDecision decision = decisions.get(ruleKey);
        if (decision == null) {
            throw new IllegalArgumentException("Unknown ruleKey: " + ruleKey);
        }
        DmnDecisionTableResult result = engine.evaluateDecisionTable(decision, inputs);
        if (result.isEmpty()) {
            throw new IllegalStateException("No DMN rule matched for " + ruleKey);
        }
        DmnDecisionRuleResult entry = result.getSingleResult();
        return new LinkedHashMap<>(entry.getEntryMap());
    }

    private DmnDecision parse(DmnLocation location) {
        try (InputStream input = new ClassPathResource(location.resource()).getInputStream()) {
            return engine.parseDecision(location.decisionKey(), input);
        } catch (Exception e) {
            throw new IllegalStateException("Unable to load DMN " + location.resource(), e);
        }
    }
}
