package com.example.rules.api;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.util.Map;

public record RuleBatchItem(@NotBlank String transactionId, @NotNull Map<String, Object> inputs) {}
