package com.example.rules.api;

import java.util.Map;

public record RuleItemResult(
        String transactionId,
        boolean success,
        Map<String, Object> outputs,
        String errorCode,
        String errorMessage) {

    public static RuleItemResult success(String id, Map<String, Object> outputs) {
        return new RuleItemResult(id, true, outputs, null, null);
    }

    public static RuleItemResult failure(String id, String code, String message) {
        return new RuleItemResult(id, false, Map.of(), code, message);
    }
}
