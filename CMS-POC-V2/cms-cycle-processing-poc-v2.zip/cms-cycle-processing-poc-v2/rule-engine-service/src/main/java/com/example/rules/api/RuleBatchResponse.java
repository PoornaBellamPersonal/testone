package com.example.rules.api;

import java.util.List;

public record RuleBatchResponse(
        String batchId,
        String status,
        int total,
        int successful,
        int failed,
        List<RuleItemResult> results) {}
