package com.example.rules.api;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;

import java.util.List;

public record RuleBatchRequest(
        @NotBlank String batchId,
        @NotBlank String ruleKey,
        @NotEmpty List<@Valid RuleBatchItem> items) {}
