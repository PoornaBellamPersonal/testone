package com.example.rules.api;

import com.example.rules.service.RuleEvaluationService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/rules")
public class RuleEvaluationController {

    private final RuleEvaluationService service;

    public RuleEvaluationController(RuleEvaluationService service) {
        this.service = service;
    }

    @PostMapping("/batch/evaluate")
    public RuleBatchResponse evaluate(@Valid @RequestBody RuleBatchRequest request) {
        return service.evaluate(request);
    }
}
