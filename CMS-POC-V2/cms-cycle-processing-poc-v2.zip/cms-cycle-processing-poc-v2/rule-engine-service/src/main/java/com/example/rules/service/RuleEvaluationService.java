package com.example.rules.service;

import com.example.rules.api.*;
import com.example.rules.engine.RuleEvaluator;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
public class RuleEvaluationService {

    private final RuleEvaluator evaluator;

    public RuleEvaluationService(RuleEvaluator evaluator) {
        this.evaluator = evaluator;
    }

    public RuleBatchResponse evaluate(RuleBatchRequest request) {
        if (!evaluator.supports(request.ruleKey())) {
            throw new IllegalArgumentException("Unknown ruleKey: " + request.ruleKey());
        }
        List<RuleItemResult> results = new ArrayList<>(request.items().size());
        int success = 0;
        for (RuleBatchItem item : request.items()) {
            try {
                Map<String, Object> output = evaluator.evaluate(request.ruleKey(), item.inputs());
                results.add(RuleItemResult.success(item.transactionId(), output));
                success++;
            } catch (Exception e) {
                results.add(RuleItemResult.failure(item.transactionId(), "RULE_EVALUATION_ERROR", e.getMessage()));
            }
        }
        int failed = results.size() - success;
        return new RuleBatchResponse(request.batchId(), failed == 0 ? "COMPLETED" : "COMPLETED_WITH_ERRORS",
                results.size(), success, failed, results);
    }
}
