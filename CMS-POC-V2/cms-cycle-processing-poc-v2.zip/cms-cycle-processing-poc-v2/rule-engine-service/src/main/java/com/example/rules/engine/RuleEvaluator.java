package com.example.rules.engine;

import java.util.Map;

public interface RuleEvaluator {
    boolean supports(String ruleKey);
    Map<String, Object> evaluate(String ruleKey, Map<String, Object> inputs);
}
