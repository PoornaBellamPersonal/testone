# local-kafka

A single-node **Apache Kafka 4.3.1 KRaft** launcher for this POC.

It is intentionally a development utility, not a production Kafka deployment.
It needs only JDK 21 and Maven. Docker, ZooKeeper, Git Bash, WSL and a separate
Kafka installation are not required.

## Start

From the repository root:

```bash
mvn -pl local-kafka spring-boot:run
```

Expected endpoints:

- Kafka client/broker: `127.0.0.1:9092`
- KRaft controller: `127.0.0.1:9094`
- CMS H2 remains on `9093`, so there is no port conflict.

The first startup automatically formats KRaft storage. Later startups reuse it.
The local Kafka data is stored under the repository `data/kafka` directory.

## Configuration

Edit:

`local-kafka/src/main/resources/application.properties`

For a completely clean broker on the next run:

```properties
local.kafka.reset-on-start=true
```

Set it back to `false` after the reset.

You can also temporarily override a setting without editing the file:

```bash
mvn -pl local-kafka spring-boot:run \
  -Dspring-boot.run.arguments="--local.kafka.broker-port=19092"
```

or with a JVM system property if passed to the launched JVM.

## Stop

Press `Ctrl+C` in the terminal running the module.
