package com.example.localkafka;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Properties;

/**
 * Small, dependency-light launcher for a single-node Kafka KRaft broker.
 *
 * <p>The wrapper intentionally does not compile against Kafka's internal server
 * classes. Maven puts the Kafka distribution JARs on the runtime classpath, and
 * this launcher uses the same official entry points that Kafka's shell scripts
 * invoke:</p>
 *
 * <ul>
 *   <li>{@code kafka.tools.StorageTool} for first-time storage formatting</li>
 *   <li>{@code kafka.Kafka} for the broker/controller process</li>
 * </ul>
 *
 * <p>This module is for local POC/development use only.</p>
 */
public final class LocalKafkaApplication {

    private static final String RESOURCE = "application.properties";
    private static final String META_PROPERTIES = "meta.properties";

    private LocalKafkaApplication() {
    }

    public static void main(String[] args) throws Exception {
        Properties properties = loadProperties();
        applySystemOverrides(properties);
        applyCommandLineOverrides(properties, args);

        Config config = Config.from(properties);

        printHeader(config);
        validateJava();

        if (config.resetOnStart()) {
            System.out.println("[local-kafka] reset-on-start=true; deleting " + config.dataDir());
            deleteRecursively(config.dataDir());
        }

        Files.createDirectories(config.dataDir());
        Files.createDirectories(config.generatedConfigDir());

        verifyPortAvailable(config.host(), config.brokerPort(), "broker");
        verifyPortAvailable(config.host(), config.controllerPort(), "controller");

        Path serverProperties = config.generatedConfigDir().resolve("server.properties").toAbsolutePath().normalize();
        writeKafkaServerProperties(config, serverProperties);
        ensureFormatted(config, serverProperties);

        startReadinessWatcher(config);

        System.out.println();
        System.out.println("[local-kafka] Starting Apache Kafka in single-node KRaft mode...");
        System.out.println("[local-kafka] Generated Kafka config: " + serverProperties);
        System.out.println("[local-kafka] Stop the broker with Ctrl+C.");
        System.out.println();

        invokeKafkaMain(serverProperties);
    }

    private static Properties loadProperties() throws IOException {
        Properties properties = new Properties();
        try (InputStream input = LocalKafkaApplication.class.getClassLoader().getResourceAsStream(RESOURCE)) {
            if (input == null) {
                throw new IllegalStateException("Could not find " + RESOURCE + " on the classpath");
            }
            properties.load(input);
        }
        return properties;
    }

    /** Allow -Dlocal.kafka.broker-port=... style overrides. */
    private static void applySystemOverrides(Properties properties) {
        System.getProperties().stringPropertyNames().stream()
                .filter(name -> name.startsWith("local.kafka."))
                .forEach(name -> properties.setProperty(name, System.getProperty(name)));
    }

    /** Allow --local.kafka.broker-port=... style overrides. */
    private static void applyCommandLineOverrides(Properties properties, String[] args) {
        for (String arg : args) {
            if (!arg.startsWith("--local.kafka.") || !arg.contains("=")) {
                continue;
            }
            int equals = arg.indexOf('=');
            String key = arg.substring(2, equals);
            String value = arg.substring(equals + 1);
            properties.setProperty(key, value);
        }
    }

    private static void validateJava() {
        int feature = Runtime.version().feature();
        if (feature < 17) {
            throw new IllegalStateException("Kafka 4.x requires Java 17 or newer. Current Java: " + Runtime.version());
        }
    }

    private static void printHeader(Config config) {
        System.out.println();
        System.out.println("============================================================");
        System.out.println(" CMS POC - Local Apache Kafka");
        System.out.println("============================================================");
        System.out.println(" Broker       : " + config.host() + ":" + config.brokerPort());
        System.out.println(" Controller   : " + config.host() + ":" + config.controllerPort());
        System.out.println(" Node ID      : " + config.nodeId());
        System.out.println(" Data dir     : " + config.dataDir());
        System.out.println(" Partitions   : " + config.numPartitions());
        System.out.println(" Java         : " + Runtime.version());
        System.out.println("============================================================");
    }

    private static void verifyPortAvailable(String host, int port, String purpose) throws IOException {
        try (ServerSocket socket = new ServerSocket()) {
            socket.setReuseAddress(false);
            socket.bind(new InetSocketAddress(host, port));
        } catch (IOException e) {
            throw new IllegalStateException(
                    "Kafka " + purpose + " port " + host + ":" + port + " is already in use. " +
                    "Stop the existing process or change application.properties.", e);
        }
    }

    private static void writeKafkaServerProperties(Config config, Path destination) throws IOException {
        Properties kafka = new Properties();

        kafka.setProperty("process.roles", "broker,controller");
        kafka.setProperty("node.id", Integer.toString(config.nodeId()));
        kafka.setProperty("controller.quorum.voters",
                config.nodeId() + "@" + config.host() + ":" + config.controllerPort());

        kafka.setProperty("listeners",
                "PLAINTEXT://" + config.host() + ":" + config.brokerPort() + "," +
                "CONTROLLER://" + config.host() + ":" + config.controllerPort());
        kafka.setProperty("advertised.listeners",
                "PLAINTEXT://" + config.host() + ":" + config.brokerPort());
        kafka.setProperty("listener.security.protocol.map", "CONTROLLER:PLAINTEXT,PLAINTEXT:PLAINTEXT");
        kafka.setProperty("controller.listener.names", "CONTROLLER");
        kafka.setProperty("inter.broker.listener.name", "PLAINTEXT");

        kafka.setProperty("log.dirs", config.dataDir().toAbsolutePath().normalize().toString());
        kafka.setProperty("num.partitions", Integer.toString(config.numPartitions()));
        kafka.setProperty("default.replication.factor", Integer.toString(config.defaultReplicationFactor()));
        kafka.setProperty("offsets.topic.replication.factor", Integer.toString(config.offsetsReplicationFactor()));
        kafka.setProperty("transaction.state.log.replication.factor", Integer.toString(config.transactionReplicationFactor()));
        kafka.setProperty("transaction.state.log.min.isr", Integer.toString(config.transactionMinIsr()));
        kafka.setProperty("group.initial.rebalance.delay.ms", Integer.toString(config.groupInitialRebalanceDelayMs()));
        kafka.setProperty("auto.create.topics.enable", Boolean.toString(config.autoCreateTopics()));
        kafka.setProperty("delete.topic.enable", Boolean.toString(config.deleteTopicEnable()));
        kafka.setProperty("log.retention.hours", Integer.toString(config.logRetentionHours()));

        StringBuilder content = new StringBuilder();
        content.append("# Generated by local-kafka. Do not edit; change application.properties instead.\n");
        kafka.stringPropertyNames().stream().sorted().forEach(name ->
                content.append(name).append('=').append(escapeProperty(kafka.getProperty(name))).append('\n'));

        Files.writeString(destination, content.toString(), StandardCharsets.UTF_8,
                StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
    }

    private static String escapeProperty(String value) {
        // Kafka accepts forward slashes on Windows and this avoids backslash escaping in .properties.
        return value.replace('\\', '/');
    }

    private static void ensureFormatted(Config config, Path serverProperties) throws Exception {
        Path meta = config.dataDir().resolve(META_PROPERTIES);
        if (Files.exists(meta)) {
            verifyExistingNodeId(meta, config.nodeId());
            System.out.println("[local-kafka] Existing KRaft storage found; format step skipped.");
            return;
        }

        System.out.println("[local-kafka] First run detected. Formatting KRaft storage...");
        String clusterId = runAndCapture("kafka.tools.StorageTool", "random-uuid").trim();
        if (clusterId.contains(System.lineSeparator())) {
            String[] lines = clusterId.split("\\R");
            clusterId = lines[lines.length - 1].trim();
        }
        if (clusterId.isBlank()) {
            throw new IllegalStateException("Kafka StorageTool returned an empty cluster id");
        }

        int exit = runInherited(
                "kafka.tools.StorageTool",
                "format",
                "-t", clusterId,
                "-c", serverProperties.toString());
        if (exit != 0) {
            throw new IllegalStateException("Kafka storage formatting failed with exit code " + exit);
        }

        if (!Files.exists(meta)) {
            throw new IllegalStateException("Kafka formatting completed but " + meta + " was not created");
        }
        System.out.println("[local-kafka] KRaft storage formatted. cluster.id=" + clusterId);
    }

    private static void verifyExistingNodeId(Path meta, int expectedNodeId) throws IOException {
        Properties existing = new Properties();
        try (InputStream input = Files.newInputStream(meta)) {
            existing.load(input);
        }
        String actual = existing.getProperty("node.id");
        if (actual != null && !Integer.toString(expectedNodeId).equals(actual.trim())) {
            throw new IllegalStateException(
                    "Existing Kafka storage was formatted for node.id=" + actual +
                    " but application.properties has node.id=" + expectedNodeId + ". " +
                    "Restore the original node id or set local.kafka.reset-on-start=true for a fresh local broker.");
        }
    }

    private static String runAndCapture(String mainClass, String... args) throws Exception {
        List<String> command = javaCommand(mainClass, args);
        Process process = new ProcessBuilder(command)
                .redirectErrorStream(true)
                .start();

        StringBuilder output = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line).append(System.lineSeparator());
            }
        }

        int exit = process.waitFor();
        if (exit != 0) {
            throw new IllegalStateException(
                    "Command failed with exit code " + exit + ": " + mainClass + System.lineSeparator() + output);
        }
        return output.toString();
    }

    private static int runInherited(String mainClass, String... args) throws Exception {
        List<String> command = javaCommand(mainClass, args);
        Process process = new ProcessBuilder(command)
                .inheritIO()
                .start();
        return process.waitFor();
    }

    private static List<String> javaCommand(String mainClass, String... args) {
        String javaHome = System.getProperty("java.home");
        boolean windows = System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win");
        Path java = Path.of(javaHome, "bin", windows ? "java.exe" : "java");

        List<String> command = new ArrayList<>();
        command.add(java.toString());
        command.add("-cp");
        command.add(System.getProperty("java.class.path"));
        command.add(mainClass);
        command.addAll(List.of(args));
        return command;
    }

    private static void startReadinessWatcher(Config config) {
        Thread watcher = new Thread(() -> {
            Instant deadline = Instant.now().plus(Duration.ofSeconds(config.readinessTimeoutSeconds()));
            while (Instant.now().isBefore(deadline)) {
                try (Socket socket = new Socket()) {
                    socket.connect(new InetSocketAddress(config.host(), config.brokerPort()), 500);
                    System.out.println();
                    System.out.println("============================================================");
                    System.out.println(" LOCAL KAFKA BROKER PORT IS READY");
                    System.out.println(" bootstrap.servers=" + config.host() + ":" + config.brokerPort());
                    System.out.println(" CMS already expects localhost:9092 by default.");
                    System.out.println("============================================================");
                    System.out.println();
                    return;
                } catch (IOException ignored) {
                    sleep(500);
                }
            }
            System.err.println("[local-kafka] Broker port did not become reachable within " +
                    config.readinessTimeoutSeconds() + " seconds. Review the Kafka logs above.");
        }, "local-kafka-readiness");
        watcher.setDaemon(true);
        watcher.start();
    }

    private static void invokeKafkaMain(Path serverProperties) throws Exception {
        try {
            Class<?> kafkaMain = Class.forName("kafka.Kafka");
            Method main = kafkaMain.getMethod("main", String[].class);
            main.invoke(null, (Object) new String[]{serverProperties.toString()});
        } catch (ClassNotFoundException e) {
            throw new IllegalStateException(
                    "Kafka server classes were not found. Run this module through Maven so runtime dependencies " +
                    "are on the classpath: mvn -pl local-kafka spring-boot:run", e);
        } catch (InvocationTargetException e) {
            Throwable cause = e.getCause();
            if (cause instanceof Exception exception) {
                throw exception;
            }
            if (cause instanceof Error error) {
                throw error;
            }
            throw e;
        }
    }

    private static void deleteRecursively(Path root) throws IOException {
        if (!Files.exists(root)) {
            return;
        }
        try (var paths = Files.walk(root)) {
            paths.sorted(Comparator.reverseOrder()).forEach(path -> {
                try {
                    Files.deleteIfExists(path);
                } catch (IOException e) {
                    throw new DeleteFailure(e);
                }
            });
        } catch (DeleteFailure e) {
            throw e.ioException;
        }
    }

    private static void sleep(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return;
        }
    }

    private static int requiredInt(Properties p, String key) {
        try {
            return Integer.parseInt(required(p, key));
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException(key + " must be an integer", e);
        }
    }

    private static boolean requiredBoolean(Properties p, String key) {
        String value = required(p, key);
        if (!value.equalsIgnoreCase("true") && !value.equalsIgnoreCase("false")) {
            throw new IllegalArgumentException(key + " must be true or false");
        }
        return Boolean.parseBoolean(value);
    }

    private static String required(Properties p, String key) {
        String value = p.getProperty(key);
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException("Missing property: " + key);
        }
        return value.trim();
    }

    private record Config(
            String host,
            int brokerPort,
            int controllerPort,
            int nodeId,
            Path dataDir,
            Path generatedConfigDir,
            boolean resetOnStart,
            int numPartitions,
            int defaultReplicationFactor,
            int offsetsReplicationFactor,
            int transactionReplicationFactor,
            int transactionMinIsr,
            int groupInitialRebalanceDelayMs,
            boolean autoCreateTopics,
            boolean deleteTopicEnable,
            int logRetentionHours,
            int readinessTimeoutSeconds) {

        static Config from(Properties p) {
            Path base = Path.of(System.getProperty("user.dir"));
            return new Config(
                    required(p, "local.kafka.host"),
                    requiredInt(p, "local.kafka.broker-port"),
                    requiredInt(p, "local.kafka.controller-port"),
                    requiredInt(p, "local.kafka.node-id"),
                    base.resolve(required(p, "local.kafka.data-dir")).normalize(),
                    base.resolve(required(p, "local.kafka.generated-config-dir")).normalize(),
                    requiredBoolean(p, "local.kafka.reset-on-start"),
                    requiredInt(p, "local.kafka.num-partitions"),
                    requiredInt(p, "local.kafka.default-replication-factor"),
                    requiredInt(p, "local.kafka.offsets-topic-replication-factor"),
                    requiredInt(p, "local.kafka.transaction-state-log-replication-factor"),
                    requiredInt(p, "local.kafka.transaction-state-log-min-isr"),
                    requiredInt(p, "local.kafka.group-initial-rebalance-delay-ms"),
                    requiredBoolean(p, "local.kafka.auto-create-topics"),
                    requiredBoolean(p, "local.kafka.delete-topic-enable"),
                    requiredInt(p, "local.kafka.log-retention-hours"),
                    requiredInt(p, "local.kafka.readiness-timeout-seconds"));
        }
    }

    private static final class DeleteFailure extends RuntimeException {
        private final IOException ioException;

        private DeleteFailure(IOException ioException) {
            super(ioException);
            this.ioException = ioException;
        }
    }
}
