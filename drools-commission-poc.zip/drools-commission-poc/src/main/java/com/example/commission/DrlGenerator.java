package com.example.commission;

import java.util.Locale;

public final class DrlGenerator {
    private DrlGenerator() {}

    public static String generatePartitionDrl(int partition, int[] ruleIds) {
        StringBuilder out = new StringBuilder(Math.max(16_384, ruleIds.length * 1_350));
        out.append("package com.example.commission.generated.p").append(partition).append(";\n\n")
           .append("import com.example.commission.CommissionTransaction;\n\n");

        for (int ruleId : ruleIds) {
            appendRule(out, RuleSpec.fromRuleId(ruleId));
        }
        return out.toString();
    }

    private static void appendRule(StringBuilder out, RuleSpec r) {
        out.append("rule \"COMMISSION_").append(r.ruleId()).append("\"\n")
           .append("when\n")
           .append("  $t : CommissionTransaction(\n")
           .append("    carrier == \"").append(r.carrier()).append("\",\n")
           .append("    product == \"").append(r.product()).append("\",\n")
           .append("    state == \"").append(r.state()).append("\",\n")
           .append("    channel == \"").append(r.channel()).append("\",\n")
           .append("    agentType == \"").append(r.agentType()).append("\",\n")
           .append("    registrationType == \"").append(r.registrationType()).append("\",\n")
           .append("    commissionType == \"").append(r.commissionType()).append("\",\n")
           .append("    transactionType == \"").append(r.transactionType()).append("\",\n")
           .append("    policyType == \"").append(r.policyType()).append("\",\n")
           .append("    currency == \"").append(r.currency()).append("\",\n")
           .append("    planCode == \"").append(r.planCode()).append("\",\n")
           .append("    producerLevel == \"").append(r.producerLevel()).append("\",\n")
           .append("    customerSegment == \"").append(r.customerSegment()).append("\",\n")
           .append("    paymentMode == \"").append(r.paymentMode()).append("\",\n")
           .append("    renewal == ").append(r.renewal()).append(",\n")
           .append("    replacement == ").append(r.replacement()).append(",\n")
           .append("    specialProgram == ").append(r.specialProgram()).append(",\n")
           .append("    internalBusiness == ").append(r.internalBusiness()).append(",\n")
           .append("    premium >= ").append(decimal(r.premiumMin())).append(", premium <= ").append(decimal(r.premiumMax())).append(",\n")
           .append("    faceAmount >= ").append(decimal(r.faceAmountMin())).append(", faceAmount <= ").append(decimal(r.faceAmountMax())).append(",\n")
           .append("    productionAmount >= ").append(decimal(r.productionAmountMin())).append(", productionAmount <= ").append(decimal(r.productionAmountMax())).append(",\n")
           .append("    policyDurationMonths >= ").append(r.policyDurationMin()).append(", policyDurationMonths <= ").append(r.policyDurationMax()).append(",\n")
           .append("    issueAge >= ").append(r.issueAgeMin()).append(", issueAge <= ").append(r.issueAgeMax()).append(",\n")
           .append("    effectiveEpochDay >= ").append(r.effectiveEpochDayMin()).append("L, effectiveEpochDay <= ").append(r.effectiveEpochDayMax()).append("L\n")
           .append("  )\n")
           .append("then\n")
           .append("  $t.applyCommission(").append(r.ruleId()).append(", ").append(decimal(r.commissionPercentage())).append(");\n")
           .append("end\n\n");
    }

    private static String decimal(double value) {
        return String.format(Locale.ROOT, "%.6f", value);
    }
}
