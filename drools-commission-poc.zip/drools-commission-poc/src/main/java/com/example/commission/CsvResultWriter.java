package com.example.commission;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.Instant;

public final class CsvResultWriter {
    private CsvResultWriter() {}

    public static void append(Path path, BenchmarkConfig c, PartitionedRuleBases bases, BenchmarkResult r) throws IOException {
        boolean exists = Files.exists(path);
        if (path.toAbsolutePath().getParent() != null) {
            Files.createDirectories(path.toAbsolutePath().getParent());
        }
        StringBuilder out = new StringBuilder();
        if (!exists) {
            out.append("timestamp,rules,transactions,partitions,threads,batch,sequential,executableModel,warmup,missRate,ruleBuildMs,maxPartitionBuildMs,elapsedMs,tps,p50BatchMs,p95BatchMs,p99BatchMs,matched,noMatch,incorrect,heapMB\n");
        }
        out.append(Instant.now()).append(',')
                .append(c.ruleCount()).append(',')
                .append(c.transactionCount()).append(',')
                .append(c.partitions()).append(',')
                .append(c.workerThreads()).append(',')
                .append(c.batchSize()).append(',')
                .append(c.sequential()).append(',')
                .append(c.executableModel()).append(',')
                .append(c.warmupTransactions()).append(',')
                .append(c.missRate()).append(',')
                .append(bases.totalBuildMillis()).append(',')
                .append(bases.maxPartitionBuildMillis()).append(',')
                .append(r.elapsedNanos() / 1_000_000L).append(',')
                .append(String.format(java.util.Locale.ROOT, "%.3f", r.transactionsPerSecond())).append(',')
                .append(String.format(java.util.Locale.ROOT, "%.3f", r.p50BatchMillis())).append(',')
                .append(String.format(java.util.Locale.ROOT, "%.3f", r.p95BatchMillis())).append(',')
                .append(String.format(java.util.Locale.ROOT, "%.3f", r.p99BatchMillis())).append(',')
                .append(r.matched()).append(',')
                .append(r.noMatch()).append(',')
                .append(r.incorrect()).append(',')
                .append(String.format(java.util.Locale.ROOT, "%.1f", r.usedHeapBytesAfterRun() / 1024.0 / 1024.0))
                .append('\n');
        Files.writeString(path, out.toString(), StandardCharsets.UTF_8,
                StandardOpenOption.CREATE, StandardOpenOption.APPEND);
    }
}
