package com.example.commission;

import java.util.List;

public record BenchmarkResult(
        long transactions,
        long matched,
        long noMatch,
        long incorrect,
        long elapsedNanos,
        double transactionsPerSecond,
        double p50BatchMillis,
        double p95BatchMillis,
        double p99BatchMillis,
        long usedHeapBytesAfterRun,
        List<Long> batchNanos
) {}
