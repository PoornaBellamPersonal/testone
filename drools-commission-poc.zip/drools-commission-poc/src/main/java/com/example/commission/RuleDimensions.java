package com.example.commission;

public final class RuleDimensions {
    private RuleDimensions() {}

    public static final String[] CARRIERS = values("CAR", 64);
    public static final String[] PRODUCTS = values("PROD", 64);
    public static final String[] STATES = values("ST", 32);
    public static final String[] CHANNELS = values("CH", 8);
    public static final String[] AGENT_TYPES = values("AG", 8);
    public static final String[] REGISTRATION_TYPES = values("REG", 8);
    public static final String[] COMMISSION_TYPES = values("COMM", 8);
    public static final String[] TRANSACTION_TYPES = values("TXN", 8);
    public static final String[] POLICY_TYPES = values("POL", 8);
    public static final String[] CURRENCIES = values("CUR", 4);
    public static final String[] PLAN_CODES = values("PLAN", 16);
    public static final String[] PRODUCER_LEVELS = values("LEVEL", 8);
    public static final String[] CUSTOMER_SEGMENTS = values("SEG", 8);
    public static final String[] PAYMENT_MODES = values("PAY", 8);

    private static final int[] RADICES = {
            CARRIERS.length,
            PRODUCTS.length,
            STATES.length,
            CHANNELS.length,
            AGENT_TYPES.length,
            REGISTRATION_TYPES.length,
            COMMISSION_TYPES.length,
            TRANSACTION_TYPES.length,
            POLICY_TYPES.length,
            CURRENCIES.length,
            PLAN_CODES.length,
            PRODUCER_LEVELS.length,
            CUSTOMER_SEGMENTS.length,
            PAYMENT_MODES.length
    };

    public static long maxUniqueRuleCount() {
        long product = 1L;
        for (int radix : RADICES) {
            if (product > Long.MAX_VALUE / radix) return Long.MAX_VALUE;
            product *= radix;
        }
        return product;
    }

    public static int[] exactIndexes(int ruleId) {
        int[] indexes = new int[RADICES.length];
        long value = Integer.toUnsignedLong(ruleId);
        for (int i = 0; i < RADICES.length; i++) {
            indexes[i] = (int) (value % RADICES[i]);
            value /= RADICES[i];
        }
        return indexes;
    }

    private static String[] values(String prefix, int count) {
        String[] values = new String[count];
        for (int i = 0; i < count; i++) {
            values[i] = prefix + String.format("%02d", i);
        }
        return values;
    }
}
