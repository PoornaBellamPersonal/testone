package com.example.commission;

import java.time.Duration;

public final class CommissionBenchmarkApp {
    private CommissionBenchmarkApp() {}

    public static void main(String[] args) throws Exception {
        BenchmarkConfig config = BenchmarkConfig.fromArgs(args);
        printConfig(config);

        long buildStarted = System.nanoTime();
        PartitionedRuleBases ruleBases = PartitionedRuleBases.build(config);
        long wallBuildMillis = (System.nanoTime() - buildStarted) / 1_000_000L;

        System.out.printf("%nRule bases ready. Summed partition build time: %,d ms; wall time: %,d ms%n%n",
                ruleBases.totalBuildMillis(), wallBuildMillis);

        BenchmarkRunner runner = new BenchmarkRunner(config, ruleBases);
        runner.warmup();
        System.gc();
        Thread.sleep(500);
        BenchmarkResult result = runner.runMeasured();

        printResult(config, ruleBases, result);
        CsvResultWriter.append(config.csvOutput(), config, ruleBases, result);
        System.out.println("CSV appended to: " + config.csvOutput().toAbsolutePath());

        if (result.incorrect() > 0) {
            throw new IllegalStateException("Correctness failure: " + result.incorrect() + " transactions produced an unexpected result");
        }
    }

    private static void printConfig(BenchmarkConfig c) {
        System.out.println("============================================================");
        System.out.println(" Drools Commission Performance POC");
        System.out.println("============================================================");
        System.out.printf("Rules             : %,d%n", c.ruleCount());
        System.out.printf("Transactions      : %,d%n", c.transactionCount());
        System.out.printf("Input columns     : 24%n");
        System.out.printf("Partitions        : %d%n", c.partitions());
        System.out.printf("Worker threads    : %d%n", c.workerThreads());
        System.out.printf("Batch size        : %,d%n", c.batchSize());
        System.out.printf("Sequential mode   : %s%n", c.sequential());
        System.out.printf("Executable model  : %s%n", c.executableModel());
        System.out.printf("Warmup tx         : %,d%n", c.warmupTransactions());
        System.out.printf("Miss rate         : %.2f%%%n", c.missRate() * 100.0);
        System.out.println("============================================================\n");
    }

    private static void printResult(BenchmarkConfig c, PartitionedRuleBases bases, BenchmarkResult r) {
        double elapsedSeconds = r.elapsedNanos() / 1_000_000_000.0;
        Duration projected2m = Duration.ofMillis(Math.round((2_000_000.0 / r.transactionsPerSecond()) * 1000.0));
        System.out.println("\n====================== RESULT ==============================");
        System.out.printf("Rule build time       : %,d ms%n", bases.totalBuildMillis());
        System.out.printf("Max partition build   : %,d ms%n", bases.maxPartitionBuildMillis());
        System.out.printf("Processing elapsed    : %.3f s%n", elapsedSeconds);
        System.out.printf("Throughput            : %,.2f tx/s%n", r.transactionsPerSecond());
        System.out.printf("Batch p50             : %,.3f ms%n", r.p50BatchMillis());
        System.out.printf("Batch p95             : %,.3f ms%n", r.p95BatchMillis());
        System.out.printf("Batch p99             : %,.3f ms%n", r.p99BatchMillis());
        System.out.printf("Matched               : %,d%n", r.matched());
        System.out.printf("Expected no-match     : %,d%n", r.noMatch());
        System.out.printf("Incorrect             : %,d%n", r.incorrect());
        System.out.printf("Used heap after run   : %,.1f MB%n", r.usedHeapBytesAfterRun() / 1024.0 / 1024.0);
        System.out.printf("Projected 2M duration : %s%n", formatDuration(projected2m));
        System.out.printf("2-hour target margin  : %.1fx%n", r.transactionsPerSecond() / (2_000_000.0 / 7200.0));
        System.out.println("============================================================");

        if (c.transactionCount() < 2_000_000) {
            System.out.println("Note: projection is indicative only. Run the full 2M profile before drawing conclusions.");
        }
    }

    private static String formatDuration(Duration d) {
        long seconds = d.toSeconds();
        long h = seconds / 3600;
        long m = (seconds % 3600) / 60;
        long s = seconds % 60;
        return "%02d:%02d:%02d".formatted(h, m, s);
    }
}
