package com.example.commission;

import org.drools.model.codegen.ExecutableModelProject;
import org.kie.api.KieBase;
import org.kie.api.KieBaseConfiguration;
import org.kie.api.KieServices;
import org.kie.api.conf.SequentialOption;
import org.kie.api.io.ResourceType;
import org.kie.internal.utils.KieHelper;

import java.util.Arrays;

public final class PartitionedRuleBases {
    private final KieBase[] bases;
    private final int[][] ruleIdsByPartition;
    private final long[] buildMillis;

    private PartitionedRuleBases(KieBase[] bases, int[][] ruleIdsByPartition, long[] buildMillis) {
        this.bases = bases;
        this.ruleIdsByPartition = ruleIdsByPartition;
        this.buildMillis = buildMillis;
    }

    public static PartitionedRuleBases build(BenchmarkConfig config) {
        int[][] ruleIdsByPartition = partitionRuleIds(config.ruleCount(), config.partitions());
        KieBase[] bases = new KieBase[config.partitions()];
        long[] buildMillis = new long[config.partitions()];
        KieServices services = KieServices.Factory.get();

        for (int partition = 0; partition < config.partitions(); partition++) {
            int[] ids = ruleIdsByPartition[partition];
            if (ids.length == 0) continue;

            System.out.printf("Building partition %d/%d (%d rules)%n",
                    partition + 1, config.partitions(), ids.length);
            long started = System.nanoTime();

            String drl = DrlGenerator.generatePartitionDrl(partition, ids);
            KieBaseConfiguration baseConfig = services.newKieBaseConfiguration();
            baseConfig.setOption(config.sequential() ? SequentialOption.YES : SequentialOption.NO);

            KieHelper helper = new KieHelper()
                    .setClassLoader(CommissionTransaction.class.getClassLoader())
                    .addContent(drl, ResourceType.DRL);

            KieBase base = config.executableModel()
                    ? helper.build(ExecutableModelProject.class, baseConfig)
                    : helper.build(baseConfig);

            bases[partition] = base;
            buildMillis[partition] = (System.nanoTime() - started) / 1_000_000L;
            System.out.printf("  built in %,d ms%n", buildMillis[partition]);
        }
        return new PartitionedRuleBases(bases, ruleIdsByPartition, buildMillis);
    }

    public KieBase base(int partition) { return bases[partition]; }
    public int[] ruleIds(int partition) { return ruleIdsByPartition[partition]; }
    public long totalBuildMillis() { return Arrays.stream(buildMillis).sum(); }
    public long maxPartitionBuildMillis() { return Arrays.stream(buildMillis).max().orElse(0L); }
    public int partitionCount() { return bases.length; }

    private static int[][] partitionRuleIds(int ruleCount, int partitions) {
        int[] counts = new int[partitions];
        for (int id = 0; id < ruleCount; id++) {
            int p = RuleSpec.fromRuleId(id).partition(partitions);
            counts[p]++;
        }
        int[][] ids = new int[partitions][];
        for (int p = 0; p < partitions; p++) ids[p] = new int[counts[p]];
        Arrays.fill(counts, 0);
        for (int id = 0; id < ruleCount; id++) {
            int p = RuleSpec.fromRuleId(id).partition(partitions);
            ids[p][counts[p]++] = id;
        }
        return ids;
    }
}
