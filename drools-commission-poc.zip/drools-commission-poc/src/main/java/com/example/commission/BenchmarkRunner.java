package com.example.commission;

import org.kie.api.KieBase;
import org.kie.api.runtime.StatelessKieSession;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.SplittableRandom;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public final class BenchmarkRunner {
    private final BenchmarkConfig config;
    private final PartitionedRuleBases ruleBases;

    public BenchmarkRunner(BenchmarkConfig config, PartitionedRuleBases ruleBases) {
        this.config = config;
        this.ruleBases = ruleBases;
    }

    public void warmup() throws Exception {
        if (config.warmupTransactions() == 0) return;
        long warmupCount = Math.min(config.warmupTransactions(), config.transactionCount());
        System.out.printf("Warmup: %,d transactions%n", warmupCount);
        runInternal(warmupCount, config.seed() ^ 0x9E3779B97F4A7C15L, false);
    }

    public BenchmarkResult runMeasured() throws Exception {
        System.out.printf("Measured run: %,d transactions%n", config.transactionCount());
        return runInternal(config.transactionCount(), config.seed(), true);
    }

    private BenchmarkResult runInternal(long totalTransactions, long seed, boolean collectMetrics) throws Exception {
        ExecutorService pool = Executors.newFixedThreadPool(config.workerThreads());
        try {
            List<Callable<BatchResult>> tasks = createTasks(totalTransactions, seed);
            long started = System.nanoTime();
            List<Future<BatchResult>> futures = pool.invokeAll(tasks);

            long matched = 0;
            long noMatch = 0;
            long incorrect = 0;
            List<Long> batchNanos = collectMetrics ? new ArrayList<>(futures.size()) : Collections.emptyList();

            for (Future<BatchResult> f : futures) {
                BatchResult r;
                try {
                    r = f.get();
                } catch (ExecutionException e) {
                    Throwable cause = e.getCause();
                    if (cause instanceof Exception ex) throw ex;
                    throw new RuntimeException(cause);
                }
                matched += r.matched();
                noMatch += r.noMatch();
                incorrect += r.incorrect();
                if (collectMetrics) batchNanos.add(r.elapsedNanos());
            }

            long elapsed = System.nanoTime() - started;
            if (!collectMetrics) {
                return new BenchmarkResult(totalTransactions, matched, noMatch, incorrect, elapsed,
                        totalTransactions / (elapsed / 1_000_000_000.0), 0, 0, 0, usedHeap(), List.of());
            }

            Collections.sort(batchNanos);
            return new BenchmarkResult(
                    totalTransactions,
                    matched,
                    noMatch,
                    incorrect,
                    elapsed,
                    totalTransactions / (elapsed / 1_000_000_000.0),
                    percentileMillis(batchNanos, 0.50),
                    percentileMillis(batchNanos, 0.95),
                    percentileMillis(batchNanos, 0.99),
                    usedHeap(),
                    List.copyOf(batchNanos)
            );
        } finally {
            pool.shutdownNow();
        }
    }

    private List<Callable<BatchResult>> createTasks(long totalTransactions, long seed) {
        List<Callable<BatchResult>> tasks = new ArrayList<>();
        int activePartitions = 0;
        for (int p = 0; p < ruleBases.partitionCount(); p++) {
            if (ruleBases.ruleIds(p).length > 0) activePartitions++;
        }

        long basePerPartition = totalTransactions / activePartitions;
        long remainder = totalTransactions % activePartitions;
        int activeIndex = 0;
        long transactionIdBase = 0;

        for (int partition = 0; partition < ruleBases.partitionCount(); partition++) {
            if (ruleBases.ruleIds(partition).length == 0) continue;
            long partitionTransactions = basePerPartition + (activeIndex < remainder ? 1 : 0);
            long partitionTxStart = transactionIdBase;
            transactionIdBase += partitionTransactions;
            activeIndex++;

            long offset = 0;
            int batchIndex = 0;
            while (offset < partitionTransactions) {
                int size = (int) Math.min(config.batchSize(), partitionTransactions - offset);
                long batchTxStart = partitionTxStart + offset;
                long batchSeed = mix64(seed ^ ((long) partition << 32) ^ batchIndex);
                int p = partition;
                tasks.add(() -> executeBatch(p, batchTxStart, size, batchSeed));
                offset += size;
                batchIndex++;
            }
        }
        return tasks;
    }

    private BatchResult executeBatch(int partition, long transactionIdStart, int size, long seed) {
        KieBase base = ruleBases.base(partition);
        int[] ruleIds = ruleBases.ruleIds(partition);
        SplittableRandom random = new SplittableRandom(seed);
        List<CommissionTransaction> batch = new ArrayList<>(size);

        for (int i = 0; i < size; i++) {
            int ruleId = ruleIds[random.nextInt(ruleIds.length)];
            long txId = transactionIdStart + i;
            boolean miss = config.missRate() > 0.0 && random.nextDouble() < config.missRate();
            batch.add(miss
                    ? TransactionFactory.nonMatching(txId, ruleId)
                    : TransactionFactory.matching(txId, ruleId));
        }

        StatelessKieSession session = base.newStatelessKieSession();
        long started = System.nanoTime();
        session.execute(batch);
        long elapsed = System.nanoTime() - started;

        int matched = 0;
        int noMatch = 0;
        int incorrect = 0;
        for (CommissionTransaction tx : batch) {
            if (tx.getExpectedRuleId() < 0) {
                if (tx.getMatchedRuleId() == -1) noMatch++;
                else incorrect++;
            } else if (tx.getMatchedRuleId() == tx.getExpectedRuleId()) {
                matched++;
            } else {
                incorrect++;
            }
        }
        return new BatchResult(size, matched, noMatch, incorrect, elapsed);
    }

    private static double percentileMillis(List<Long> values, double quantile) {
        if (values.isEmpty()) return 0.0;
        int index = (int) Math.ceil(quantile * values.size()) - 1;
        index = Math.max(0, Math.min(values.size() - 1, index));
        return values.get(index) / 1_000_000.0;
    }

    private static long usedHeap() {
        Runtime rt = Runtime.getRuntime();
        return rt.totalMemory() - rt.freeMemory();
    }

    private static long mix64(long z) {
        z = (z ^ (z >>> 30)) * 0xbf58476d1ce4e5b9L;
        z = (z ^ (z >>> 27)) * 0x94d049bb133111ebL;
        return z ^ (z >>> 31);
    }
}
