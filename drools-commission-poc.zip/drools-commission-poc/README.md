# Drools Commission Performance POC

A focused benchmark for the requirement:

- up to **200,000 commission rules**
- **24 business input columns** per rule
- **2,000,000+ transactions**
- target completion under **2 hours**

This POC deliberately avoids Camunda/DMN. It tests Drools as the rule-matching runtime.

## Architecture being tested

1. Rules are generated deterministically with 24 conditions.
2. Rules are partitioned by carrier so no transaction is sent to one global 200K-rule KieBase.
3. Each partition is compiled into its own KieBase.
4. The Drools executable model is enabled by default.
5. Stateless sessions process transaction **batches**, not one session per transaction.
6. Multiple partition/batch tasks run concurrently.
7. Every generated matching transaction knows its expected rule id, so the benchmark verifies correctness as well as speed.

The 24 input columns are:

1. carrier
2. product
3. state
4. channel
5. agentType
6. registrationType
7. commissionType
8. transactionType
9. policyType
10. currency
11. planCode
12. producerLevel
13. customerSegment
14. paymentMode
15. renewal
16. replacement
17. specialProgram
18. internalBusiness
19. premium (range)
20. faceAmount (range)
21. productionAmount (range)
22. policyDurationMonths (range)
23. issueAge (range)
24. effectiveEpochDay (range)

## Prerequisites

- JDK 21 recommended (Drools 10 requires JDK 17+)
- Maven 3.8.6+
- Enough heap for larger rule compilation runs

Check:

```bash
java -version
mvn -version
```

## Start with the smoke test

Windows:

```bat
scripts\run-smoke.bat
```

Linux/macOS:

```bash
./scripts/run-smoke.sh
```

Default smoke profile:

- 5,000 rules
- 50,000 transactions
- 8 rule partitions
- 4 worker threads
- 5,000 transactions per Drools batch

## Progressively scale

Windows:

```bat
scripts\run-medium.bat
scripts\run-target.bat
```

Target profile:

```text
rules          = 200,000
transactions   = 2,000,000
partitions     = 32
threads        = 16
batch          = 5,000
sequential     = true
executable     = true
warmup         = 50,000
```

The target script uses a large Maven JVM heap because runtime rule compilation is intentionally part of this first POC.

## Compare sequential vs normal PHREAK mode

```bat
scripts\run-compare-modes.bat
```

This is important because this commission use case does not rely on a rule modifying a fact and thereby enabling another rule. Sequential stateless mode may therefore be a good fit, but it must be measured rather than assumed.

## Manual command

```bash
mvn -DskipTests compile exec:java -Dexec.args="--rules=50000 --transactions=500000 --partitions=16 --threads=8 --batch=5000 --sequential=true --executable-model=true --warmup=20000 --miss-rate=0 --csv=benchmark-results.csv"
```

Available arguments:

| Argument | Default | Meaning |
|---|---:|---|
| `--rules` | 5000 | Total generated rules |
| `--transactions` | 50000 | Measured transaction count |
| `--partitions` | 8 | Number of KieBases; max 64 in this generator |
| `--threads` | up to 8 | Outer application worker threads |
| `--batch` | 5000 | Facts inserted into one stateless execution |
| `--sequential` | true | Drools sequential mode |
| `--executable-model` | true | Build the executable model |
| `--warmup` | 10000 | Warmup transactions |
| `--miss-rate` | 0.0 | Fraction deliberately created with no matching rule |
| `--seed` | 42 | Deterministic workload seed |
| `--csv` | benchmark-results.csv | CSV history file |

## Metrics

The console and CSV report:

- rule compilation/build time
- processing wall-clock time
- transactions/second
- batch p50 / p95 / p99
- matched transactions
- expected no-match transactions
- incorrect results
- heap used after measured run
- projected duration for 2M records
- speed margin relative to the two-hour requirement

## Interpretation

The minimum throughput for 2M records in two hours is only about **278 tx/s**. Do not use that as the design target. For the POC, a useful target is at least several thousand transactions/second so database I/O, audit persistence, retries and growth have substantial headroom.

Rule **build time** and rule **execution time** are deliberately reported separately. A runtime that processes transactions quickly but takes an unacceptable amount of time/memory to compile 200K rules still needs architectural work.

## Important limitations of POC 1

- Synthetic rules are deliberately deterministic and have one expected matching rule per normal transaction.
- It does not include Oracle reads/writes yet.
- It does not include business-rule authoring/import yet.
- It does not model overlapping rules, priority/salience or multiple-hit policies yet.
- Rule bases are built at runtime for measurement; production should normally precompile/version rule artifacts and swap immutable versions.

## Planned POC 2 improvements if Drools is promising

1. Import realistic commission rows from CSV/Excel/database.
2. Add wildcard/ANY conditions.
3. Add rule priority and override behavior.
4. Measure different partition keys automatically.
5. Separate precompiled rule artifact startup from runtime evaluation.
6. Add Oracle bulk-read and bulk-write timing.
7. Compare batch sizes and thread counts systematically.
8. Compare against an indexed custom matcher using the exact same test dataset.
