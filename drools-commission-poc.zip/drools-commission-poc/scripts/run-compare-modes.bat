@echo off
setlocal
set MAVEN_OPTS=-Xms4g -Xmx10g -XX:+UseG1GC

echo === Sequential + executable model ===
mvn -q -DskipTests compile exec:java -Dexec.args="--rules=50000 --transactions=500000 --partitions=16 --threads=8 --batch=5000 --sequential=true --executable-model=true --warmup=20000 --csv=benchmark-results.csv"

echo === Normal PHREAK + executable model ===
mvn -q -DskipTests compile exec:java -Dexec.args="--rules=50000 --transactions=500000 --partitions=16 --threads=8 --batch=5000 --sequential=false --executable-model=true --warmup=20000 --csv=benchmark-results.csv"
endlocal
