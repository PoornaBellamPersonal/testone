#!/usr/bin/env bash
set -euo pipefail
export MAVEN_OPTS="-Xms2g -Xmx6g -XX:+UseG1GC"
mvn -q -DskipTests compile exec:java \
  -Dexec.args="--rules=5000 --transactions=50000 --partitions=8 --threads=4 --batch=5000 --sequential=true --executable-model=true --warmup=10000 --csv=benchmark-results.csv"
