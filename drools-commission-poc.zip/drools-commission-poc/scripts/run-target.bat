@echo off
setlocal
REM Intended for a 32 GB development machine. Adjust -Xmx if required.
set MAVEN_OPTS=-Xms8g -Xmx20g -XX:+UseG1GC -XX:+HeapDumpOnOutOfMemoryError
mvn -q -DskipTests compile exec:java -Dexec.args="--rules=200000 --transactions=2000000 --partitions=32 --threads=16 --batch=5000 --sequential=true --executable-model=true --warmup=50000 --csv=benchmark-results.csv"
endlocal
