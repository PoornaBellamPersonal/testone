#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
export MAVEN_OPTS="-Xms512m -Xmx4g -XX:+UseG1GC"
mvn spring-boot:run
