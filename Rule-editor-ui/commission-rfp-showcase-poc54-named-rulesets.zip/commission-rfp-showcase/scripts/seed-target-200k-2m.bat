@echo off
setlocal
pushd "%~dp0.."
if exist "%~dp0java21-env.bat" call "%~dp0java21-env.bat"
set MAVEN_OPTS=-Xms2g -Xmx8g -XX:+UseG1GC
mvn -q spring-boot:run -Dspring-boot.run.arguments="--spring.main.web-application-type=none --rfp.demo.seed-profile=target --rfp.demo.reset=true --rfp.demo.exit-after-seed=true"
popd
endlocal
