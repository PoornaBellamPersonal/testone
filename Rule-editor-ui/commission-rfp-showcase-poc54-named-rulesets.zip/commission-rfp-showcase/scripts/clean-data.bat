@echo off
pushd "%~dp0.."
echo Deleting generated H2 data...
if exist data\rfp-showcase.mv.db del /q data\rfp-showcase.mv.db
if exist data\rfp-showcase.trace.db del /q data\rfp-showcase.trace.db
popd
