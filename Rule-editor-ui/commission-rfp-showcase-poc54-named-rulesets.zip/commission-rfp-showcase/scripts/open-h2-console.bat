@echo off
echo Start the showcase with scripts\run-showcase.bat, then open:
echo http://localhost:8080/h2-console
echo.
echo JDBC URL: jdbc:h2:file:./data/rfp-showcase
echo User: sa
echo Password: ^<blank^>
