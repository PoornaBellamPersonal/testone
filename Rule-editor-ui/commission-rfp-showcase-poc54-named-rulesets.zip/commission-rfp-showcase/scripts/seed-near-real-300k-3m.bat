@echo off
setlocal
pushd "%~dp0.."
if exist "%~dp0java21-env.bat" call "%~dp0java21-env.bat"
echo ============================================================
echo  Near-real RFP target dataset
echo  300 attributes / 300,000 rules / 3,000,000 transactions
echo ============================================================
echo This can create a multi-GB H2 database. Ensure enough free disk space.
echo Stop the showcase application before continuing.
echo.
set MAVEN_OPTS=-Xms3g -Xmx12g -XX:+UseG1GC
mvn -q spring-boot:run -Dspring-boot.run.arguments="--spring.main.web-application-type=none --rfp.demo.seed-profile=nearreal-target --rfp.demo.reset=true --rfp.demo.exit-after-seed=true"
popd
endlocal
