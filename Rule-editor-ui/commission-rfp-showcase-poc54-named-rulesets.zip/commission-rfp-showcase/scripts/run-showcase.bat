@echo off
setlocal
pushd "%~dp0.."
if exist "%~dp0java21-env.bat" call "%~dp0java21-env.bat"
set MAVEN_OPTS=-Xms512m -Xmx4g -XX:+UseG1GC
mvn spring-boot:run
popd
endlocal
