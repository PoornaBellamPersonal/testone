@echo off
setlocal
curl -s -X POST "http://localhost:8080/api/v1/rule-sets/TAX_RULES/evaluate-batch" ^
  -H "Content-Type: application/json" ^
  -d "{\"batchId\":\"DEMO-BATCH-001\",\"transactions\":[{\"transactionId\":\"TX-DEMO-1\",\"attributes\":{\"ISSUE_STATE\":\"CA\",\"TRANSACTION_TYPE\":\"NEW_BUSINESS\"}},{\"transactionId\":\"TX-DEMO-2\",\"attributes\":{\"ISSUE_STATE\":\"TX\",\"TRANSACTION_TYPE\":\"ADJUSTMENT\"}}]}"
echo.
endlocal
