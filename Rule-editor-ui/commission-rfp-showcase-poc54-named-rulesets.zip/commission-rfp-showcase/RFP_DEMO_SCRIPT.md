# RFP Client Demo Script — POC #5.3

## Before the meeting

Use the already-seeded near-real target data if available:

- 300 dynamic attributes
- 300,000 sparse rules
- 3,000,000 transactions

Start with:

```bat
scripts\run-showcase-large.bat
```

Open `http://localhost:8080/`.

## 1. Dashboard — 1 minute

Show scale, latest execution, throughput, zero incorrect outcomes, and SLA headroom.

Message: **business configuration, performance evidence and decision audit are all visible in one RFP application.**

## 2. Attribute / Parameter Management — 2 minutes

Open **Attributes / Parameters**.

- Search the 300-column metadata dictionary.
- Click **Add Attribute**.
- Add `CAMPAIGN_PROPENSITY_SCORE` as DECIMAL.

Message: **a new monthly business column does not require a Java field, DRL change or rule-table schema change.**

## 3. Business Rule Composer — 3 minutes

Open **Compose Rule**.

Demonstrate:

- type/search an attribute code
- operator list changes based on metadata
- add/remove conditions dynamically
- use `IN` for several states
- use `BETWEEN` for premium
- use the newly added attribute
- watch the business-readable preview update
- validate and save the rule

Message: **business users compose sparse rules, not technical expressions.**

## 4. Test & Explain — 2 minutes

Open **Test & Explain** and submit a small transaction.

Show:

- commission outcome
- winning rule
- candidate count
- matched rule count
- priority / specificity
- latency
- condition-by-condition explanation

## 5. Decision Audit — 3 minutes

Open **Decision Audit** and choose a completed run with persisted results.

- Search a transaction or pick one from the table.
- Click **Explain**.
- Show the persisted batch result.
- Show all rules that survived indexed candidate reduction.
- Expand a candidate to see expected vs actual values.
- Point out why a matched rule lost on priority/specificity or why a rejected rule failed.

Message: **we explain not only why a rule won, but also why alternatives did not.**

## 6. Decision Insights — 1 minute

Show matched, no-match, ambiguous and incorrect counts plus sample drill-down.

Message: **operational teams can investigate coverage gaps and overlapping rules.**

## 7. Performance Metrics — 2 minutes

Open the completed benchmark execution.

Show:

- 300K rules / 3M transactions
- worker count and throughput
- DB read / engine / DB write metrics
- average candidate count
- heap
- zero incorrect outcomes
- 2-hour SLA headroom

## 8. Architecture — 1 minute

Close with:

```text
metadata
  -> sparse business rules
  -> compact indexes
  -> ~5 candidates
  -> deterministic winner
  -> persisted result audit
  -> on-demand explainability
```

## Scope statement if asked

The RFP POC deliberately does not invent final nested AND/OR semantics, maker/checker workflow, SSO/RBAC or BPMN stages before the client business-requirement documents are reviewed.
