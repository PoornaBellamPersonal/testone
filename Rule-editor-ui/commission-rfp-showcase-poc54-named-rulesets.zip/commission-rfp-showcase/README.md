# Commission Rules RFP Showcase — POC #5.3

A single Spring Boot + Thymeleaf application focused on the commission-processing RFP.

POC #5.3 keeps the proven near-real scalable engine and adds a **client-facing business UI and decision-audit layer** for:

- **300 metadata-driven attributes**
- **300,000 sparse commission rules**
- **3,000,000 persisted transactions**
- monthly attribute evolution without Java/model changes
- metrics-enabled end-to-end batch execution
- professional Thymeleaf rule-management UI
- transaction-level persisted decision audit
- on-demand candidate-rule explainability
- no-match and ambiguity insights

## Technology

- JDK 21
- Spring Boot 3.5.16
- Spring MVC + Thymeleaf
- Spring JDBC
- file-based H2
- Micrometer / Actuator
- custom metadata-driven `SparseIndexedCommissionEngine`

No React build or external UI runtime is required for the RFP demo.

## What this version proves

- Registered attributes are metadata rather than Java fields.
- A rule stores only the conditions it actually uses.
- New monthly attributes can be added through the UI without changing the engine schema or Java model.
- High-cardinality equality values use compact posting lists rather than one full bitmap per distinct value.
- The rule repository can contain hundreds of thousands of sparse rules with millions of condition rows.
- Deterministic winner policy is **priority > specificity > lowest rule ID**.
- H2 stores attributes, rule versions, sparse conditions, transactions, execution metrics and optional detailed results.
- The Thymeleaf UI demonstrates rule maintenance, explainability, benchmark execution and management/architecture metrics.

## Near-real business attribute catalog

The generator registers 300 named insurance/commission attributes rather than `ATTR_001`-style placeholders. Domains include:

- policy
- product
- transaction
- producer
- distribution
- customer
- compensation
- contract
- compliance

Examples include `CARRIER_CODE`, `PRODUCT_FAMILY`, `ISSUE_STATE`, `ANNUAL_PREMIUM`, `PRODUCER_LEVEL`, `COMPENSATION_PROGRAM_CODE`, `PRODUCTION_YTD`, `POLICY_FACE_AMOUNT`, `CUSTOMER_RISK_BAND`, `COMPENSATION_BONUS_RATE`, and `COMPLIANCE_SUITABILITY_STATUS`.

See `samples/near-real-attributes-300.csv` for the complete metadata catalog.

## Sparse rule shape

A near-real exact rule uses about 20 conditions. Its competing wildcard/fallback variants use fewer conditions, resulting in roughly **12 conditions per rule on average** across the generated rule population.

Example:

```text
Product Family          = TERM_LIFE
Issue State             = TX
Distribution Channel    = CAREER_AGENCY
Producer Level          = GOLD
Registration Type       = REGISTERED
Transaction Type        = NEW_BUSINESS
Annual Premium          BETWEEN 100000 AND 149999
Effective Date          BETWEEN 2026-08-01 AND 2026-08-31
Compensation Program    = COMP-012345
Production YTD          BETWEEN 1000000 AND 1499999
... selected dynamic attributes ...

Commission              = 3.25%
Priority                = 100
```

The other registered attributes are implicitly `ANY` for that rule.

## Transaction representation

`TRANSACTION_RECORD.ATTRIBUTES_PAYLOAD` is a compact dynamic projection:

```text
attributeId=value|attributeId=value|...
```

The near-real target has **300 available attributes**, while each generated transaction contains its rule-relevant values plus approximately 32 additional business values by default. This models a wide source record where many columns can be null or irrelevant to the active rules, while avoiding a 900-million-row EAV transaction table.

You can make transaction payloads denser by overriding:

```text
--rfp.demo.tx-extra-attributes=80
```

Be aware that increasing transaction density can materially increase H2 disk usage for 3M records.

## Data profiles

### Existing quick profile

```bat
scripts\seed-quick.bat
```

- 220 attributes
- 5K rules
- 50K transactions

### Near-real smoke

```bat
scripts\seed-near-real-smoke.bat
```

- 300 attributes
- 30K rules
- 100K transactions

### Near-real medium

```bat
scripts\seed-near-real-medium.bat
```

- 300 attributes
- 100K rules
- 500K transactions

### Near-real RFP target

Stop the web application first, then run:

```bat
scripts\seed-near-real-300k-3m.bat
```

This creates:

- **300 attributes**
- **300,000 rule rows**
- **60,000 logical commission programs**
- roughly **3.6M+ sparse rule-condition rows**
- **3,000,000 transactions**
- ~3% deliberate no-match transactions
- geography/distribution wildcards
- broad range rules
- priority overrides
- exact-rank ties for ambiguity metrics
- moderate partition skew

Then start the UI with the larger heap profile:

```bat
scripts\run-showcase-large.bat
```

Open:

```text
http://localhost:8080/
```

## Recommended run sequence

Do not go directly to the 300K/3M profile on a new machine. Use:

```text
near-real smoke
    ↓
near-real medium
    ↓
near-real 300K / 3M
```

For the 3M run, confirm adequate free disk space first. File-based H2 can grow to multiple GB depending on payload density and whether detailed execution results are persisted.

## Benchmark modes

On **Batch Execution** choose:

- Workers: start with `8`
- Batch size: start with `5000`
- Persist detailed results:
  - `No` for the cleanest engine/DB-read throughput benchmark
  - `Yes` for a full audit-result persistence benchmark

For the RFP, capture both once the dataset is stable.

## Metrics captured

Each execution records:

- rule count
- registered / active attributes
- transaction count
- processed / matched / no-match / ambiguous / incorrect
- average and max candidates
- engine compile/load time
- cumulative database read time
- cumulative engine evaluation time
- cumulative database write time
- processing and total wall times
- throughput
- heap after engine initialization
- SLA target/headroom

## Dynamic monthly attribute demonstration

After seeding the 300K/3M dataset:

1. Open **Attributes**.
2. Add a new attribute such as `CAMPAIGN_PROPENSITY_SCORE`.
3. Open **Create Rule** and use the new attribute.
4. Open **Test / Explain** and evaluate a matching transaction.

No Java property, rule-table column, or application recompilation is needed.

## UI pages

| Page | Purpose |
|---|---|
| `/` | Management dashboard and client-demo quick actions |
| `/attributes` | Searchable dynamic attribute / parameter registry |
| `/rules` | Paginated business rule explorer + CSV import/export |
| `/rules/new` | Dynamic business rule composer with metadata-driven operators and preview |
| `/tester` | Single-transaction simulation + winning-rule explanation |
| `/executions` | Benchmark execution/history |
| `/executions/{id}` | Live/final execution metrics + audit link |
| `/audit` | Search every persisted transaction decision |
| `/audit/{runId}/{transactionId}` | Candidate-rule and condition-level explanation |
| `/insights` | Match/no-match/ambiguity decision quality view |
| `/versions` | Monthly rule-set versions |
| `/architecture` | Architect-facing design |
| `/h2-console` | POC database inspection |

### Audit design

For a persisted batch, one compact `EXECUTION_RESULT` row is stored for every transaction. Candidate/condition details are reconstructed only when a user opens a particular transaction explanation. This keeps the 3M-result benchmark practical while still demonstrating why the winning rule was selected and why competing candidates were rejected.

## Java 21 without changing system JDK 17

The new BAT files automatically call `scripts\java21-env.bat` if that file exists.

Copy:

```text
scripts\java21-env.bat.example
```

to:

```text
scripts\java21-env.bat
```

and set your extracted JDK 21 path there.

## Disk cleanup

Stop the application and run:

```bat
scripts\clean-data.bat
mvn clean
```

For a large target dataset, deleting the H2 database file is the quickest way to reclaim all benchmark space.

## Scope intentionally deferred until the business documents are reviewed

- exact BPMN evaluation stages and rule-set boundaries
- final business terminology and formulas
- maker/checker workflow
- Oracle-specific tuning
- SSO/RBAC
- complex chained-rule adapter (Drools or another engine)
- multi-node execution

The incoming business-requirements documents should determine the final BPMN stages and rule-set boundaries rather than having the POC invent them.

---

## POC #5.4 — Named rule sets and payout-cycle batches

The RFP architecture now treats each business decision as a named rule set. A future BPMN payout process can invoke keys such as `COMMISSION_RULES`, `TAX_RULES`, `WITHHOLDING_RULES`, `BONUS_RULES` and `ADJUSTMENT_RULES` at different service-task stages.

A payout cycle snapshots the exact active version of every named rule set before batches begin. This prevents a mid-cycle rule publication from changing later batches.

### Reuse your existing 300K / 3M database

Do **not** reseed if you want to retain the benchmark results already produced by POC #5.3. Copy the existing `data/rfp-showcase.mv.db` into this project (or update the existing project in place), then run:

```bat
scripts\run-showcase-large.bat
```

`schema.sql` adds the new structures without deleting existing data. Startup migration links the legacy active version and historical executions to `COMMISSION_RULES`.

### New client-demo screens

- `/rule-sets` — named business rule sets and independent active versions.
- `/cycles` — payout-cycle version snapshots and transaction journey.
- `/rules` — rule-set-aware explorer.
- `/rules/new` — rule-set-aware dynamic composer.
- `/tester` — test a selected rule set.
- `/executions` — select rule set, optional payout cycle, workers and batch size.
- `/audit` — persisted transaction decision audit.
- `/architecture` — BPMN/batch/rule-set architecture.

### BPMN-friendly batch API

```http
POST /api/v1/rule-sets/COMMISSION_RULES/evaluate-batch
Content-Type: application/json
```

```json
{
  "cycleKey": "PAYOUT-2026-08",
  "batchId": "BATCH-00125",
  "transactions": [
    {
      "transactionId": "TX-100001",
      "attributes": {
        "PRODUCT_FAMILY": "TERM_LIFE",
        "ISSUE_STATE": "TX",
        "ANNUAL_PREMIUM": 250000,
        "PRODUCER_LEVEL": "GOLD"
      }
    }
  ]
}
```

For the RFP this endpoint is synchronous and deliberately simple. The production payout design can evolve to reference-based/asynchronous batch processing once the client's BPMN and complete requirements are available.


### Batch-level execution audit
POC #5.4 records a lightweight `BATCH_EXECUTION` row for every actual transaction chunk processed by a rule-set execution. For a 3M transaction run with batch size 5,000 this is roughly 600 audit rows, not millions. The execution detail screen shows transaction range, worker/partition, matched/no-match counts and read/engine/write/total timings per batch. Legacy runs remain valid and simply show no batch-level rows.
