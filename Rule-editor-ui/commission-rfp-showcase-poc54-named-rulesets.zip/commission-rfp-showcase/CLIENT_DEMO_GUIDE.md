# Client Demo Guide — POC #5.3

## Recommended 12–15 minute flow

### 1. Dashboard

Open `/` and establish the scale and latest benchmark result. Point out that business configuration, execution metrics and decision audit are all in the same application.

### 2. Attributes / Parameters

Open `/attributes`.

- Search the 300-attribute catalog.
- Click **Add Attribute**.
- Add a new monthly field such as `CAMPAIGN_PROPENSITY_SCORE`.
- Show that it appears immediately in the catalog.

Message: **new business columns are metadata, not Java fields.**

### 3. Compose a Business Rule

Open `/rules/new`.

Create a rule such as:

- Product Family = TERM_LIFE
- Issue State IN TX, CA, FL
- Producer Level = GOLD
- Annual Premium BETWEEN 100000 and 500000
- Campaign Propensity Score >= 75
- Commission = 3.75%
- Priority = 120

Show the dynamic operator choices and readable business preview.

### 4. Test & Explain

Open `/tester` and provide a small transaction input set.

Show:

- selected commission
- winning rule
- candidate count
- matched-rule count
- priority / specificity
- evaluation latency
- condition-by-condition PASS / FAIL explanation

### 5. Decision Audit

Open `/audit` and select a completed run with persisted results.

- Search a transaction ID or choose a result row.
- Click **Explain**.
- Show the final decision.
- Show all candidate rules surviving index reduction.
- Expand a rejected rule to show the failed condition.
- Expand a matched-but-lost rule to show why priority/specificity selected another rule.
- Show the sparse transaction inputs used by the decision.

Message: **we can explain both why a rule won and why alternatives did not.**

### 6. Decision Insights

Open `/insights`.

Show:

- matched count
- no-match count/rate
- ambiguity count
- incorrect count
- average candidates
- no-match samples
- ambiguity samples

### 7. Batch Execution / Metrics

Open `/executions` and the latest completed run.

Highlight:

- throughput and duration
- zero incorrect results
- DB read / engine / DB write timings
- average candidate reduction
- heap usage
- SLA headroom
- direct link back to Decision Audit

### 8. Architecture

Close on `/architecture`:

`metadata → sparse rules → compact indexes → ~5 candidates → deterministic winner → persisted audit → on-demand explanation`

## Demo scope note

The RFP UI intentionally stays simple. It does not attempt to implement the final maker/checker workflow, SSO/RBAC, nested boolean-expression semantics or BPMN stages before the client business documents are reviewed.
