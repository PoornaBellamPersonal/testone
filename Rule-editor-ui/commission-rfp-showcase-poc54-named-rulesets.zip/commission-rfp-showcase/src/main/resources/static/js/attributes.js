(() => {
  const q = document.getElementById('attributeSearch');
  const rows = Array.from(document.querySelectorAll('#attributeTable tbody tr'));
  if (q) q.addEventListener('input', () => {
    const term = q.value.trim().toLowerCase();
    rows.forEach(r => r.style.display = !term || r.textContent.toLowerCase().includes(term) ? '' : 'none');
  });
  const type = document.getElementById('attributeDataType');
  const ops = document.getElementById('allowedOperators');
  const presets = {
    STRING:'EQ,NE,IN,NOT_IN,IS_NULL,IS_NOT_NULL',
    BOOLEAN:'EQ,NE,IS_NULL,IS_NOT_NULL',
    DATE:'EQ,NE,GT,GE,LT,LE,BETWEEN,IS_NULL,IS_NOT_NULL',
    DECIMAL:'EQ,NE,GT,GE,LT,LE,BETWEEN,IS_NULL,IS_NOT_NULL',
    INTEGER:'EQ,NE,GT,GE,LT,LE,BETWEEN,IS_NULL,IS_NOT_NULL'
  };
  if (type && ops) type.addEventListener('change', () => ops.value = presets[type.value] || presets.STRING);
})();
