(() => {
  const rows=document.getElementById('testRows'), tpl=document.getElementById('testRowTemplate');
  window.addTestAttribute=()=>{const f=tpl.content.cloneNode(true);const r=f.querySelector('.condition-row');rows.appendChild(f);r.querySelector('.remove-test').addEventListener('click',()=>{r.remove();renumber();});renumber();};
  function renumber(){Array.from(rows.querySelectorAll('.condition-row')).forEach((r,i)=>r.querySelector('.condition-join').textContent=i===0?'INPUT':'AND');}
  addTestAttribute(); addTestAttribute(); addTestAttribute();
})();
