(() => {
  const root = document.querySelector('[data-run-id]');
  if (!root) return;

  const id = root.dataset.runId;
  let tx = Number(root.dataset.txCount || 0);
  const initialStatus = String(root.dataset.status || '').toUpperCase();
  const activeStatuses = new Set(['QUEUED', 'RUNNING']);
  let finalReloadRequested = false;

  const formatValue = (key, value) => {
    if (key === 'THROUGHPUT') {
      const n = Number(value);
      return Number.isFinite(n)
        ? n.toLocaleString(undefined, { maximumFractionDigits: 0 })
        : value;
    }
    return value;
  };

  const updatePage = (d) => {
    if (d.TRANSACTION_COUNT !== undefined && d.TRANSACTION_COUNT !== null) {
      tx = Number(d.TRANSACTION_COUNT || tx);
    }

    document.querySelectorAll('[data-field]').forEach(e => {
      const key = e.dataset.field;
      if (d[key] !== undefined && d[key] !== null) {
        e.textContent = formatValue(key, d[key]);
      }
    });

    const processed = Number(d.PROCESSED || 0);
    const progress = tx ? Math.min(100, (processed / tx) * 100) : 0;
    const bar = document.querySelector('.progress > div');
    if (bar) bar.style.width = progress.toFixed(1) + '%';
  };

  async function refresh() {
    try {
      const response = await fetch(`/executions/${id}/progress`, { cache: 'no-store' });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);

      const d = await response.json();
      updatePage(d);

      const status = String(d.STATUS || '').toUpperCase();
      if (activeStatuses.has(status)) {
        setTimeout(refresh, 1000);
        return;
      }

      // The live JSON only updates the summary cards. Reload once so the
      // server-rendered stage/rule metrics show their final values.
      if (!finalReloadRequested) {
        finalReloadRequested = true;
        window.location.reload();
      }
    } catch (err) {
      console.warn('Execution progress refresh failed:', err);
      setTimeout(refresh, 2000);
    }
  }

  // Critical: a page already rendered in SUCCESS/FAILED state must not
  // start polling, otherwise completion would cause an infinite reload loop.
  if (activeStatuses.has(initialStatus)) {
    refresh();
  } else if (initialStatus === 'SUCCESS') {
    const bar = document.querySelector('.progress > div');
    if (bar) bar.style.width = '100%';
  }
})();
