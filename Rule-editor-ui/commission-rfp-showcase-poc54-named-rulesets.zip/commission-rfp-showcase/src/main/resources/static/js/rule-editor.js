(() => {
  const catalog = new Map();
  document.querySelectorAll('#attributeCatalog [data-code]').forEach(e => catalog.set(e.dataset.code.toUpperCase(), {
    code:e.dataset.code, name:e.dataset.name, type:e.dataset.type, ops:(e.dataset.ops || 'EQ').split(',')
  }));
  const operatorLabels = {EQ:'Equals',NE:'Not Equals',IN:'In List',NOT_IN:'Not In List',GT:'Greater Than',GE:'Greater Than or Equal',LT:'Less Than',LE:'Less Than or Equal',BETWEEN:'Between',IS_NULL:'Is Missing',IS_NOT_NULL:'Is Present'};
  const rows = document.getElementById('conditionRows');
  const tpl = document.getElementById('conditionTemplate');
  const form = document.getElementById('ruleForm');
  const resultLabel = form?.dataset.resultLabel || 'Result';
  const resultUnit = form?.dataset.resultUnit || '';
  const formatResult = v => resultUnit ? `${v}${resultUnit}` : `${v}`;

  window.addConditionRow = function(){
    const fragment = tpl.content.cloneNode(true);
    const row = fragment.querySelector('.condition-row');
    rows.appendChild(fragment);
    wireRow(row);
    renumberJoins(); updatePreview();
  };

  function wireRow(row){
    const attr=row.querySelector('.attribute-input'), op=row.querySelector('.operator-select');
    row.querySelector('.remove-condition').addEventListener('click',()=>{row.remove();renumberJoins();updatePreview();});
    attr.addEventListener('input',()=>{configure(row);updatePreview();});
    attr.addEventListener('change',()=>{configure(row);updatePreview();});
    op.addEventListener('change',()=>{configureValueFields(row);updatePreview();});
    row.querySelectorAll('input').forEach(i=>i.addEventListener('input',updatePreview));
    configure(row);
  }

  function configure(row){
    const code=row.querySelector('.attribute-input').value.trim().toUpperCase();
    const def=catalog.get(code); const select=row.querySelector('.operator-select'); const current=select.value;
    select.innerHTML='';
    (def ? def.ops : ['EQ','NE','IN','NOT_IN']).forEach(o=>{const opt=document.createElement('option');opt.value=o;opt.textContent=operatorLabels[o]||o;select.appendChild(opt);});
    if(Array.from(select.options).some(o=>o.value===current))select.value=current;
    const v1=row.querySelector('.value1');
    if(def){
      if(def.type==='DATE') v1.placeholder='YYYY-MM-DD';
      else if(def.type==='DECIMAL'||def.type==='INTEGER') v1.placeholder='Numeric value';
      else if(def.type==='BOOLEAN') v1.placeholder='true / false';
      else v1.placeholder='Business value';
    }
    configureValueFields(row);
  }

  function configureValueFields(row){
    const op=row.querySelector('.operator-select').value;
    const v1=row.querySelector('.value1'), v2wrap=row.querySelector('.value2-wrap'), v2=row.querySelector('.value2');
    const noValue=op==='IS_NULL'||op==='IS_NOT_NULL';
    v1.closest('div').classList.toggle('hidden',noValue);
    v1.required=!noValue;
    const between=op==='BETWEEN'; v2wrap.classList.toggle('hidden',!between); v2.required=between;
    if(op==='IN'||op==='NOT_IN') v1.placeholder='Example: TX, CA, FL';
  }

  function renumberJoins(){
    Array.from(rows.querySelectorAll('.condition-row')).forEach((r,i)=>r.querySelector('.condition-join').textContent=i===0?'WHEN':'AND');
  }

  function updatePreview(){
    const lines=[];
    rows.querySelectorAll('.condition-row').forEach(r=>{
      const code=r.querySelector('.attribute-input').value.trim(); if(!code)return;
      const def=catalog.get(code.toUpperCase()); const name=def?def.name:code;
      const op=r.querySelector('.operator-select').value||'EQ'; const v1=r.querySelector('.value1').value; const v2=r.querySelector('.value2').value;
      let value=(op==='IS_NULL'||op==='IS_NOT_NULL')?'':v1;
      if(op==='BETWEEN') value=`${v1} AND ${v2}`;
      lines.push(`${name} ${operatorLabels[op]||op}${value?' '+value:''}`);
    });
    const pct=document.getElementById('ruleCommission').value||'0';
    document.getElementById('ruleCommissionMirror').value=formatResult(pct);
    document.getElementById('conditionCount').textContent=lines.length;
    document.getElementById('rulePreview').textContent=`WHEN\n${lines.length?lines.map((x,i)=>`${i?'AND ':'    '}${x}`).join('\n'):'    Add conditions to preview the rule.'}\n\nTHEN\n    ${resultLabel} = ${formatResult(pct)}\n    Priority = ${document.getElementById('rulePriority').value||'100'}`;
  }

  window.validateRuleForm=function(){
    const alert=document.getElementById('clientValidation'); const used=new Set(); let error='';
    if(!document.getElementById('ruleName').value.trim()) error='Enter a rule name.';
    rows.querySelectorAll('.condition-row').forEach(r=>{
      if(error)return; const code=r.querySelector('.attribute-input').value.trim().toUpperCase(); if(!catalog.has(code)){error=`Choose a valid attribute: ${code||'(blank)'}`;return;}
      if(used.has(code)){error=`Attribute ${code} is repeated.`;return;} used.add(code);
      const op=r.querySelector('.operator-select').value; const v1=r.querySelector('.value1').value.trim(); const v2=r.querySelector('.value2').value.trim();
      if(op!=='IS_NULL'&&op!=='IS_NOT_NULL'&&!v1)error=`Enter a value for ${code}.`;
      if(op==='BETWEEN'&&!v2)error=`Enter both values for ${code}.`;
    });
    alert.className='alert '+(error?'error':'success'); alert.textContent=error||'Rule structure looks valid and is ready to save.'; alert.classList.remove('hidden');
    if(!error) alert.scrollIntoView({behavior:'smooth',block:'center'});
  };

  ['ruleCommission','rulePriority','ruleName'].forEach(id=>document.getElementById(id)?.addEventListener('input',updatePreview));
  addConditionRow();
})();
