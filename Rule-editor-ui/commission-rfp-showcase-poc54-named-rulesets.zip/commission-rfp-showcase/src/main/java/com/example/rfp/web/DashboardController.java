package com.example.rfp.web;

import com.example.rfp.service.DashboardService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class DashboardController {
    private final DashboardService dashboard;
    public DashboardController(DashboardService dashboard){this.dashboard=dashboard;}
    @GetMapping("/") public String home(Model model){model.addAllAttributes(dashboard.snapshot());return "dashboard";}
    @GetMapping("/architecture") public String architecture(){return "architecture";}
}
