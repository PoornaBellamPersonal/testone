package com.example.rfp.service;

import com.example.rfp.codec.SparsePayloadCodec;
import com.example.rfp.model.AttributeDataType;
import com.example.rfp.model.ConditionOperator;
import com.example.rfp.model.RuleCondition;
import com.example.rfp.repository.RfpRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import javax.sql.DataSource;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Types;
import java.time.Duration;
import java.time.LocalDate;
import java.util.*;

@Service
public class DemoDataSeeder {
    private final JdbcTemplate jdbc;
    private final DataSource dataSource;
    private final EngineRegistry engines;
    private final RfpRepository repo;
    private final int txExtraAttributesOverride;

    public DemoDataSeeder(JdbcTemplate jdbc,
                          DataSource dataSource,
                          EngineRegistry engines,
                          RfpRepository repo,
                          @Value("${rfp.demo.tx-extra-attributes:-1}") int txExtraAttributesOverride) {
        this.jdbc = jdbc;
        this.dataSource = dataSource;
        this.engines = engines;
        this.repo = repo;
        this.txExtraAttributesOverride = txExtraAttributesOverride;
    }

    public void seedProfile(String profileName, boolean reset) throws Exception {
        Profile profile = Profile.of(profileName);
        if (reset) reset();
        if (jdbc.queryForObject("select count(*) from commission_rule", Long.class) > 0) {
            System.out.println("Existing dataset detected; seed skipped. Use --rfp.demo.reset=true to rebuild it.");
            return;
        }

        int extras = txExtraAttributesOverride >= 0 ? txExtraAttributesOverride : profile.txExtraAttributes();
        System.out.printf(Locale.ROOT,
                "%n=== Seeding %s ===%nAttributes: %,d | Rules: %,d | Transactions: %,d | Extra populated tx attributes: %d%n",
                profile.code(), profile.attributes(), profile.rules(), profile.transactions(), extras);
        long allStarted = System.nanoTime();
        seedAttributes(profile.attributes());
        repo.ensureDefaultRuleSetsAndMigrateLegacyData();
        long commissionVersionId = seedVersion(profile);
        repo.ensureAuxiliaryDemoVersions();
        seedRules(commissionVersionId, profile.rules(), profile.attributes());
        ensureAuxiliaryRuleSamples();
        seedTransactions(profile.rules(), profile.transactions(), profile.attributes(), extras);
        engines.invalidate();
        System.out.printf(Locale.ROOT, "Dataset ready in %s%n%n", fmt(System.nanoTime() - allStarted));
    }

    public void reset() {
        jdbc.execute("delete from execution_result");
        jdbc.execute("delete from execution_run");
        jdbc.execute("delete from cycle_ruleset_snapshot");
        jdbc.execute("delete from cycle_execution");
        jdbc.execute("delete from transaction_record");
        jdbc.execute("delete from rule_condition");
        jdbc.execute("delete from commission_rule");
        jdbc.execute("delete from rule_set_version");
        jdbc.execute("delete from rule_set");
        jdbc.execute("delete from attribute_definition");
        engines.invalidate();
    }

    private void seedAttributes(int count) {
        long started = System.nanoTime();
        for (NearRealAttributeCatalog.Spec s : NearRealAttributeCatalog.specs(count)) {
            jdbc.update("insert into attribute_definition(id,code,display_name,data_type,source_key,allowed_operators,active) values(?,?,?,?,?,?,true)",
                    s.id(), s.code(), s.displayName(), s.type().name(), s.code(), s.allowedOperators());
        }
        System.out.printf(Locale.ROOT, "Seeded %,d near-real attribute definitions in %s%n", count, fmt(System.nanoTime() - started));
    }

    private long seedVersion(Profile profile) {
        String version = "2026.08-" + profile.code().toUpperCase(Locale.ROOT).replace('-', '_');
        String description = String.format(Locale.ROOT,
                "RFP dataset: %,d dynamic attributes, %,d sparse rules, %,d transactions",
                profile.attributes(), profile.rules(), profile.transactions());
        long commissionSetId = repo.defaultCommissionRuleSetId();
        jdbc.update("insert into rule_set_version(named_rule_set_id,version_code,status,description,activated_at) values(?,?,'ACTIVE',?,current_timestamp)", commissionSetId, version, description);
        return jdbc.queryForObject("select id from rule_set_version where version_code=?", Long.class, version);
    }

    private void seedRules(long commissionVersionId, int requestedRows, int attributeCount) throws Exception {
        if (requestedRows % 5 != 0) throw new IllegalArgumentException("Rule count must be divisible by 5 for deterministic logical groups");
        int groups = requestedRows / 5;
        long conditionId = 1;
        long started = System.nanoTime();
        long conditionRows = 0;

        try (Connection c = dataSource.getConnection();
             PreparedStatement r = c.prepareStatement("insert into commission_rule(id,rule_set_id,name,priority,commission_percentage,status) values(?,?,?,?,?,'ACTIVE')");
             PreparedStatement rc = c.prepareStatement("insert into rule_condition(id,rule_id,attribute_id,operator_code,value_1,value_2) values(?,?,?,?,?,?)")) {
            c.setAutoCommit(false);
            int pending = 0;
            for (int g = 0; g < groups; g++) {
                List<Cond> exact = baseConditions(g, attributeCount);
                for (int v = 0; v < 5; v++) {
                    long ruleId = (long) g * 5 + v + 1;
                    int priority;
                    List<Cond> cs;
                    String type;
                    if (v == 0) {
                        priority = 100;
                        cs = exact;
                        type = "STANDARD_EXACT";
                    } else if (v == 1) {
                        priority = 80;
                        cs = drop(exact, 3, 13); // issue state + customer segment become ANY
                        type = "GEOGRAPHY_WILDCARD";
                    } else if (v == 2) {
                        priority = 70;
                        cs = drop(exact, 5, 6, 7, 8); // distribution/producer attributes become ANY
                        type = "DISTRIBUTION_WILDCARD";
                    } else if (v == 3) {
                        priority = 60;
                        cs = List.of(
                                exact.get(14), // unique compensation program keeps the logical group bounded
                                exact.get(1),
                                exact.get(9),
                                new Cond(5, "BETWEEN", "0", "5000000"),
                                new Cond(11, "BETWEEN", "2025-01-01", "2029-12-31")
                        );
                        type = "BROAD_PROGRAM_BAND";
                    } else if (g % 10 == 0) {
                        priority = 120;
                        cs = List.of(exact.get(14), exact.get(1), exact.get(5), exact.get(6), exact.get(9), exact.get(4));
                        type = "PRIORITY_OVERRIDE";
                    } else if (g % 20 == 1) {
                        priority = 100;
                        cs = exact;
                        type = "EXACT_TIE";
                    } else {
                        priority = 50;
                        cs = List.of(exact.get(14));
                        type = "PROGRAM_FALLBACK";
                    }

                    BigDecimal pct = BigDecimal.valueOf(125 + (g % 1375)).movePointLeft(2);
                    String program = exact.get(14).v1;
                    String product = exact.get(1).v1;
                    r.setLong(1, ruleId);
                    r.setLong(2, commissionVersionId);
                    r.setString(3, type + " | " + product + " | " + program);
                    r.setInt(4, priority);
                    r.setBigDecimal(5, pct);
                    r.addBatch();

                    for (Cond x : cs) {
                        rc.setLong(1, conditionId++);
                        rc.setLong(2, ruleId);
                        rc.setLong(3, x.attr);
                        rc.setString(4, x.op);
                        rc.setString(5, x.v1);
                        rc.setString(6, x.v2);
                        rc.addBatch();
                        conditionRows++;
                    }

                    if (++pending % 2_000 == 0) {
                        r.executeBatch();
                        rc.executeBatch();
                        c.commit();
                    }
                }
                if ((g + 1) % 10_000 == 0 || g + 1 == groups) {
                    System.out.printf(Locale.ROOT, "  rules: %,d / %,d logical groups (%,d rule rows)%n", g + 1, groups, (g + 1L) * 5);
                }
            }
            r.executeBatch();
            rc.executeBatch();
            c.commit();
        }
        System.out.printf(Locale.ROOT,
                "Seeded %,d rule rows and %,d sparse conditions (avg %.2f/rule) in %s%n",
                requestedRows, conditionRows, (double) conditionRows / requestedRows, fmt(System.nanoTime() - started));
    }

    public void ensureAuxiliaryRuleSamples() {
        if (repo.attributeCount() < 16) return;
        // Small near-real examples make TAX/WITHHOLDING/BONUS/ADJUSTMENT rule sets useful in the client UI
        // without changing the 300K commission benchmark population.
        if (auxiliarySetEmpty("TAX_RULES")) {
        seedAuxiliaryRule("TAX_RULES", "Resident tax - standard transaction", 100, new BigDecimal("12.50"),
                List.of(new RuleCondition(4,"ISSUE_STATE",ConditionOperator.IN,"CA,NY,NJ,MA",null),
                        new RuleCondition(10,"TRANSACTION_TYPE",ConditionOperator.IN,"NEW_BUSINESS,RENEWAL",null)));
        seedAuxiliaryRule("TAX_RULES", "General tax fallback", 50, new BigDecimal("8.00"),
                List.of(new RuleCondition(10,"TRANSACTION_TYPE",ConditionOperator.IN,"NEW_BUSINESS,RENEWAL,ADJUSTMENT",null)));
        }

        if (auxiliarySetEmpty("WITHHOLDING_RULES")) {
        seedAuxiliaryRule("WITHHOLDING_RULES", "Broker withholding", 100, new BigDecimal("5.00"),
                List.of(new RuleCondition(6,"DISTRIBUTION_CHANNEL",ConditionOperator.IN,"BROKER,INDEPENDENT_AGENCY",null)));
        seedAuxiliaryRule("WITHHOLDING_RULES", "Default withholding", 50, new BigDecimal("2.00"),
                List.of(new RuleCondition(12,"POLICY_STATUS",ConditionOperator.IN,"ACTIVE,PREMIUM_PAYING,INFORCE",null)));
        }

        if (auxiliarySetEmpty("BONUS_RULES")) {
        seedAuxiliaryRule("BONUS_RULES", "Gold and Platinum producer bonus", 100, new BigDecimal("1.50"),
                List.of(new RuleCondition(8,"PRODUCER_LEVEL",ConditionOperator.IN,"GOLD,PLATINUM,ELITE",null),
                        new RuleCondition(16,"PRODUCTION_YTD",ConditionOperator.GE,"1000000",null)));
        seedAuxiliaryRule("BONUS_RULES", "High premium bonus", 80, new BigDecimal("0.75"),
                List.of(new RuleCondition(5,"ANNUAL_PREMIUM",ConditionOperator.GE,"250000",null)));
        }

        if (auxiliarySetEmpty("ADJUSTMENT_RULES")) {
        seedAuxiliaryRule("ADJUSTMENT_RULES", "Large premium adjustment", 100, new BigDecimal("0.50"),
                List.of(new RuleCondition(5,"ANNUAL_PREMIUM",ConditionOperator.GE,"500000",null)));
        seedAuxiliaryRule("ADJUSTMENT_RULES", "Renewal adjustment", 70, new BigDecimal("0.25"),
                List.of(new RuleCondition(10,"TRANSACTION_TYPE",ConditionOperator.EQ,"RENEWAL",null)));
        }
    }

    private boolean auxiliarySetEmpty(String key) {
        long setId=repo.ruleSetByKey(key).id(); Long version=repo.activeVersionId(setId); return version != null && repo.ruleCount(version)==0;
    }

    private void seedAuxiliaryRule(String ruleSetKey, String name, int priority, BigDecimal value, List<RuleCondition> conditions) {
        long setId=repo.ruleSetByKey(ruleSetKey).id();
        Long versionId=repo.activeVersionId(setId);
        if(versionId==null) return;
        repo.createRule(versionId,name,priority,value,conditions);
    }

    private void seedTransactions(int ruleRows, int txCount, int attributeCount, int extraAttributes) throws Exception {
        int groups = ruleRows / 5;
        long started = System.nanoTime();
        try (Connection c = dataSource.getConnection();
             PreparedStatement ps = c.prepareStatement("insert into transaction_record(id,partition_id,attributes_payload,expected_rule_id) values(?,?,?,?)")) {
            c.setAutoCommit(false);
            for (int i = 1; i <= txCount; i++) {
                // Multiplicative permutation yields deterministic but non-sequential business populations.
                int g = (int) Math.floorMod((long) i * 104729L + (i / 97L) * 7919L, groups);
                boolean noMatch = i % 33 == 0; // ~3.03%
                Map<Long, String> values = transactionValues(g, i, noMatch, attributeCount, extraAttributes);
                Long expected = noMatch ? null : ((g % 10 == 0) ? ((long) g * 5 + 5) : ((long) g * 5 + 1));

                ps.setLong(1, i);
                ps.setInt(2, partitionFor(g, i));
                ps.setString(3, SparsePayloadCodec.encode(values));
                if (expected == null) ps.setNull(4, Types.BIGINT); else ps.setLong(4, expected);
                ps.addBatch();

                if (i % 10_000 == 0) {
                    ps.executeBatch();
                    c.commit();
                }
                if (i % 250_000 == 0 || i == txCount) {
                    System.out.printf(Locale.ROOT, "  transactions: %,d / %,d%n", i, txCount);
                }
            }
            ps.executeBatch();
            c.commit();
        }
        System.out.printf(Locale.ROOT, "Seeded %,d transaction rows in %s%n", txCount, fmt(System.nanoTime() - started));
    }

    private List<Cond> baseConditions(int g, int attributeCount) {
        long premiumMin = premiumBand(g);
        long productionMin = (g % 25L) * 250_000L;
        LocalDate effectiveStart = LocalDate.of(2026, 1 + Math.floorMod(g, 12), 1);
        LocalDate effectiveEnd = effectiveStart.plusMonths(1).minusDays(1);

        List<Cond> out = new ArrayList<>(20);
        out.add(new Cond(1, "EQ", CARRIERS[Math.floorMod(g, CARRIERS.length)], null));
        out.add(new Cond(2, "EQ", PRODUCT_FAMILIES[Math.floorMod(g * 7, PRODUCT_FAMILIES.length)], null));
        out.add(new Cond(3, "EQ", PRODUCT_CODES[Math.floorMod(g * 11, PRODUCT_CODES.length)], null));
        out.add(new Cond(4, "EQ", STATES[Math.floorMod(g * 13, STATES.length)], null));
        out.add(new Cond(5, "BETWEEN", Long.toString(premiumMin), Long.toString(premiumMin + 49_999L)));
        out.add(new Cond(6, "EQ", CHANNELS[Math.floorMod(g * 5, CHANNELS.length)], null));
        out.add(new Cond(7, "EQ", PRODUCER_TYPES[Math.floorMod(g * 3, PRODUCER_TYPES.length)], null));
        out.add(new Cond(8, "EQ", PRODUCER_LEVELS[Math.floorMod(g * 7, PRODUCER_LEVELS.length)], null));
        out.add(new Cond(9, "EQ", REGISTRATION_TYPES[Math.floorMod(g * 5, REGISTRATION_TYPES.length)], null));
        out.add(new Cond(10, "EQ", TRANSACTION_TYPES[Math.floorMod(g * 11, TRANSACTION_TYPES.length)], null));
        out.add(new Cond(11, "BETWEEN", effectiveStart.toString(), effectiveEnd.toString()));
        out.add(new Cond(12, "EQ", POLICY_STATUSES[Math.floorMod(g * 13, POLICY_STATUSES.length)], null));
        out.add(new Cond(13, "EQ", PREMIUM_MODES[Math.floorMod(g * 17, PREMIUM_MODES.length)], null));
        out.add(new Cond(14, "EQ", CUSTOMER_SEGMENTS[Math.floorMod(g * 19, CUSTOMER_SEGMENTS.length)], null));
        out.add(new Cond(15, "EQ", String.format(Locale.ROOT, "COMP-%06d", g), null));
        out.add(new Cond(16, "BETWEEN", Long.toString(productionMin), Long.toString(productionMin + 499_999L)));

        int dynamicSlots = Math.min(4, Math.max(0, attributeCount - 16));
        Set<Integer> used = new HashSet<>();
        for (int slot = 0; slot < dynamicSlots; slot++) {
            int attr = 17 + Math.floorMod(g * 31 + slot * 67, attributeCount - 16);
            while (!used.add(attr)) attr = 17 + Math.floorMod(attr - 16 + 37, attributeCount - 16);
            out.add(dynamicCondition(attr, g * 97 + slot * 17));
        }
        return List.copyOf(out);
    }

    private Cond dynamicCondition(int attributeId, int seed) {
        NearRealAttributeCatalog.Spec s = NearRealAttributeCatalog.spec(attributeId);
        String value = NearRealAttributeCatalog.generatedValue(attributeId, seed);
        return switch (s.type()) {
            case STRING, BOOLEAN -> new Cond(attributeId, "EQ", value, null);
            case INTEGER, DECIMAL -> {
                BigDecimal v = new BigDecimal(value);
                BigDecimal span = s.type() == AttributeDataType.INTEGER ? BigDecimal.valueOf(5) : BigDecimal.valueOf(1000);
                yield new Cond(attributeId, "BETWEEN", v.subtract(span).max(BigDecimal.ZERO).stripTrailingZeros().toPlainString(), v.add(span).stripTrailingZeros().toPlainString());
            }
            case DATE -> {
                LocalDate d = LocalDate.parse(value);
                yield new Cond(attributeId, "BETWEEN", d.minusDays(15).toString(), d.plusDays(15).toString());
            }
        };
    }

    private Map<Long, String> transactionValues(int g, int txId, boolean noMatch, int attributeCount, int extraAttributes) {
        Map<Long, String> m = new LinkedHashMap<>();
        for (Cond c : baseConditions(g, attributeCount)) m.put(c.attr, representative(c));
        if (noMatch) m.put(15L, "UNMAPPED-COMP-PROGRAM-" + (txId % 1000));

        // Additional business attributes are present in the transaction but not necessarily referenced by its winning rule.
        int available = Math.max(0, attributeCount - 16);
        for (int j = 0; j < extraAttributes && available > 0; j++) {
            int attr = 17 + Math.floorMod(txId * 17 + g * 13 + j * 71, available);
            m.putIfAbsent((long) attr, NearRealAttributeCatalog.generatedValue(attr, txId * 31 + j * 101));
        }
        return m;
    }

    private static String representative(Cond c) {
        if (!"BETWEEN".equals(c.op)) return c.v1;
        try {
            return new BigDecimal(c.v1).add(new BigDecimal(c.v2)).divide(BigDecimal.valueOf(2)).stripTrailingZeros().toPlainString();
        } catch (NumberFormatException ignored) {
            try {
                LocalDate a = LocalDate.parse(c.v1), b = LocalDate.parse(c.v2);
                return a.plusDays(Duration.between(a.atStartOfDay(), b.atStartOfDay()).toDays() / 2).toString();
            } catch (Exception ex) {
                return c.v1;
            }
        }
    }

    private static int partitionFor(int group, int txId) {
        // Near-real skew: ~35% of traffic is concentrated in four busy business partitions.
        if (txId % 20 < 7) return Math.floorMod(txId, 4);
        return Math.floorMod(group * 17 + txId, 32);
    }

    private static long premiumBand(int g) {
        int bucket = Math.floorMod(g * 7, 30);
        return switch (bucket) {
            case 0, 1, 2, 3, 4, 5, 6, 7 -> bucket * 10_000L;
            case 8, 9, 10, 11, 12, 13, 14, 15 -> 100_000L + (bucket - 8L) * 25_000L;
            default -> 300_000L + (bucket - 16L) * 50_000L;
        };
    }

    private static List<Cond> drop(List<Cond> src, int... positions) {
        Set<Integer> s = new HashSet<>();
        for (int p : positions) s.add(p);
        List<Cond> o = new ArrayList<>();
        for (int i = 0; i < src.size(); i++) if (!s.contains(i)) o.add(src.get(i));
        return List.copyOf(o);
    }

    private static String fmt(long nanos) {
        long ms = nanos / 1_000_000;
        return String.format(Locale.ROOT, "%d:%02d.%03d", ms / 60_000, (ms / 1000) % 60, ms % 1000);
    }

    private record Cond(long attr, String op, String v1, String v2) {}

    private record Profile(String code, int attributes, int rules, int transactions, int txExtraAttributes) {
        static Profile of(String name) {
            return switch (name.toLowerCase(Locale.ROOT)) {
                case "quick" -> new Profile("quick", 220, 5_000, 50_000, 16);
                case "medium" -> new Profile("medium", 220, 50_000, 200_000, 20);
                case "target" -> new Profile("target-200k-2m", 220, 200_000, 2_000_000, 24);
                case "nearreal-smoke", "near-real-smoke" -> new Profile("nearreal-smoke", 300, 30_000, 100_000, 24);
                case "nearreal-medium", "near-real-medium" -> new Profile("nearreal-medium", 300, 100_000, 500_000, 28);
                case "nearreal", "nearreal-target", "near-real-target", "300k-3m" -> new Profile("nearreal-300k-3m", 300, 300_000, 3_000_000, 32);
                default -> throw new IllegalArgumentException("Unknown seed profile: " + name + ". Use quick, medium, target, nearreal-smoke, nearreal-medium or nearreal-target");
            };
        }
    }

    private static final String[] CARRIERS = {"NORTHSTAR_LIFE","HERITAGE_LIFE","SUMMIT_FINANCIAL","PIONEER_ASSURANCE","EVERGREEN_LIFE","HORIZON_ANNUITY","LIBERTY_PROTECTION","CENTENNIAL_LIFE","STERLING_ASSURANCE","PACIFIC_HERITAGE","ATLANTIC_LIFE","METRO_PROTECTION"};
    private static final String[] PRODUCT_FAMILIES = {"TERM_LIFE","WHOLE_LIFE","UNIVERSAL_LIFE","INDEXED_UL","VARIABLE_UL","FIXED_ANNUITY","INDEXED_ANNUITY","IMMEDIATE_ANNUITY"};
    private static final String[] PRODUCT_CODES = {"TL10","TL20","TL30","WL100","WLPLUS","ULFLEX","ULPRO","IULACC","IULMAX","VULCORE","VULSELECT","FA3","FA5","FA7","FIA5","FIA7","SPIA","DIA","ROPTERM","JUVWL","SURVUL","KEYPERSON","EXECBONUS","FINAL_EXPENSE"};
    private static final String[] STATES = {"AL","AZ","CA","CO","CT","FL","GA","IL","IN","MA","MD","MI","MN","MO","NC","NJ","NY","OH","OR","PA","SC","TN","TX","UT","VA","WA","WI","NV","NH","NM","OK","KY"};
    private static final String[] CHANNELS = {"CAREER_AGENCY","INDEPENDENT_AGENCY","BROKER","BANK","DIRECT","DIGITAL","BGA","IMO"};
    private static final String[] PRODUCER_TYPES = {"CAPTIVE_AGENT","INDEPENDENT_AGENT","BROKER","BANK_REP","BGA","IMO"};
    private static final String[] PRODUCER_LEVELS = {"ASSOCIATE","STANDARD","SENIOR","GOLD","PLATINUM","ELITE"};
    private static final String[] REGISTRATION_TYPES = {"REGISTERED","NON_REGISTERED","DUAL_REGISTERED","CORPORATE"};
    private static final String[] TRANSACTION_TYPES = {"NEW_BUSINESS","RENEWAL","TOP_UP","EXCHANGE","REINSTATEMENT","ADJUSTMENT"};
    private static final String[] POLICY_STATUSES = {"ACTIVE","PREMIUM_PAYING","PAID_UP","INFORCE"};
    private static final String[] PREMIUM_MODES = {"MONTHLY","QUARTERLY","SEMI_ANNUAL","ANNUAL","SINGLE_PREMIUM"};
    private static final String[] CUSTOMER_SEGMENTS = {"MASS_MARKET","MASS_AFFLUENT","AFFLUENT","HNW","SMALL_BUSINESS","INSTITUTIONAL"};
}
