package com.example.rfp.web;

import com.example.rfp.codec.SparsePayloadCodec;
import com.example.rfp.model.AttributeDefinition;
import com.example.rfp.model.DecisionAudit;
import com.example.rfp.repository.RfpRepository;
import com.example.rfp.service.EngineRegistry;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@Controller
@RequestMapping("/audit")
public class AuditController {
    private final RfpRepository repo;
    private final EngineRegistry engines;

    public AuditController(RfpRepository repo, EngineRegistry engines) {
        this.repo = repo;
        this.engines = engines;
    }

    @GetMapping
    public String list(@RequestParam(required = false) Long runId,
                       @RequestParam(defaultValue = "") String transactionId,
                       @RequestParam(defaultValue = "ALL") String status,
                       @RequestParam(defaultValue = "0") int page,
                       Model model) {
        List<Map<String,Object>> runs = repo.persistedExecutionHistory();
        Long selected = runId;
        if (selected == null && !runs.isEmpty()) selected = ((Number) runs.getFirst().get("ID")).longValue();
        model.addAttribute("runs", runs);
        model.addAttribute("selectedRun", selected);
        model.addAttribute("transactionId", transactionId);
        model.addAttribute("status", status);
        model.addAttribute("page", Math.max(0, page));
        model.addAttribute("results", selected == null ? List.of() :
                repo.executionResults(selected, transactionId, status, Math.max(0, page), 50));
        if (selected != null) {
            Map<String,Object> selectedRun = repo.execution(selected); model.addAttribute("run", selectedRun);
            if (selectedRun.get("NAMED_RULE_SET_ID") instanceof Number n) model.addAttribute("ruleSet", repo.ruleSet(n.longValue()));
        }
        return "audit";
    }

    @GetMapping("/{runId}/{transactionId}")
    public String detail(@PathVariable long runId, @PathVariable long transactionId, Model model) {
        Map<String,Object> run = repo.execution(runId);
        Map<String,Object> stored = repo.executionResult(runId, transactionId);
        Map<String,Object> tx = repo.transactionRecord(transactionId);
        long versionId = ((Number) run.get("RULE_SET_ID")).longValue();

        var bag = SparsePayloadCodec.decode(String.valueOf(tx.get("ATTRIBUTES_PAYLOAD")));
        DecisionAudit audit = engines.engine(versionId).explain(bag, 25);
        Map<Long, AttributeDefinition> definitions = repo.attributeMap();
        List<Map<String,Object>> values = new ArrayList<>();
        bag.values().forEach((id, value) -> {
            AttributeDefinition a = definitions.get(id);
            Map<String,Object> row = new LinkedHashMap<>();
            row.put("ID", id);
            row.put("CODE", a == null ? "ATTR_" + id : a.code());
            row.put("NAME", a == null ? "Attribute " + id : a.displayName());
            row.put("TYPE", a == null ? "-" : a.dataType().name());
            row.put("VALUE", value);
            values.add(row);
        });

        model.addAttribute("run", run);
        if (run.get("NAMED_RULE_SET_ID") instanceof Number n) model.addAttribute("ruleSet", repo.ruleSet(n.longValue()));
        model.addAttribute("stored", stored);
        model.addAttribute("transaction", tx);
        Long storedWinner = stored.get("MATCHED_RULE_ID") == null ? null : ((Number) stored.get("MATCHED_RULE_ID")).longValue();
        model.addAttribute("replayConsistent", Objects.equals(storedWinner, audit.result().matchedRuleId()));
        model.addAttribute("audit", audit);
        model.addAttribute("attributeValues", values);
        return "audit-detail";
    }
}
