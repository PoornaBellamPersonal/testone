package com.example.rfp.model;

import java.math.BigDecimal;
import java.util.List;

public record EvaluationResult(
        Long matchedRuleId,
        String matchedRuleName,
        BigDecimal commissionPercentage,
        int candidateCount,
        int matchedCount,
        int topRankCount,
        int priority,
        int specificity,
        long evaluationNanos,
        String status,
        List<ConditionTrace> traces) {

    public static EvaluationResult noMatch(int candidates, long nanos) {
        return new EvaluationResult(null, null, null, candidates, 0, 0, 0, 0, nanos, "NO_MATCH", List.of());
    }
}
