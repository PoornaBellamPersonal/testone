package com.example.rfp.model;

public record EngineStats(long ruleCount, long conditionCount, int activeAttributes, int indexedAttributes, double averageConditions, int maxConditions, long compileMillis) {}
