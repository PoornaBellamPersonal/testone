package com.example.rfp.web;

import com.example.rfp.model.*;
import com.example.rfp.repository.RfpRepository;
import com.example.rfp.service.EngineRegistry;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import java.io.*;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.util.*;

@Controller
@RequestMapping("/rules")
public class RuleController {
    private final RfpRepository repo; private final EngineRegistry engines;
    public RuleController(RfpRepository repo,EngineRegistry engines){this.repo=repo;this.engines=engines;}

    @GetMapping
    public String list(@RequestParam(required=false) Long ruleSetId,
                       @RequestParam(required=false) Long versionId,
                       @RequestParam(defaultValue="0") int page,
                       @RequestParam(defaultValue="") String search,
                       Model m){
        long setId = ruleSetId==null?repo.defaultCommissionRuleSetId():ruleSetId;
        Long v = versionId==null?repo.activeVersionId(setId):versionId;
        m.addAttribute("ruleSets",repo.ruleSetSummaries());
        m.addAttribute("selectedRuleSet",repo.ruleSet(setId));
        m.addAttribute("selectedRuleSetId",setId);
        m.addAttribute("versions",repo.versions(setId));
        m.addAttribute("selectedVersionId",v);
        m.addAttribute("version",v==null?"NONE":String.valueOf(repo.version(v).get("VERSION_CODE")));
        m.addAttribute("rules",v==null?List.of():repo.rulePage(v,search,page,50));
        m.addAttribute("page",page); m.addAttribute("search",search);
        return "rules";
    }

    @GetMapping("/{id}") public String detail(@PathVariable long id,Model m){m.addAttribute("rule",repo.rule(id));m.addAttribute("context",repo.ruleContext(id));return "rule-detail";}

    @GetMapping("/new")
    public String createForm(@RequestParam(required=false) Long ruleSetId,Model m){
        long setId=ruleSetId==null?repo.defaultCommissionRuleSetId():ruleSetId;
        m.addAttribute("attributes",repo.attributes());m.addAttribute("operators",ConditionOperator.values());
        m.addAttribute("ruleSets",repo.ruleSetSummaries());m.addAttribute("selectedRuleSet",repo.ruleSet(setId));m.addAttribute("selectedRuleSetId",setId);
        m.addAttribute("activeVersion",repo.activeVersionCode(setId));
        return "rule-new";
    }

    @PostMapping
    public String create(@RequestParam long ruleSetId,
                         @RequestParam String name,
                         @RequestParam int priority,
                         @RequestParam BigDecimal commissionPercentage,
                         @RequestParam(required=false) List<String> attributeCode,
                         @RequestParam(required=false) List<String> operator,
                         @RequestParam(required=false) List<String> value1,
                         @RequestParam(required=false) List<String> value2,
                         Model m) {
        Long version=repo.activeVersionId(ruleSetId);
        if(version==null) throw new IllegalStateException("No ACTIVE version for selected rule set");
        Map<String,AttributeDefinition> defs=repo.attributeMapByCode(); List<RuleCondition> conditions=new ArrayList<>(); Set<Long> seen=new HashSet<>();
        try {
            if(attributeCode!=null){
                for(int i=0;i<attributeCode.size();i++){
                    String code=attributeCode.get(i)==null?"":attributeCode.get(i).trim().toUpperCase(Locale.ROOT); if(code.isBlank()) continue;
                    AttributeDefinition d=defs.get(code); if(d==null) throw new IllegalArgumentException("Unknown attribute: "+code);
                    if(!seen.add(d.id())) throw new IllegalArgumentException("Attribute "+d.displayName()+" is used more than once in this rule");
                    String op=(operator!=null && i<operator.size() && operator.get(i)!=null)?operator.get(i):"EQ"; ConditionOperator parsed=ConditionOperator.valueOf(op.toUpperCase(Locale.ROOT));
                    if(d.allowedOperators()!=null && !Arrays.asList(d.allowedOperators().split(",")).contains(parsed.name())) throw new IllegalArgumentException(parsed+" is not allowed for "+d.displayName());
                    String v1=(value1!=null && i<value1.size())?value1.get(i):""; String v2=(value2!=null && i<value2.size())?value2.get(i):"";
                    if(parsed!=ConditionOperator.IS_NULL && parsed!=ConditionOperator.IS_NOT_NULL && (v1==null || v1.isBlank())) throw new IllegalArgumentException("A value is required for "+d.displayName());
                    if(parsed==ConditionOperator.BETWEEN && (v2==null || v2.isBlank())) throw new IllegalArgumentException("Between requires two values for "+d.displayName());
                    conditions.add(new RuleCondition(d.id(),d.code(),parsed,v1,v2));
                }
            }
            if(conditions.isEmpty()) throw new IllegalArgumentException("Add at least one condition");
            long id=repo.createRule(version,name,priority,commissionPercentage,conditions); engines.invalidate();
            return "redirect:/rules/"+id+"?created";
        } catch (IllegalArgumentException ex) {
            m.addAttribute("attributes",repo.attributes());m.addAttribute("operators",ConditionOperator.values());m.addAttribute("error",ex.getMessage());
            m.addAttribute("ruleSets",repo.ruleSetSummaries());m.addAttribute("selectedRuleSet",repo.ruleSet(ruleSetId));m.addAttribute("selectedRuleSetId",ruleSetId);m.addAttribute("activeVersion",repo.activeVersionCode(ruleSetId));
            return "rule-new";
        }
    }

    @PostMapping("/{id}/clone")
    public String cloneRule(@PathVariable long id) {
        RuleDefinition source=repo.rule(id); Map<String,Object> ctx=repo.ruleContext(id); long namedSet=((Number)ctx.get("RULE_SET_ID")).longValue();
        Long version=repo.activeVersionId(namedSet); if(version==null) throw new IllegalStateException("No ACTIVE version for selected rule set");
        long newId=repo.createRule(version,"Copy of "+source.name(),source.priority(),source.commissionPercentage(),source.conditions()); engines.invalidate();
        return "redirect:/rules/"+newId+"?cloned";
    }

    @GetMapping("/import")
    public String importForm(@RequestParam(required=false) Long ruleSetId,Model m){ long setId=ruleSetId==null?repo.defaultCommissionRuleSetId():ruleSetId; m.addAttribute("ruleSets",repo.ruleSetSummaries());m.addAttribute("selectedRuleSetId",setId);return "rule-import"; }

    @PostMapping("/import")
    public String importCsv(@RequestParam long ruleSetId,@RequestParam MultipartFile file) throws IOException {
        Long version=repo.activeVersionId(ruleSetId); if(version==null) throw new IllegalStateException("No ACTIVE version for selected rule set");
        Map<String,AttributeDefinition> defs=repo.attributeMapByCode(); record Pending(String name,int priority,BigDecimal pct,List<RuleCondition> conditions){} Map<String,Pending> pending=new LinkedHashMap<>();
        try(BufferedReader br=new BufferedReader(new InputStreamReader(file.getInputStream(),StandardCharsets.UTF_8))){
            String line; boolean first=true;
            while((line=br.readLine())!=null){ if(line.isBlank()) continue; if(first && line.toLowerCase(Locale.ROOT).startsWith("rule_name")){first=false;continue;} first=false;
                String[] x=line.split(",",-1); if(x.length<7) continue; String name=x[0].trim(); if(name.isBlank()) continue; int pri=Integer.parseInt(x[1].trim()); BigDecimal pct=new BigDecimal(x[2].trim());
                AttributeDefinition d=defs.get(x[3].trim().toUpperCase(Locale.ROOT)); if(d==null) throw new IllegalArgumentException("Unknown attribute: "+x[3]);
                RuleCondition c=new RuleCondition(d.id(),d.code(),ConditionOperator.valueOf(x[4].trim().toUpperCase(Locale.ROOT)),x[5].trim(),x[6].trim());
                Pending old=pending.get(name); if(old==null) pending.put(name,new Pending(name,pri,pct,new ArrayList<>(List.of(c)))); else old.conditions().add(c);
            }
        }
        for(Pending r:pending.values()) repo.createRule(version,r.name(),r.priority(),r.pct(),r.conditions()); engines.invalidate();
        return "redirect:/rules?ruleSetId="+ruleSetId+"&imported="+pending.size();
    }

    @GetMapping(value="/export.csv",produces="text/csv") @ResponseBody
    public StreamingResponseBody export(@RequestParam(required=false) Long ruleSetId){
        long setId=ruleSetId==null?repo.defaultCommissionRuleSetId():ruleSetId; Long v=repo.activeVersionId(setId);
        return out->{var writer=new BufferedWriter(new OutputStreamWriter(out, StandardCharsets.UTF_8));writer.write("rule_id,name,priority,result_value,conditions\\n");if(v!=null)for(var r:repo.loadRules(v)){String cond=r.conditions().stream().map(c->c.attributeCode()+" "+c.operator()+" "+safe(c.value1())+(c.value2()==null?"":".."+safe(c.value2()))).reduce((a,b)->a+"; "+b).orElse("");writer.write(r.id()+",\""+safe(r.name())+"\","+r.priority()+","+r.commissionPercentage()+",\""+safe(cond)+"\"\\n");}writer.flush();};
    }
    private static String safe(String s){return s==null?"":s.replace("\"","\"\"").replace("\\n"," ");}
}
