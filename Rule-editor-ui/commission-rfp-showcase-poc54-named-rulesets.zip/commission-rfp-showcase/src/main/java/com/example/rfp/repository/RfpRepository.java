package com.example.rfp.repository;

import com.example.rfp.model.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;

@Repository
public class RfpRepository {
    private final JdbcTemplate jdbc;
    public RfpRepository(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    // -------------------------------------------------------------------------
    // Startup/backward-compatible bootstrap
    // -------------------------------------------------------------------------

    public void ensureDefaultRuleSetsAndMigrateLegacyData() {
        ensureRuleSet("COMMISSION_RULES", "Commission Rules", "Commission rate and payout qualification decisions", "COMMISSION", "DECISION", "Commission Rate", "%", true, 10);
        ensureRuleSet("TAX_RULES", "Tax Rules", "Tax rate and tax treatment decisions", "TAX", "DECISION", "Tax Rate", "%", false, 20);
        ensureRuleSet("WITHHOLDING_RULES", "Withholding Rules", "Withholding and deduction decisions", "WITHHOLDING", "DECISION", "Withholding Rate", "%", false, 30);
        ensureRuleSet("BONUS_RULES", "Bonus Rules", "Bonus and incentive decisions", "BONUS", "DECISION", "Bonus Rate", "%", false, 40);
        ensureRuleSet("ADJUSTMENT_RULES", "Adjustment Rules", "Adjustments, caps and floor decisions", "ADJUSTMENT", "DECISION", "Adjustment Rate", "%", false, 50);

        long commissionId = defaultCommissionRuleSetId();
        jdbc.update("update rule_set_version set named_rule_set_id=? where named_rule_set_id is null", commissionId);

        // Enrich old benchmark executions without touching their results.
        jdbc.update("""
                update execution_run
                   set named_rule_set_id = coalesce(named_rule_set_id, (select v.named_rule_set_id from rule_set_version v where v.id=execution_run.rule_set_id)),
                       rule_set_version_code = coalesce(rule_set_version_code, (select v.version_code from rule_set_version v where v.id=execution_run.rule_set_id))
                 where rule_set_id is not null
                """);
        jdbc.update("""
                update execution_run
                   set rule_set_key = coalesce(rule_set_key, (select rs.rule_set_key from rule_set rs where rs.id=execution_run.named_rule_set_id)),
                       verify_expected_results = coalesce(verify_expected_results, false)
                 where named_rule_set_id is not null
                """);
    }

    public void ensureAuxiliaryDemoVersions() {
        ensureActiveVersionForSet("TAX_RULES", "TAX-2026.08", "Active tax rules for the RFP demonstration");
        ensureActiveVersionForSet("WITHHOLDING_RULES", "WITHHOLDING-2026.08", "Active withholding rules for the RFP demonstration");
        ensureActiveVersionForSet("BONUS_RULES", "BONUS-2026.08", "Active bonus rules for the RFP demonstration");
        ensureActiveVersionForSet("ADJUSTMENT_RULES", "ADJUSTMENT-2026.08", "Active adjustment rules for the RFP demonstration");
    }

    private void ensureRuleSet(String key, String name, String description, String category, String ruleType,
                               String resultLabel, String resultUnit, boolean verify, int displayOrder) {
        Long count = jdbc.queryForObject("select count(*) from rule_set where rule_set_key=?", Long.class, key);
        if (count != null && count > 0) return;
        jdbc.update("""
                insert into rule_set(rule_set_key,name,description,category,rule_type,result_label,result_unit,
                                     verify_expected_results,status,display_order)
                values(?,?,?,?,?,?,?,?, 'ACTIVE', ?)
                """, key, name, description, category, ruleType, resultLabel, resultUnit, verify, displayOrder);
    }

    private void ensureActiveVersionForSet(String key, String code, String description) {
        RuleSetDefinition rs = ruleSetByKey(key);
        if (activeVersionId(rs.id()) != null) return;
        if (jdbc.queryForObject("select count(*) from rule_set_version where version_code=?", Long.class, code) > 0) {
            jdbc.update("update rule_set_version set named_rule_set_id=?,status='ACTIVE',activated_at=current_timestamp where version_code=?", rs.id(), code);
            return;
        }
        jdbc.update("insert into rule_set_version(named_rule_set_id,version_code,status,description,activated_at) values(?,?,'ACTIVE',?,current_timestamp)", rs.id(), code, description);
    }

    // -------------------------------------------------------------------------
    // Attributes
    // -------------------------------------------------------------------------

    public long attributeCount() { return jdbc.queryForObject("select count(*) from attribute_definition where active=true", Long.class); }

    public List<AttributeDefinition> attributes() {
        return jdbc.query("select id,code,display_name,data_type,source_key,allowed_operators,active from attribute_definition order by id",
                (rs,n) -> new AttributeDefinition(rs.getLong(1), rs.getString(2), rs.getString(3), AttributeDataType.valueOf(rs.getString(4)), rs.getString(5), rs.getString(6), rs.getBoolean(7)));
    }

    public AttributeDefinition attribute(long id) {
        return jdbc.queryForObject("select id,code,display_name,data_type,source_key,allowed_operators,active from attribute_definition where id=?",
                (rs,n) -> new AttributeDefinition(rs.getLong(1), rs.getString(2), rs.getString(3), AttributeDataType.valueOf(rs.getString(4)), rs.getString(5), rs.getString(6), rs.getBoolean(7)), id);
    }

    public Map<Long, AttributeDefinition> attributeMap() {
        Map<Long,AttributeDefinition> m=new LinkedHashMap<>(); for (var a:attributes()) m.put(a.id(),a); return m;
    }

    public Map<String, AttributeDefinition> attributeMapByCode() {
        Map<String,AttributeDefinition> m=new LinkedHashMap<>(); for (var a:attributes()) m.put(a.code().toUpperCase(Locale.ROOT),a); return m;
    }

    public void createAttribute(String code, String display, AttributeDataType type, String sourceKey, String operators) {
        jdbc.update("insert into attribute_definition(code,display_name,data_type,source_key,allowed_operators,active) values(?,?,?,?,?,true)",
                code.trim().toUpperCase(Locale.ROOT), display.trim(), type.name(),
                sourceKey == null ? null : sourceKey.trim().toUpperCase(Locale.ROOT), normalizeOperators(operators));
    }

    public long attributeUsageCount(long attributeId) {
        return jdbc.queryForObject("""
                select count(*)
                  from rule_condition c
                  join commission_rule r on r.id=c.rule_id
                  join rule_set_version v on v.id=r.rule_set_id
                 where c.attribute_id=? and v.status='ACTIVE'
                """, Long.class, attributeId);
    }

    public void updateAttribute(long id, String display, String sourceKey, String operators, boolean active) {
        jdbc.update("update attribute_definition set display_name=?,source_key=?,allowed_operators=?,active=? where id=?",
                display.trim(), sourceKey == null ? null : sourceKey.trim().toUpperCase(Locale.ROOT), normalizeOperators(operators), active, id);
    }

    private static String normalizeOperators(String operators) {
        return operators == null || operators.isBlank()
                ? "EQ,NE,IN,NOT_IN,IS_NULL,IS_NOT_NULL"
                : operators.toUpperCase(Locale.ROOT).replace(" ", "");
    }

    // -------------------------------------------------------------------------
    // Named rule sets and versions
    // -------------------------------------------------------------------------

    public List<RuleSetDefinition> ruleSets() {
        return jdbc.query("""
                select id,rule_set_key,name,description,category,rule_type,result_label,result_unit,
                       verify_expected_results,status,display_order
                  from rule_set
                 order by display_order,name
                """, (rs,n) -> new RuleSetDefinition(rs.getLong(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getBoolean(9),rs.getString(10),rs.getInt(11)));
    }

    public RuleSetDefinition ruleSet(long id) {
        return jdbc.queryForObject("""
                select id,rule_set_key,name,description,category,rule_type,result_label,result_unit,
                       verify_expected_results,status,display_order
                  from rule_set where id=?
                """, (rs,n) -> new RuleSetDefinition(rs.getLong(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getBoolean(9),rs.getString(10),rs.getInt(11)), id);
    }

    public RuleSetDefinition ruleSetByKey(String key) {
        return jdbc.queryForObject("""
                select id,rule_set_key,name,description,category,rule_type,result_label,result_unit,
                       verify_expected_results,status,display_order
                  from rule_set where rule_set_key=?
                """, (rs,n) -> new RuleSetDefinition(rs.getLong(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getBoolean(9),rs.getString(10),rs.getInt(11)), key.toUpperCase(Locale.ROOT));
    }

    public long defaultCommissionRuleSetId() {
        return ruleSetByKey("COMMISSION_RULES").id();
    }

    public long createRuleSet(String key, String name, String description, String category, String resultLabel, String resultUnit) {
        String normalized = key.trim().toUpperCase(Locale.ROOT).replaceAll("[^A-Z0-9_]+", "_");
        jdbc.update("""
                insert into rule_set(rule_set_key,name,description,category,rule_type,result_label,result_unit,
                                     verify_expected_results,status,display_order)
                values(?,?,?,?, 'DECISION', ?,?, false,'ACTIVE',100)
                """, normalized, name.trim(), description, category, resultLabel, resultUnit);
        return jdbc.queryForObject("select id from rule_set where rule_set_key=?", Long.class, normalized);
    }

    public List<Map<String,Object>> ruleSetSummaries() {
        return jdbc.queryForList("""
                select rs.id,rs.rule_set_key,rs.name,rs.description,rs.category,rs.result_label,rs.result_unit,rs.status,
                       v.id active_version_id,v.version_code active_version_code,
                       coalesce((select count(*) from commission_rule r where r.rule_set_id=v.id and r.status='ACTIVE'),0) rule_count,
                       coalesce((select count(*) from rule_condition c join commission_rule r on r.id=c.rule_id where r.rule_set_id=v.id),0) condition_count
                  from rule_set rs
                  left join rule_set_version v on v.named_rule_set_id=rs.id and v.status='ACTIVE'
                 order by rs.display_order,rs.name
                """);
    }

    public List<Map<String,Object>> versions() { return versions(defaultCommissionRuleSetId()); }

    public List<Map<String,Object>> versions(long namedRuleSetId) {
        return jdbc.queryForList("select * from rule_set_version where named_rule_set_id=? order by created_at desc,id desc", namedRuleSetId);
    }

    public Map<String,Object> version(long id) { return jdbc.queryForMap("select * from rule_set_version where id=?", id); }

    public Long activeVersionId() { return activeVersionId(defaultCommissionRuleSetId()); }

    public Long activeVersionId(long namedRuleSetId) {
        List<Long> ids = jdbc.query("select id from rule_set_version where named_rule_set_id=? and status='ACTIVE' order by activated_at desc,id desc limit 1",
                (rs,n)->rs.getLong(1), namedRuleSetId);
        return ids.isEmpty()?null:ids.getFirst();
    }

    public String activeVersionCode() { return activeVersionCode(defaultCommissionRuleSetId()); }

    public String activeVersionCode(long namedRuleSetId) {
        List<String> v=jdbc.query("select version_code from rule_set_version where named_rule_set_id=? and status='ACTIVE' order by activated_at desc,id desc limit 1",
                (rs,n)->rs.getString(1), namedRuleSetId);
        return v.isEmpty()?"NONE":v.getFirst();
    }

    public Long versionId(long namedRuleSetId, String versionCode) {
        List<Long> ids = jdbc.query("select id from rule_set_version where named_rule_set_id=? and upper(version_code)=upper(?)", (rs,n)->rs.getLong(1), namedRuleSetId, versionCode);
        return ids.isEmpty()?null:ids.getFirst();
    }

    public long createVersion(String code, String description) { return createVersion(defaultCommissionRuleSetId(), code, description); }

    public long createVersion(long namedRuleSetId, String code, String description) {
        jdbc.update("insert into rule_set_version(named_rule_set_id,version_code,status,description) values(?,?,'DRAFT',?)", namedRuleSetId, code, description);
        return jdbc.queryForObject("select id from rule_set_version where version_code=?", Long.class, code);
    }

    public long cloneActiveVersion(String newCode) { return cloneActiveVersion(defaultCommissionRuleSetId(), newCode); }

    public long cloneActiveVersion(long namedRuleSetId, String newCode) {
        Long active=activeVersionId(namedRuleSetId);
        if(active==null) return createVersion(namedRuleSetId,newCode,"Initial draft");
        long newId=createVersion(namedRuleSetId,newCode,"Cloned from "+activeVersionCode(namedRuleSetId));
        long offset=newId*1_000_000_000L;
        jdbc.update("insert into commission_rule(id,rule_set_id,name,priority,commission_percentage,status,created_at) select ?+id,?,name,priority,commission_percentage,status,current_timestamp from commission_rule where rule_set_id=?",offset,newId,active);
        jdbc.update("insert into rule_condition(id,rule_id,attribute_id,operator_code,value_1,value_2) select ?+c.id,?+c.rule_id,c.attribute_id,c.operator_code,c.value_1,c.value_2 from rule_condition c join commission_rule r on r.id=c.rule_id where r.rule_set_id=?",offset,offset,active);
        return newId;
    }

    public void activateVersion(long id) {
        Map<String,Object> target=version(id);
        long owner=((Number)target.get("NAMED_RULE_SET_ID")).longValue();
        jdbc.update("update rule_set_version set status='RETIRED' where named_rule_set_id=? and status='ACTIVE'", owner);
        jdbc.update("update rule_set_version set status='ACTIVE', activated_at=current_timestamp where id=?",id);
    }

    public long ruleCount(long versionId) { return jdbc.queryForObject("select count(*) from commission_rule where rule_set_id=?",Long.class,versionId); }
    public long conditionCount(long versionId) { return jdbc.queryForObject("select count(*) from rule_condition c join commission_rule r on r.id=c.rule_id where r.rule_set_id=?",Long.class,versionId); }
    public long transactionCount() { return jdbc.queryForObject("select count(*) from transaction_record",Long.class); }

    public List<Map<String,Object>> rulePage(long versionId, String search, int page, int size) {
        String q=(search==null?"":search.trim().toUpperCase(Locale.ROOT));
        return jdbc.queryForList("select r.id,r.name,r.priority,r.commission_percentage,r.status,count(c.id) condition_count from commission_rule r left join rule_condition c on c.rule_id=r.id where r.rule_set_id=? and (?='' or upper(r.name) like ? or cast(r.id as varchar)=?) group by r.id,r.name,r.priority,r.commission_percentage,r.status order by r.id limit ? offset ?",
                versionId,q,"%"+q+"%",q,size,Math.max(0,page)*size);
    }

    public RuleDefinition rule(long ruleId) {
        Map<Long,AttributeDefinition> attrs=attributeMap();
        Map<String,Object> r=jdbc.queryForMap("select id,rule_set_id,name,priority,commission_percentage from commission_rule where id=?",ruleId);
        List<RuleCondition> conditions=jdbc.query("select attribute_id,operator_code,value_1,value_2 from rule_condition where rule_id=? order by id",(rs,n)->{
            long aid=rs.getLong(1); var a=attrs.get(aid); return new RuleCondition(aid,a==null?("ATTR_"+aid):a.code(),ConditionOperator.valueOf(rs.getString(2)),rs.getString(3),rs.getString(4));
        },ruleId);
        return new RuleDefinition(((Number)r.get("ID")).longValue(),((Number)r.get("RULE_SET_ID")).longValue(),(String)r.get("NAME"),((Number)r.get("PRIORITY")).intValue(),(BigDecimal)r.get("COMMISSION_PERCENTAGE"),conditions);
    }

    public Map<String,Object> ruleContext(long ruleId) {
        return jdbc.queryForMap("""
                select r.id rule_id,v.id version_id,v.version_code,rs.id rule_set_id,rs.rule_set_key,rs.name rule_set_name,
                       rs.result_label,rs.result_unit
                  from commission_rule r
                  join rule_set_version v on v.id=r.rule_set_id
                  join rule_set rs on rs.id=v.named_rule_set_id
                 where r.id=?
                """, ruleId);
    }

    public synchronized long createRule(long versionId, String name, int priority, BigDecimal percentage, List<RuleCondition> conditions) {
        Long maxRule=jdbc.queryForObject("select max(id) from commission_rule",Long.class);
        long id=(maxRule==null?0:maxRule)+1;
        jdbc.update("insert into commission_rule(id,rule_set_id,name,priority,commission_percentage,status) values(?,?,?,?,?,'ACTIVE')",id,versionId,name,priority,percentage);
        Long maxCondition=jdbc.queryForObject("select max(id) from rule_condition",Long.class);
        long conditionId=(maxCondition==null?0:maxCondition)+1;
        for(var c:conditions) jdbc.update("insert into rule_condition(id,rule_id,attribute_id,operator_code,value_1,value_2) values(?,?,?,?,?,?)",conditionId++,id,c.attributeId(),c.operator().name(),c.value1(),c.value2());
        return id;
    }

    public List<RuleDefinition> loadRules(long versionId) {
        Map<Long,AttributeDefinition> attrs=attributeMap();
        String sql="""
                select r.id,r.rule_set_id,r.name,r.priority,r.commission_percentage,
                       c.attribute_id,c.operator_code,c.value_1,c.value_2
                  from commission_rule r
                  left join rule_condition c on c.rule_id=r.id
                 where r.rule_set_id=? and r.status='ACTIVE'
                 order by r.id,c.id
                """;
        return jdbc.query(sql, rs -> {
            List<RuleDefinition> out=new ArrayList<>();
            long currentId=Long.MIN_VALUE, currentSet=0;
            String currentName=null; int currentPriority=0; BigDecimal currentPct=null;
            List<RuleCondition> currentConditions=new ArrayList<>();
            while(rs.next()){
                long rid=rs.getLong(1);
                if(currentId!=Long.MIN_VALUE && rid!=currentId){
                    out.add(new RuleDefinition(currentId,currentSet,currentName,currentPriority,currentPct,List.copyOf(currentConditions)));
                    currentConditions=new ArrayList<>();
                }
                if(rid!=currentId){ currentId=rid; currentSet=rs.getLong(2); currentName=rs.getString(3); currentPriority=rs.getInt(4); currentPct=rs.getBigDecimal(5); }
                Object aidObj=rs.getObject(6);
                if(aidObj!=null){
                    long aid=((Number)aidObj).longValue(); var a=attrs.get(aid);
                    currentConditions.add(new RuleCondition(aid,a==null?("ATTR_"+aid):a.code(),ConditionOperator.valueOf(rs.getString(7)),rs.getString(8),rs.getString(9)));
                }
            }
            if(currentId!=Long.MIN_VALUE) out.add(new RuleDefinition(currentId,currentSet,currentName,currentPriority,currentPct,List.copyOf(currentConditions)));
            return out;
        }, versionId);
    }

    // -------------------------------------------------------------------------
    // Payout-cycle snapshots
    // -------------------------------------------------------------------------

    public long createCycle(String cycleKey, String name, String businessPeriod) {
        String key=cycleKey.trim().toUpperCase(Locale.ROOT).replaceAll("[^A-Z0-9_.-]+","-");
        jdbc.update("insert into cycle_execution(cycle_key,name,business_period,status) values(?,?,?,'READY')", key,name.trim(),businessPeriod);
        long id=jdbc.queryForObject("select id from cycle_execution where cycle_key=?",Long.class,key);
        for(RuleSetDefinition rs:ruleSets()) {
            if(!"ACTIVE".equalsIgnoreCase(rs.status())) continue;
            Long version=activeVersionId(rs.id());
            if(version==null) continue;
            String code=String.valueOf(version(version).get("VERSION_CODE"));
            jdbc.update("insert into cycle_ruleset_snapshot(cycle_id,rule_set_id,rule_set_version_id,rule_set_key,version_code) values(?,?,?,?,?)", id,rs.id(),version,rs.key(),code);
        }
        return id;
    }

    public List<Map<String,Object>> cycles() {
        return jdbc.queryForList("""
                select c.*,(select count(*) from cycle_ruleset_snapshot s where s.cycle_id=c.id) snapshot_count,
                       (select count(*) from execution_run e where e.cycle_id=c.id) execution_count
                  from cycle_execution c order by c.id desc
                """);
    }

    public Map<String,Object> cycle(long id) { return jdbc.queryForMap("select * from cycle_execution where id=?",id); }
    public Map<String,Object> cycleByKey(String key) { return jdbc.queryForMap("select * from cycle_execution where upper(cycle_key)=upper(?)",key); }

    public List<Map<String,Object>> cycleSnapshots(long cycleId) {
        return jdbc.queryForList("""
                select s.*,rs.name rule_set_name,rs.category,rs.result_label,rs.result_unit,
                       coalesce((select count(*) from commission_rule r where r.rule_set_id=s.rule_set_version_id and r.status='ACTIVE'),0) rule_count,
                       rs.display_order
                  from cycle_ruleset_snapshot s
                  join rule_set rs on rs.id=s.rule_set_id
                 where s.cycle_id=?
                 order by rs.display_order,rs.name
                """, cycleId);
    }

    public Long cycleSnapshotVersion(long cycleId,long namedRuleSetId) {
        List<Long> ids=jdbc.query("select rule_set_version_id from cycle_ruleset_snapshot where cycle_id=? and rule_set_id=?",(rs,n)->rs.getLong(1),cycleId,namedRuleSetId);
        return ids.isEmpty()?null:ids.getFirst();
    }

    public Long cycleSnapshotVersionByKey(String cycleKey,String ruleSetKey) {
        List<Long> ids=jdbc.query("""
                select s.rule_set_version_id from cycle_ruleset_snapshot s
                join cycle_execution c on c.id=s.cycle_id
                where upper(c.cycle_key)=upper(?) and upper(s.rule_set_key)=upper(?)
                """,(rs,n)->rs.getLong(1),cycleKey,ruleSetKey);
        return ids.isEmpty()?null:ids.getFirst();
    }

    public List<Map<String,Object>> transactionJourney(long cycleId,long transactionId) {
        return jdbc.queryForList("""
                select e.id run_id,e.rule_set_key,e.rule_set_version_code,e.status run_status,e.started_at,e.ended_at,
                       er.transaction_id,er.matched_rule_id,er.commission_percentage,er.candidate_count,er.matched_count,
                       er.top_rank_count,er.result_status,r.name matched_rule_name,rs.name rule_set_name,rs.result_label,rs.result_unit,
                       rs.display_order
                  from execution_run e
                  join rule_set rs on rs.id=e.named_rule_set_id
                  left join execution_result er on er.run_id=e.id and er.transaction_id=?
                  left join commission_rule r on r.id=er.matched_rule_id
                 where e.cycle_id=?
                 order by rs.display_order,e.id
                """,transactionId,cycleId);
    }

    // -------------------------------------------------------------------------
    // Execution/audit
    // -------------------------------------------------------------------------

    public List<Map<String,Object>> persistedExecutionHistory() {
        return jdbc.queryForList("select * from execution_run where persist_results=true order by id desc limit 100");
    }

    public List<Map<String,Object>> executionResults(long runId, String transactionId, String status, int page, int size) {
        StringBuilder sql = new StringBuilder("""
                select er.run_id,er.transaction_id,er.expected_rule_id,er.matched_rule_id,
                       er.commission_percentage,er.candidate_count,er.matched_count,er.top_rank_count,
                       er.evaluation_nanos,er.result_status,r.name matched_rule_name
                  from execution_result er
                  left join commission_rule r on r.id=er.matched_rule_id
                 where er.run_id=?
                """);
        List<Object> args = new ArrayList<>(); args.add(runId);
        if (status != null && !status.isBlank() && !"ALL".equalsIgnoreCase(status)) { sql.append(" and er.result_status=?"); args.add(status.toUpperCase(Locale.ROOT)); }
        if (transactionId != null && !transactionId.isBlank()) {
            try { sql.append(" and er.transaction_id=?"); args.add(Long.parseLong(transactionId.trim())); }
            catch (NumberFormatException ex) { return List.of(); }
        }
        sql.append(" order by er.transaction_id limit ? offset ?"); args.add(Math.max(1, size)); args.add(Math.max(0, page) * Math.max(1, size));
        return jdbc.queryForList(sql.toString(), args.toArray());
    }

    public Map<String,Object> executionResult(long runId, long transactionId) {
        return jdbc.queryForMap("""
                select er.*,r.name matched_rule_name,r.priority matched_rule_priority,
                       (select count(*) from rule_condition c where c.rule_id=er.matched_rule_id) matched_rule_specificity
                  from execution_result er
                  left join commission_rule r on r.id=er.matched_rule_id
                 where er.run_id=? and er.transaction_id=?
                """, runId, transactionId);
    }

    public Map<String,Object> transactionRecord(long transactionId) {
        return jdbc.queryForMap("select id,partition_id,attributes_payload,expected_rule_id from transaction_record where id=?", transactionId);
    }

    public List<Map<String,Object>> sampleExecutionResults(long runId, String status, int limit) {
        return jdbc.queryForList("""
                select er.transaction_id,er.matched_rule_id,er.commission_percentage,er.candidate_count,
                       er.matched_count,er.top_rank_count,er.result_status,r.name matched_rule_name
                  from execution_result er
                  left join commission_rule r on r.id=er.matched_rule_id
                 where er.run_id=? and er.result_status=?
                 order by er.transaction_id limit ?
                """, runId, status, Math.max(1, limit));
    }

    public List<Map<String,Object>> executionHistory() { return jdbc.queryForList("select * from execution_run order by id desc limit 100"); }
    public Map<String,Object> execution(long id) { return jdbc.queryForMap("select * from execution_run where id=?",id); }

    public void recordBatchExecution(long runId,long sequence,int partition,int worker,long firstTx,long lastTx,int txCount,
                                     long matched,long noMatch,long ambiguous,long incorrect,long readMs,long engineMs,long writeMs,long totalMs) {
        String batchKey = "RUN-"+runId+"-BATCH-"+String.format(Locale.ROOT,"%06d",sequence);
        jdbc.update("""
                insert into batch_execution(run_id,batch_sequence,batch_key,partition_id,worker_id,first_transaction_id,last_transaction_id,
                                            transaction_count,matched,no_match,ambiguous,incorrect,read_ms,engine_ms,write_ms,total_ms,status,completed_at)
                values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, 'SUCCESS', current_timestamp)
                """,runId,sequence,batchKey,partition,worker,firstTx,lastTx,txCount,matched,noMatch,ambiguous,incorrect,readMs,engineMs,writeMs,totalMs);
    }

    public List<Map<String,Object>> batchExecutions(long runId,int limit) {
        return jdbc.queryForList("select * from batch_execution where run_id=? order by batch_sequence limit ?",runId,Math.max(1,limit));
    }

    public long completedBatchCount(long runId) {
        Long n=jdbc.queryForObject("select count(*) from batch_execution where run_id=?",Long.class,runId);
        return n==null?0:n;
    }

    public long createExecution(long versionId,long namedRuleSetId,Long cycleId,int workers,int batch,boolean persist,long sla,boolean verifyExpected) {
        RuleSetDefinition rs=ruleSet(namedRuleSetId);
        String versionCode=String.valueOf(version(versionId).get("VERSION_CODE"));
        GeneratedKeyHolder keys=new GeneratedKeyHolder();
        jdbc.update(con -> {
            var ps=con.prepareStatement("insert into execution_run(rule_set_id,named_rule_set_id,rule_set_key,rule_set_version_code,cycle_id,engine_type,status,workers,batch_size,persist_results,sla_seconds,verify_expected_results,created_at) values(?,?,?,?,?,'SPARSE_INDEXED','QUEUED',?,?,?,?,?,current_timestamp)", new String[]{"ID"});
            ps.setLong(1,versionId);ps.setLong(2,namedRuleSetId);ps.setString(3,rs.key());ps.setString(4,versionCode);
            if(cycleId==null) ps.setNull(5,java.sql.Types.BIGINT); else ps.setLong(5,cycleId);
            ps.setInt(6,workers);ps.setInt(7,batch);ps.setBoolean(8,persist);ps.setLong(9,sla);ps.setBoolean(10,verifyExpected);return ps;
        },keys);
        Number key=keys.getKey();if(key==null)throw new IllegalStateException("Execution insert did not return an ID");return key.longValue();
    }

    // Legacy signature retained for older controller/service code while POC #5.4 migrates callers.
    public long createExecution(long versionId,int workers,int batch,boolean persist,long sla) {
        long named=ruleSetIdForVersion(versionId);
        return createExecution(versionId,named,null,workers,batch,persist,sla,ruleSet(named).verifyExpectedResults());
    }

    public long ruleSetIdForVersion(long versionId) {
        return jdbc.queryForObject("select named_rule_set_id from rule_set_version where id=?",Long.class,versionId);
    }

    public void markRunning(long id,long rules,long attrs,long activeAttrs,long tx,long compileMs,double heap,long batchCount) {
        jdbc.update("update execution_run set status='RUNNING',started_at=current_timestamp,rule_count=?,attribute_count=?,active_attribute_count=?,transaction_count=?,engine_compile_ms=?,heap_after_engine_mb=?,batch_count=? where id=?",rules,attrs,activeAttrs,tx,compileMs,heap,batchCount,id);
    }

    public void markRunning(long id,long rules,long attrs,long activeAttrs,long tx,long compileMs,double heap) {
        markRunning(id,rules,attrs,activeAttrs,tx,compileMs,heap,0);
    }

    public void progress(long id,long processed,long matched,long noMatch,long ambiguous,long incorrect,double avgCandidates,int maxCandidates,double throughput,long readMs,long engineMs,long writeMs) {
        jdbc.update("update execution_run set processed=?,matched=?,no_match=?,ambiguous=?,incorrect=?,avg_candidates=?,max_candidates=?,throughput=?,db_read_ms=?,engine_ms=?,db_write_ms=? where id=?",processed,matched,noMatch,ambiguous,incorrect,avgCandidates,maxCandidates,throughput,readMs,engineMs,writeMs,id);
    }

    public void finish(long id,long processed,long matched,long noMatch,long ambiguous,long incorrect,double avgCandidates,int maxCandidates,long readMs,long engineMs,long writeMs,long processingMs,long totalMs,double throughput,String message) {
        jdbc.update("update execution_run set status='SUCCESS',processed=?,matched=?,no_match=?,ambiguous=?,incorrect=?,avg_candidates=?,max_candidates=?,db_read_ms=?,engine_ms=?,db_write_ms=?,processing_ms=?,total_ms=?,throughput=?,ended_at=current_timestamp,message=? where id=?",
                processed,matched,noMatch,ambiguous,incorrect,avgCandidates,maxCandidates,readMs,engineMs,writeMs,processingMs,totalMs,throughput,message,id);
    }

    public void fail(long id,String message) { jdbc.update("update execution_run set status='FAILED',ended_at=current_timestamp,message=? where id=?",message,id); }
}
