package com.example.rfp.web;

import com.example.rfp.model.AttributeDefinition;
import com.example.rfp.repository.RfpRepository;
import com.example.rfp.service.EvaluationService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@Controller
@RequestMapping("/tester")
public class TesterController {
    private final RfpRepository repo; private final EvaluationService eval;
    public TesterController(RfpRepository repo, EvaluationService eval) { this.repo=repo; this.eval=eval; }

    @GetMapping public String page(@RequestParam(required=false) Long ruleSetId,Model m) {
        long setId=ruleSetId==null?repo.defaultCommissionRuleSetId():ruleSetId;
        addBase(m,setId); return "tester";
    }

    @PostMapping
    public String test(@RequestParam long ruleSetId,
                       @RequestParam(required=false) List<String> attributeCode,
                       @RequestParam(required=false) List<String> value,
                       Model m) {
        addBase(m,ruleSetId); Map<String, AttributeDefinition> defs=repo.attributeMapByCode(); List<Long> ids=new ArrayList<>(); List<String> values=new ArrayList<>();
        if(attributeCode!=null && value!=null){for(int i=0;i<Math.min(attributeCode.size(),value.size());i++){String code=attributeCode.get(i)==null?"":attributeCode.get(i).trim().toUpperCase(Locale.ROOT);String actual=value.get(i);if(code.isBlank() || actual==null || actual.isBlank()) continue;AttributeDefinition d=defs.get(code);if(d==null){m.addAttribute("error","Unknown attribute: "+code);return "tester";}ids.add(d.id());values.add(actual);}}
        if(ids.isEmpty()){m.addAttribute("error","Enter at least one transaction attribute and value.");return "tester";}
        m.addAttribute("result",eval.evaluate(ruleSetId,ids,values)); return "tester";
    }

    private void addBase(Model m,long setId){m.addAttribute("attributes",repo.attributes());m.addAttribute("ruleSets",repo.ruleSetSummaries());m.addAttribute("selectedRuleSet",repo.ruleSet(setId));m.addAttribute("selectedRuleSetId",setId);m.addAttribute("activeVersion",repo.activeVersionCode(setId));}
}
