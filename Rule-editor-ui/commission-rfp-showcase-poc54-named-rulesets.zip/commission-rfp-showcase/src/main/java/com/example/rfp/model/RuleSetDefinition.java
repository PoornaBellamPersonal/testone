package com.example.rfp.model;

public record RuleSetDefinition(
        long id,
        String key,
        String name,
        String description,
        String category,
        String ruleType,
        String resultLabel,
        String resultUnit,
        boolean verifyExpectedResults,
        String status,
        int displayOrder) {
    public String resultDisplayLabel() {
        return resultUnit == null || resultUnit.isBlank() ? resultLabel : resultLabel + " (" + resultUnit + ")";
    }
}
