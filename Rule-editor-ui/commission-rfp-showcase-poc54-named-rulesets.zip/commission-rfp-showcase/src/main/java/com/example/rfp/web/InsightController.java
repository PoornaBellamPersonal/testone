package com.example.rfp.web;

import com.example.rfp.repository.RfpRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@Controller
@RequestMapping("/insights")
public class InsightController {
    private final RfpRepository repo;

    public InsightController(RfpRepository repo) { this.repo = repo; }

    @GetMapping
    public String page(@RequestParam(required = false) Long runId, Model model) {
        List<Map<String,Object>> runs = repo.persistedExecutionHistory();
        Long selected = runId;
        if (selected == null && !runs.isEmpty()) selected = ((Number) runs.getFirst().get("ID")).longValue();
        model.addAttribute("runs", runs);
        model.addAttribute("selectedRun", selected);
        if (selected != null) {
            model.addAttribute("run", repo.execution(selected));
            model.addAttribute("noMatchSamples", repo.sampleExecutionResults(selected, "NO_MATCH", 8));
            model.addAttribute("ambiguousSamples", repo.sampleExecutionResults(selected, "MATCHED_AMBIGUOUS", 8));
            model.addAttribute("incorrectSamples", repo.sampleExecutionResults(selected, "INCORRECT", 8));
        }
        return "insights";
    }
}
