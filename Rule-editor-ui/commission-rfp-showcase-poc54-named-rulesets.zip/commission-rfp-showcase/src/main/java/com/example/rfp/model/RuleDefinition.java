package com.example.rfp.model;

import java.math.BigDecimal;
import java.util.List;

public record RuleDefinition(long id, long ruleSetId, String name, int priority, BigDecimal commissionPercentage, List<RuleCondition> conditions) {
    public int specificity() { return conditions == null ? 0 : conditions.size(); }
}
