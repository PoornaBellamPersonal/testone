package com.example.rfp.web;

import com.example.rfp.repository.RfpRepository;
import com.example.rfp.service.BatchExecutionService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@Controller
@RequestMapping("/executions")
public class ExecutionController {
    private final RfpRepository repo;private final BatchExecutionService batch;
    public ExecutionController(RfpRepository repo,BatchExecutionService batch){this.repo=repo;this.batch=batch;}

    @GetMapping
    public String history(@RequestParam(required=false) Long ruleSetId,@RequestParam(required=false) Long cycleId,Model m){
        long selected=ruleSetId==null?repo.defaultCommissionRuleSetId():ruleSetId;
        m.addAttribute("runs",repo.executionHistory());m.addAttribute("txCount",repo.transactionCount());
        m.addAttribute("ruleSets",repo.ruleSetSummaries());m.addAttribute("selectedRuleSetId",selected);
        m.addAttribute("cycles",repo.cycles());m.addAttribute("selectedCycleId",cycleId);
        return "executions";
    }

    @PostMapping
    public String start(@RequestParam long ruleSetId,
                        @RequestParam(required=false) Long cycleId,
                        @RequestParam(defaultValue="8") int workers,
                        @RequestParam(defaultValue="5000") int batchSize,
                        @RequestParam(defaultValue="true") boolean persistResults){
        long id=batch.start(ruleSetId,cycleId,Math.max(1,workers),Math.max(100,batchSize),persistResults);return "redirect:/executions/"+id;
    }

    @GetMapping("/{id}") public String detail(@PathVariable long id,Model m){
        Map<String,Object> run=repo.execution(id);m.addAttribute("run",run);
        Object named=run.get("NAMED_RULE_SET_ID");if(named instanceof Number n) m.addAttribute("ruleSet",repo.ruleSet(n.longValue()));
        if(run.get("CYCLE_ID") instanceof Number c) m.addAttribute("cycle",repo.cycle(c.longValue()));
        m.addAttribute("batches",repo.batchExecutions(id,100));
        m.addAttribute("completedBatchCount",repo.completedBatchCount(id));
        return "execution-detail";
    }
    @GetMapping("/{id}/progress") @ResponseBody public Map<String,Object> progress(@PathVariable long id){return repo.execution(id);}
}
