package com.example.rfp.model;

import java.util.List;

/** Complete, on-demand explanation of one decision. */
public record DecisionAudit(EvaluationResult result, List<CandidateEvaluation> candidates) {
}
