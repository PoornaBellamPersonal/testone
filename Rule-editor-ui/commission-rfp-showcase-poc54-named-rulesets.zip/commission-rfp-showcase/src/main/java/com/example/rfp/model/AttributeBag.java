package com.example.rfp.model;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

public final class AttributeBag {
    private final Map<Long, String> values;

    public AttributeBag(Map<Long, String> values) {
        this.values = Collections.unmodifiableMap(new LinkedHashMap<>(values));
    }

    public String get(long attributeId) { return values.get(attributeId); }
    public boolean contains(long attributeId) { return values.containsKey(attributeId); }
    public Map<Long, String> values() { return values; }
    public int size() { return values.size(); }
}
