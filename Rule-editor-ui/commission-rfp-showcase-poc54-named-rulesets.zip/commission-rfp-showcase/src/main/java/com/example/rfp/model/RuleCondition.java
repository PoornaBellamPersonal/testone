package com.example.rfp.model;

public record RuleCondition(long attributeId, String attributeCode, ConditionOperator operator, String value1, String value2) {
    public boolean matches(AttributeBag bag) { return operator.matches(bag.get(attributeId), value1, value2); }
}
