package com.example.rfp.web;

import com.example.rfp.repository.RfpRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/cycles")
public class CycleController {
    private final RfpRepository repo;
    public CycleController(RfpRepository repo){this.repo=repo;}

    @GetMapping public String list(Model m){m.addAttribute("cycles",repo.cycles());return "cycles";}

    @PostMapping public String create(@RequestParam String cycleKey,@RequestParam String name,@RequestParam(defaultValue="") String businessPeriod){long id=repo.createCycle(cycleKey,name,businessPeriod);return "redirect:/cycles/"+id;}

    @GetMapping("/{id}") public String detail(@PathVariable long id,@RequestParam(required=false) Long transactionId,Model m){
        m.addAttribute("cycle",repo.cycle(id));m.addAttribute("snapshots",repo.cycleSnapshots(id));m.addAttribute("runs",repo.executionHistory());
        if(transactionId!=null){m.addAttribute("transactionId",transactionId);m.addAttribute("journey",repo.transactionJourney(id,transactionId));}
        return "cycle-detail";
    }
}
