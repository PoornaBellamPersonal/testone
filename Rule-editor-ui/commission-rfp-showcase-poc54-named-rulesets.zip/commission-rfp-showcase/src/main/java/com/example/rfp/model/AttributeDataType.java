package com.example.rfp.model;

public enum AttributeDataType { STRING, DECIMAL, INTEGER, BOOLEAN, DATE }
