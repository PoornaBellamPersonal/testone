package com.example.rfp.codec;

import com.example.rfp.model.AttributeBag;
import java.util.LinkedHashMap;
import java.util.Map;

public final class SparsePayloadCodec {
    private SparsePayloadCodec() {}

    public static String encode(Map<Long, String> values) {
        StringBuilder b = new StringBuilder(values.size() * 16);
        for (var e : values.entrySet()) {
            if (b.length() > 0) b.append('|');
            b.append(e.getKey()).append('=').append(escape(e.getValue()));
        }
        return b.toString();
    }

    public static AttributeBag decode(String payload) {
        Map<Long, String> values = new LinkedHashMap<>();
        if (payload == null || payload.isBlank()) return new AttributeBag(values);
        for (String pair : payload.split("\\|")) {
            int eq = pair.indexOf('=');
            if (eq <= 0) continue;
            long id = Long.parseLong(pair.substring(0, eq));
            values.put(id, unescape(pair.substring(eq + 1)));
        }
        return new AttributeBag(values);
    }

    private static String escape(String v) {
        return v == null ? "" : v.replace("%", "%25").replace("|", "%7C").replace("=", "%3D");
    }

    private static String unescape(String v) {
        return v.replace("%3D", "=").replace("%7C", "|").replace("%25", "%");
    }
}
