package com.example.rfp.service;

import com.example.rfp.model.AttributeDataType;
import java.time.LocalDate;
import java.util.*;

/**
 * Near-real attribute metadata used only by the RFP data generator.
 * The execution engine itself remains fully metadata driven.
 */
public final class NearRealAttributeCatalog {
    private NearRealAttributeCatalog() {}

    public record Spec(long id, String code, String displayName, AttributeDataType type, String allowedOperators) {}

    private static final String[] CORE = {
            "CARRIER_CODE","PRODUCT_FAMILY","PRODUCT_CODE","ISSUE_STATE","ANNUAL_PREMIUM",
            "DISTRIBUTION_CHANNEL","PRODUCER_TYPE","PRODUCER_LEVEL","REGISTRATION_TYPE","TRANSACTION_TYPE",
            "EFFECTIVE_DATE","POLICY_STATUS","PREMIUM_MODE","CUSTOMER_SEGMENT","COMPENSATION_PROGRAM_CODE",
            "PRODUCTION_YTD","ISSUE_AGE","POLICY_DURATION_MONTHS","NEW_BUSINESS_FLAG","MARKET_SEGMENT",
            "APPLICATION_TYPE","UNDERWRITING_CLASS","RISK_CLASS","CURRENCY_CODE","PAYMENT_METHOD",
            "POLICY_YEAR","CASE_TYPE","BUSINESS_LINE","SOURCE_SYSTEM","PROCESSING_PERIOD"
    };

    private static final Map<String,String[]> DOMAINS = new LinkedHashMap<>();
    static {
        DOMAINS.put("POLICY", new String[]{"SUB_STATUS","ISSUE_DATE","PAID_TO_DATE","MATURITY_DATE","FACE_AMOUNT","CASH_VALUE","LOAN_BALANCE","RIDERS_COUNT","REPLACEMENT_FLAG","CONVERSION_FLAG","REINSTATEMENT_FLAG","EXCHANGE_FLAG","OWNER_TYPE","INSURED_COUNT","BILLING_METHOD","DRAFT_DAY","GRACE_STATUS","SURRENDER_STATUS","LAPSE_REASON","TAX_QUALIFICATION","JURISDICTION","LANGUAGE","DELIVERY_METHOD","E_SIGN_FLAG","PAPERLESS_FLAG","SPECIAL_HANDLING_FLAG","SERVICE_TIER","ANNIVERSARY_MONTH","TERM_LENGTH_YEARS","BENEFIT_OPTION"});
        DOMAINS.put("PRODUCT", new String[]{"CATEGORY","SUB_CATEGORY","SERIES","VERSION","PLAN_CODE","PLAN_VARIANT","RATE_CLASS","GUARANTEE_PERIOD","INDEX_STRATEGY","FUND_CLASS","RIDER_PACKAGE","MIN_PREMIUM","MAX_PREMIUM","MIN_FACE_AMOUNT","MAX_FACE_AMOUNT","TARGET_PREMIUM","BAND_CODE","COMMISSIONABLE_FLAG","BONUS_ELIGIBLE_FLAG","STATE_APPROVAL_STATUS","LAUNCH_DATE","CLOSE_DATE","TAX_TYPE","ACCOUNT_TYPE","SURRENDER_SCHEDULE","CHARGE_CLASS","FEATURE_SET","SEGMENT","PORTFOLIO","RISK_BUCKET"});
        DOMAINS.put("TRANSACTION", new String[]{"DATE","AMOUNT","SEQUENCE","SUB_TYPE","SOURCE","CHANNEL","REASON","STATUS","REVERSAL_FLAG","BACKDATED_FLAG","CORRECTION_FLAG","BATCH_ID","ORIGINAL_DATE","EFFECTIVE_DATE","POSTING_DATE","SETTLEMENT_DATE","PREMIUM_AMOUNT","COMMISSIONABLE_AMOUNT","NET_AMOUNT","GROSS_AMOUNT","TAX_AMOUNT","FEE_AMOUNT","UNITS","PERCENTAGE","FREQUENCY","ORIGIN_SYSTEM","REFERENCE_TYPE","PRIORITY","MONTH_END_FLAG","SPECIAL_CASE_FLAG"});
        DOMAINS.put("PRODUCER", new String[]{"ID_TYPE","STATUS","APPOINTMENT_STATUS","RESIDENT_STATE","WRITING_STATE","LICENSE_CLASS","LICENSE_EXPIRY_DATE","TENURE_YEARS","START_DATE","TERMINATION_DATE","HIERARCHY_LEVEL","HIERARCHY_PATH","MANAGER_LEVEL","AGENCY_CODE","BRANCH_CODE","REGION_CODE","TERRITORY_CODE","PRODUCTION_BAND","QUALITY_BAND","PERSISTENCY_BAND","SALES_TIER","BONUS_TIER","CONTRACT_TYPE","PAYEE_TYPE","SPLIT_PERCENTAGE","ADVANCE_ELIGIBLE_FLAG","CHARGEBACK_ELIGIBLE_FLAG","SPECIALIST_FLAG","NEW_PRODUCER_FLAG","COMPLIANCE_STATUS"});
        DOMAINS.put("DISTRIBUTION", new String[]{"ORGANIZATION","SUB_CHANNEL","AGENCY","BRANCH","REGION","TERRITORY","MARKET","SALES_OFFICE","PARTNER_CODE","BANK_CODE","BROKER_DEALER","IMO_CODE","BGA_CODE","TEAM_CODE","COST_CENTER","PROFIT_CENTER","HIERARCHY_LEVEL","COMPENSATION_MODEL","SERVICE_MODEL","DIGITAL_FLAG","AFFILIATION_TYPE","NETWORK","SEGMENT","TIER","START_DATE","END_DATE","ACTIVE_FLAG","EXCLUSIVE_FLAG","STRATEGIC_FLAG","SPECIAL_PROGRAM"});
        DOMAINS.put("CUSTOMER", new String[]{"TYPE","AGE","AGE_BAND","RESIDENCE_STATE","RESIDENCE_COUNTRY","CITIZENSHIP","PROFILE_SEGMENT","SUB_SEGMENT","NET_WORTH_BAND","INCOME_BAND","OCCUPATION_CLASS","INDUSTRY","RISK_SCORE","RISK_BAND","LOYALTY_TIER","RELATIONSHIP_YEARS","EXISTING_POLICY_COUNT","TOTAL_PREMIUM","TOTAL_FACE_AMOUNT","HOUSEHOLD_FLAG","BUSINESS_OWNER_FLAG","TRUST_FLAG","CORPORATE_FLAG","VIP_FLAG","PREFERRED_LANGUAGE","MARKETING_OPT_IN_FLAG","DIGITAL_ADOPTION_SCORE","SERVICE_TIER","SOURCE","REFERRAL_TYPE"});
        DOMAINS.put("COMPENSATION", new String[]{"TYPE","PLAN","SCHEDULE","RATE_TYPE","BASE_RATE","BONUS_RATE","OVERRIDE_RATE","ADVANCE_RATE","CHARGEBACK_RATE","CAP_AMOUNT","FLOOR_AMOUNT","MAX_RATE","MIN_RATE","VESTING_PERCENTAGE","SPLIT_PERCENTAGE","HOLD_PERIOD_DAYS","PAY_FREQUENCY","PAYEE_LEVEL","BONUS_ELIGIBLE_FLAG","OVERRIDE_ELIGIBLE_FLAG","ADVANCE_FLAG","CHARGEBACK_FLAG","TRAIL_FLAG","RENEWAL_FLAG","FIRST_YEAR_FLAG","SPECIAL_RATE_FLAG","GRID_CODE","BAND_CODE","FORMULA_CODE","ROUNDING_METHOD"});
        DOMAINS.put("CONTRACT", new String[]{"CODE","TYPE","STATUS","START_DATE","END_DATE","LEVEL","TIER","VERSION","COMP_PLAN","ADVANCE_PLAN","CHARGEBACK_PLAN","RENEWAL_PLAN","BONUS_PLAN","SPLIT_RULE","ASSIGNMENT_TYPE","PAYEE_ID","PAYEE_TYPE","HIERARCHY_LEVEL","GUARANTEE_FLAG","MINIMUM_GUARANTEE","MAXIMUM_PAYOUT","CAP_PERCENTAGE","VESTING_SCHEDULE","TRAIL_SCHEDULE","STATE_SCOPE","PRODUCT_SCOPE","CHANNEL_SCOPE","AMENDMENT_COUNT","LAST_AMENDMENT_DATE","SPECIAL_TERMS_FLAG"});
        DOMAINS.put("COMPLIANCE", new String[]{"SUITABILITY_STATUS","AML_STATUS","KYC_STATUS","LICENSE_STATUS","APPOINTMENT_STATUS","TRAINING_STATUS","BACKGROUND_STATUS","DISCLOSURE_STATUS","REPLACEMENT_REVIEW_STATUS","BEST_INTEREST_STATUS","STATE_REQUIREMENT_STATUS","PRODUCT_TRAINING_STATUS","CE_STATUS","SANCTIONS_STATUS","FRAUD_SCORE","FRAUD_BAND","RISK_SCORE","RISK_BAND","EXCEPTION_FLAG","EXCEPTION_TYPE","REVIEW_DATE","EXPIRY_DATE","APPROVAL_LEVEL","APPROVER_TYPE","MANUAL_REVIEW_FLAG","ESCALATION_FLAG","HOLD_FLAG","RESTRICTION_CODE","AUDIT_STATUS","SOURCE_SYSTEM"});
    }

    private static final List<Spec> ALL_SPECS = buildAllSpecs();

    public static List<Spec> specs(int count) {
        if (count < 1 || count > 300) throw new IllegalArgumentException("Attribute count must be between 1 and 300");
        return List.copyOf(ALL_SPECS.subList(0, count));
    }

    public static Spec spec(long id) { return ALL_SPECS.get(Math.toIntExact(id - 1)); }

    private static List<Spec> buildAllSpecs() {
        List<String> codes = new ArrayList<>(300);
        codes.addAll(Arrays.asList(CORE));
        DOMAINS.forEach((prefix, suffixes) -> {
            for (String suffix : suffixes) codes.add(prefix + "_" + suffix);
        });
        if (codes.size() != 300) throw new IllegalStateException("Catalog must contain exactly 300 attributes but has " + codes.size());
        Set<String> uniqueCodes = new LinkedHashSet<>(codes);
        if (uniqueCodes.size() != codes.size()) {
            Set<String> duplicates = new LinkedHashSet<>();
            Set<String> seen = new HashSet<>();
            for (String code : codes) {
                if (!seen.add(code)) duplicates.add(code);
            }
            throw new IllegalStateException("Attribute catalog contains duplicate codes: " + duplicates);
        }
        List<Spec> out = new ArrayList<>(300);
        for (int i = 0; i < codes.size(); i++) {
            String code = codes.get(i);
            AttributeDataType type = inferType(code);
            out.add(new Spec(i + 1L, code, pretty(code), type, operators(type)));
        }
        return List.copyOf(out);
    }

    public static String generatedValue(long attributeId, int seed) {
        Spec s = spec(attributeId);
        String code = s.code();
        return switch (s.type()) {
            case BOOLEAN -> Boolean.toString(Math.floorMod(seed, 3) != 0);
            case INTEGER -> Integer.toString(integerValue(code, seed));
            case DECIMAL -> decimalValue(code, seed);
            case DATE -> LocalDate.of(2025 + Math.floorMod(seed, 4), 1 + Math.floorMod(seed * 7, 12), 1 + Math.floorMod(seed * 11, 27)).toString();
            case STRING -> stringValue(code, seed);
        };
    }

    private static int integerValue(String code, int seed) {
        if (code.contains("AGE")) return 18 + Math.floorMod(seed, 63);
        if (code.contains("MONTH")) return 1 + Math.floorMod(seed, 360);
        if (code.contains("YEAR")) return 1 + Math.floorMod(seed, 30);
        if (code.contains("COUNT")) return Math.floorMod(seed, 12);
        if (code.contains("DAY")) return 1 + Math.floorMod(seed, 31);
        if (code.contains("LEVEL") || code.contains("PRIORITY")) return 1 + Math.floorMod(seed, 10);
        return Math.floorMod(seed * 17, 1000);
    }

    private static String decimalValue(String code, int seed) {
        long base;
        if (code.contains("PERCENT") || code.contains("RATE")) base = 50 + Math.floorMod(seed * 13L, 2500);
        else if (code.contains("SCORE")) base = Math.floorMod(seed * 17L, 10000);
        else if (code.contains("PREMIUM")) base = 25_000L + Math.floorMod(seed * 7919L, 2_000_000L);
        else if (code.contains("FACE_AMOUNT")) base = 100_000L + Math.floorMod(seed * 104729L, 5_000_000L);
        else base = 1_000L + Math.floorMod(seed * 3571L, 5_000_000L);
        return Long.toString(base);
    }

    private static String stringValue(String code, int seed) {
        if (code.contains("STATE")) return STATES[Math.floorMod(seed, STATES.length)];
        if (code.contains("COUNTRY")) return pick(seed, "USA","CANADA","MEXICO","UK","INDIA");
        if (code.contains("STATUS")) return pick(seed, "ACTIVE","APPROVED","PENDING","IN_GOOD_STANDING","REVIEW_REQUIRED");
        if (code.contains("CHANNEL")) return pick(seed, "AGENCY","BROKER","DIRECT","BANK","DIGITAL","PARTNER");
        if (code.contains("TIER")) return pick(seed, "STANDARD","SILVER","GOLD","PLATINUM","ELITE");
        if (code.contains("BAND")) return pick(seed, "LOW","STANDARD","HIGH","PREMIER","SPECIAL");
        if (code.contains("TYPE")) return pick(seed, "INDIVIDUAL","CORPORATE","BROKER","AGENCY","SPECIAL");
        if (code.contains("CLASS")) return pick(seed, "PREFERRED","STANDARD","SELECT","SPECIAL","RESTRICTED");
        if (code.contains("SEGMENT")) return pick(seed, "MASS","AFFLUENT","HNW","SMALL_BUSINESS","INSTITUTIONAL");
        if (code.contains("LANGUAGE")) return pick(seed, "ENGLISH","SPANISH","FRENCH","HINDI","OTHER");
        if (code.contains("CURRENCY")) return pick(seed, "USD","CAD","EUR","GBP","INR");
        if (code.contains("METHOD") || code.contains("MODE")) return pick(seed, "MONTHLY","QUARTERLY","SEMI_ANNUAL","ANNUAL","EFT");
        if (code.contains("REGION")) return pick(seed, "NORTHEAST","SOUTHEAST","MIDWEST","SOUTH","WEST");
        return code.replace("_", "-") + "-" + String.format("%02d", Math.floorMod(seed, 12) + 1);
    }

    private static String pick(int seed, String... values) { return values[Math.floorMod(seed, values.length)]; }

    private static AttributeDataType inferType(String code) {
        String c = code.toUpperCase(Locale.ROOT);
        if (c.endsWith("_FLAG") || c.endsWith("_INDICATOR")) return AttributeDataType.BOOLEAN;
        if (c.endsWith("_DATE") || c.contains("EXPIRY_DATE") || c.contains("START_DATE") || c.contains("END_DATE")) return AttributeDataType.DATE;
        if (containsAny(c,"AMOUNT","PREMIUM","BALANCE","VALUE","RATE","PERCENTAGE","SCORE","PAYOUT","GUARANTEE","PRODUCTION")) return AttributeDataType.DECIMAL;
        if (containsAny(c,"AGE","COUNT","MONTHS","YEARS","SEQUENCE","DAYS","POLICY_YEAR","DRAFT_DAY","PRIORITY")) return AttributeDataType.INTEGER;
        return AttributeDataType.STRING;
    }

    private static boolean containsAny(String s, String... tokens) { for (String t : tokens) if (s.contains(t)) return true; return false; }
    private static String operators(AttributeDataType type) {
        return switch (type) {
            case STRING -> "EQ,NE,IN,NOT_IN,IS_NULL,IS_NOT_NULL";
            case BOOLEAN -> "EQ,NE,IS_NULL,IS_NOT_NULL";
            case DATE, DECIMAL, INTEGER -> "EQ,NE,GT,GE,LT,LE,BETWEEN,IS_NULL,IS_NOT_NULL";
        };
    }
    private static String pretty(String code) {
        StringBuilder b = new StringBuilder();
        for (String p : code.toLowerCase(Locale.ROOT).split("_")) {
            if (!p.isEmpty()) b.append(Character.toUpperCase(p.charAt(0))).append(p.substring(1)).append(' ');
        }
        return b.toString().trim();
    }

    private static final String[] STATES = {"AL","AK","AZ","AR","CA","CO","CT","DE","FL","GA","HI","ID","IL","IN","IA","KS","KY","LA","ME","MD","MA","MI","MN","MS","MO","MT","NE","NV","NH","NJ","NM","NY","NC","ND","OH","OK","OR","PA","RI","SC","SD","TN","TX","UT","VT","VA","WA","WV","WI","WY"};
}
