package com.example.rfp.model;

import java.math.BigDecimal;
import java.util.List;

/**
 * Explainability view for a rule that survived indexed candidate reduction.
 * This is generated on demand for a single audited transaction and is not
 * persisted for every batch row.
 */
public record CandidateEvaluation(
        long ruleId,
        String ruleName,
        int priority,
        int specificity,
        BigDecimal commissionPercentage,
        boolean matched,
        boolean winner,
        String reason,
        List<ConditionTrace> traces) {
}
