package com.example.rfp.web;

import com.example.rfp.repository.RfpRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/rule-sets")
public class RuleSetController {
    private final RfpRepository repo;
    public RuleSetController(RfpRepository repo){this.repo=repo;}

    @GetMapping public String list(Model m){m.addAttribute("ruleSets",repo.ruleSetSummaries());return "rule-sets";}

    @GetMapping("/{id}") public String detail(@PathVariable long id,Model m){
        m.addAttribute("ruleSet",repo.ruleSet(id));m.addAttribute("versions",repo.versions(id));
        Long active=repo.activeVersionId(id);m.addAttribute("activeVersionId",active);m.addAttribute("activeVersion",active==null?null:repo.version(active));
        m.addAttribute("ruleCount",active==null?0:repo.ruleCount(active));m.addAttribute("conditionCount",active==null?0:repo.conditionCount(active));
        return "rule-set-detail";
    }

    @GetMapping("/new") public String createForm(){return "rule-set-new";}

    @PostMapping public String create(@RequestParam String ruleSetKey,@RequestParam String name,@RequestParam(defaultValue="") String description,
                                      @RequestParam(defaultValue="GENERAL") String category,@RequestParam(defaultValue="Result") String resultLabel,
                                      @RequestParam(defaultValue="") String resultUnit,@RequestParam String initialVersion){
        long id=repo.createRuleSet(ruleSetKey,name,description,category,resultLabel,resultUnit);long version=repo.createVersion(id,initialVersion,"Initial version");repo.activateVersion(version);return "redirect:/rule-sets/"+id;
    }
}
