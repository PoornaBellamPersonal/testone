package com.example.rfp.web;

import com.example.rfp.model.AttributeBag;
import com.example.rfp.model.AttributeDefinition;
import com.example.rfp.model.EvaluationResult;
import com.example.rfp.repository.RfpRepository;
import com.example.rfp.service.EngineRegistry;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/v1/rule-sets")
public class RuleExecutionApiController {
    private final RfpRepository repo; private final EngineRegistry engines;
    public RuleExecutionApiController(RfpRepository repo,EngineRegistry engines){this.repo=repo;this.engines=engines;}

    @PostMapping("/{ruleSetKey}/evaluate-batch")
    public ResponseEntity<?> evaluateBatch(@PathVariable String ruleSetKey,@RequestBody Map<String,Object> request){
        var ruleSet=repo.ruleSetByKey(ruleSetKey);
        String cycleKey=text(request.get("cycleKey")); String requestedVersion=text(request.get("versionCode")); String batchId=text(request.get("batchId"));
        Long versionId;
        if(!cycleKey.isBlank()) versionId=repo.cycleSnapshotVersionByKey(cycleKey,ruleSet.key());
        else if(!requestedVersion.isBlank()) versionId=repo.versionId(ruleSet.id(),requestedVersion);
        else versionId=repo.activeVersionId(ruleSet.id());
        if(versionId==null) return ResponseEntity.badRequest().body(Map.of("error","No applicable rule-set version was found"));

        Object txObj=request.get("transactions");
        if(!(txObj instanceof List<?> txs) || txs.isEmpty()) return ResponseEntity.badRequest().body(Map.of("error","transactions must contain at least one transaction"));
        if(txs.size()>10_000) return ResponseEntity.badRequest().body(Map.of("error","RFP demo API accepts at most 10,000 transactions per synchronous request"));

        Map<String,AttributeDefinition> attrs=repo.attributeMapByCode(); var engine=engines.engine(versionId); List<Map<String,Object>> results=new ArrayList<>(txs.size());
        long started=System.nanoTime(); long matched=0,noMatch=0;
        for(Object txRaw:txs){
            if(!(txRaw instanceof Map<?,?> tx)) continue;
            String transactionId=text(tx.get("transactionId")); Object rawAttrs=tx.get("attributes"); Map<Long,String> bagValues=new LinkedHashMap<>();
            if(rawAttrs instanceof Map<?,?> am){
                for(var e:am.entrySet()){
                    String code=text(e.getKey()).toUpperCase(Locale.ROOT); AttributeDefinition d=attrs.get(code); if(d==null) continue;
                    Object value=e.getValue(); if(value!=null) bagValues.put(d.id(),String.valueOf(value));
                }
            }
            EvaluationResult r=engine.evaluate(new AttributeBag(bagValues),false); if(r.matchedRuleId()==null) noMatch++; else matched++;
            Map<String,Object> row=new LinkedHashMap<>(); row.put("transactionId",transactionId); row.put("matchedRuleId",r.matchedRuleId()); row.put("resultValue",r.commissionPercentage()); row.put("candidateCount",r.candidateCount()); row.put("matchedCount",r.matchedCount()); row.put("status",r.status()); results.add(row);
        }
        long durationMs=(System.nanoTime()-started)/1_000_000; String versionCode=String.valueOf(repo.version(versionId).get("VERSION_CODE"));
        Map<String,Object> response=new LinkedHashMap<>();response.put("ruleSetKey",ruleSet.key());response.put("ruleSetName",ruleSet.name());response.put("versionCode",versionCode);response.put("cycleKey",cycleKey.isBlank()?null:cycleKey);response.put("batchId",batchId);response.put("processed",results.size());response.put("matched",matched);response.put("noMatch",noMatch);response.put("durationMs",durationMs);response.put("results",results);
        return ResponseEntity.ok(response);
    }

    private static String text(Object o){return o==null?"":String.valueOf(o).trim();}
}
