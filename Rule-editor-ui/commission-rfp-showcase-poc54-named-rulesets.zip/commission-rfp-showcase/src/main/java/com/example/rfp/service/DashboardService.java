package com.example.rfp.service;

import com.example.rfp.repository.RfpRepository;
import org.springframework.stereotype.Service;
import java.util.LinkedHashMap;
import java.util.Map;

@Service
public class DashboardService {
    private final RfpRepository repo; private final EngineRegistry engines;
    public DashboardService(RfpRepository repo,EngineRegistry engines){this.repo=repo;this.engines=engines;}
    public Map<String,Object> snapshot(){
        Map<String,Object> m=new LinkedHashMap<>(); long commissionSet=repo.defaultCommissionRuleSetId(); Long v=repo.activeVersionId(commissionSet);
        m.put("activeVersion",repo.activeVersionCode(commissionSet));m.put("attributes",repo.attributeCount());m.put("transactions",repo.transactionCount());
        m.put("rules",v==null?0:repo.ruleCount(v));m.put("conditions",v==null?0:repo.conditionCount(v));m.put("ruleSets",repo.ruleSetSummaries());m.put("ruleSetCount",repo.ruleSets().size());m.put("cycleCount",repo.cycles().size());
        var h=repo.executionHistory();m.put("lastRun",h.isEmpty()?null:h.getFirst());if(v!=null) engines.peekStats(v).ifPresent(stats -> m.put("engineStats", stats));return m;
    }
}
