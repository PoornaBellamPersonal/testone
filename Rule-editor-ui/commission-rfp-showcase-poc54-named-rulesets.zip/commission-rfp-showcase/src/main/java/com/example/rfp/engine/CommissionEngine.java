package com.example.rfp.engine;

import com.example.rfp.model.AttributeBag;
import com.example.rfp.model.DecisionAudit;
import com.example.rfp.model.EngineStats;
import com.example.rfp.model.EvaluationResult;

public interface CommissionEngine {
    EvaluationResult evaluate(AttributeBag transaction, boolean explain);
    DecisionAudit explain(AttributeBag transaction, int maxCandidates);
    EngineStats stats();
}
