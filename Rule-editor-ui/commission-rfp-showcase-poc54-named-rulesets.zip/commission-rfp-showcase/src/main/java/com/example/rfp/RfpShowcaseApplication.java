package com.example.rfp;

import com.example.rfp.repository.RfpRepository;
import com.example.rfp.service.DemoDataSeeder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.core.annotation.Order;
import org.springframework.scheduling.annotation.EnableAsync;

@SpringBootApplication
@EnableAsync
public class RfpShowcaseApplication {
    public static void main(String[] args) { SpringApplication.run(RfpShowcaseApplication.class, args); }

    @Bean
    @Order(0)
    CommandLineRunner ruleSetBootstrap(RfpRepository repo, DemoDataSeeder seeder) {
        return args -> {
            repo.ensureDefaultRuleSetsAndMigrateLegacyData();
            repo.ensureAuxiliaryDemoVersions();
            seeder.ensureAuxiliaryRuleSamples();
        };
    }

    @Bean
    @Order(10)
    CommandLineRunner seedRunner(DemoDataSeeder seeder,
                                 @Value("${rfp.demo.seed-profile:none}") String profile,
                                 @Value("${rfp.demo.reset:false}") boolean reset,
                                 @Value("${rfp.demo.exit-after-seed:false}") boolean exit) {
        return args -> {
            if (!"none".equalsIgnoreCase(profile)) {
                seeder.seedProfile(profile, reset);
                if (exit) System.exit(0);
            }
        };
    }
}
