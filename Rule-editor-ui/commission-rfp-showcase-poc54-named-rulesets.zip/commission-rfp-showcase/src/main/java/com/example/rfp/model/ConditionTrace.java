package com.example.rfp.model;

public record ConditionTrace(String attributeCode, String operator, String expected, String actual, boolean matched) {}
