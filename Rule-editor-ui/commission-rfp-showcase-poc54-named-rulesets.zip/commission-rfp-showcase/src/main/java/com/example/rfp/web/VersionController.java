package com.example.rfp.web;

import com.example.rfp.repository.RfpRepository;
import com.example.rfp.service.EngineRegistry;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/versions")
public class VersionController {
    private final RfpRepository repo;private final EngineRegistry engines;
    public VersionController(RfpRepository repo,EngineRegistry engines){this.repo=repo;this.engines=engines;}

    @GetMapping public String list(@RequestParam(required=false) Long ruleSetId,Model m){
        long setId=ruleSetId==null?repo.defaultCommissionRuleSetId():ruleSetId;
        m.addAttribute("ruleSets",repo.ruleSetSummaries());m.addAttribute("selectedRuleSet",repo.ruleSet(setId));m.addAttribute("selectedRuleSetId",setId);
        m.addAttribute("versions",repo.versions(setId));return "versions";
    }

    @PostMapping("/clone") public String clone(@RequestParam long ruleSetId,@RequestParam String versionCode){repo.cloneActiveVersion(ruleSetId,versionCode);return "redirect:/versions?ruleSetId="+ruleSetId;}
    @PostMapping("/{id}/activate") public String activate(@PathVariable long id){var v=repo.version(id);long set=((Number)v.get("NAMED_RULE_SET_ID")).longValue();repo.activateVersion(id);engines.invalidate();return "redirect:/versions?ruleSetId="+set;}
}
