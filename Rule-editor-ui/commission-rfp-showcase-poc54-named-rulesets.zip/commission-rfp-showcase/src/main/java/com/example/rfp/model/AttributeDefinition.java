package com.example.rfp.model;

public record AttributeDefinition(long id, String code, String displayName, AttributeDataType dataType, String sourceKey, String allowedOperators, boolean active) {}
