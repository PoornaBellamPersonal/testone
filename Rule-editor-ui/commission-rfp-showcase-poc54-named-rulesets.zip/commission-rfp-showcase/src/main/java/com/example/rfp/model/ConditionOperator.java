package com.example.rfp.model;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Locale;

public enum ConditionOperator {
    EQ, NE, IN, NOT_IN, GT, GE, LT, LE, BETWEEN, IS_NULL, IS_NOT_NULL;

    public boolean isEqualityIndexable() {
        return this == EQ || this == IN;
    }

    public boolean matches(String actual, String value1, String value2) {
        return switch (this) {
            case IS_NULL -> actual == null || actual.isBlank();
            case IS_NOT_NULL -> actual != null && !actual.isBlank();
            case EQ -> actual != null && normalize(actual).equals(normalize(value1));
            case NE -> actual != null && !normalize(actual).equals(normalize(value1));
            case IN -> actual != null && Arrays.stream(split(value1)).anyMatch(v -> normalize(actual).equals(normalize(v)));
            case NOT_IN -> actual != null && Arrays.stream(split(value1)).noneMatch(v -> normalize(actual).equals(normalize(v)));
            case GT -> actual != null && compareNumber(actual, value1) > 0;
            case GE -> actual != null && compareNumber(actual, value1) >= 0;
            case LT -> actual != null && compareNumber(actual, value1) < 0;
            case LE -> actual != null && compareNumber(actual, value1) <= 0;
            case BETWEEN -> actual != null && compareNumber(actual, value1) >= 0 && compareNumber(actual, value2) <= 0;
        };
    }

    public static String normalize(String value) {
        return value == null ? "" : value.trim().toUpperCase(Locale.ROOT);
    }

    public static String[] split(String value) {
        return value == null ? new String[0] : value.split("\\s*[,|]\\s*");
    }

    private static int compareNumber(String actual, String expected) {
        if (actual == null || expected == null) return Integer.MIN_VALUE;
        try {
            return new BigDecimal(actual.trim()).compareTo(new BigDecimal(expected.trim()));
        } catch (NumberFormatException ex) {
            return normalize(actual).compareTo(normalize(expected));
        }
    }
}
