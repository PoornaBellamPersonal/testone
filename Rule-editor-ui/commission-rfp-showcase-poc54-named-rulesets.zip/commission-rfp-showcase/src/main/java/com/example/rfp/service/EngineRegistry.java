package com.example.rfp.service;

import com.example.rfp.engine.CommissionEngine;
import com.example.rfp.engine.SparseIndexedCommissionEngine;
import com.example.rfp.repository.RfpRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class EngineRegistry {
    private final RfpRepository repo;
    private final int maxIndexed;
    private final boolean cacheEnabled;
    private final ConcurrentHashMap<Long, CommissionEngine> cache = new ConcurrentHashMap<>();

    public EngineRegistry(RfpRepository repo,
                          @Value("${rfp.engine.max-indexed-attributes:48}") int maxIndexed,
                          @Value("${rfp.engine.cache-enabled:true}") boolean cacheEnabled) {
        this.repo=repo; this.maxIndexed=maxIndexed; this.cacheEnabled=cacheEnabled;
    }
    public CommissionEngine engine(long versionId) {
        if (!cacheEnabled) return compile(versionId);
        return cache.computeIfAbsent(versionId,this::compile);
    }
    public java.util.Optional<com.example.rfp.model.EngineStats> peekStats(long versionId) {
        CommissionEngine e = cache.get(versionId);
        return e == null ? java.util.Optional.empty() : java.util.Optional.of(e.stats());
    }
    public void invalidate() { cache.clear(); }
    private CommissionEngine compile(long versionId) { return new SparseIndexedCommissionEngine(repo.loadRules(versionId),maxIndexed); }
}
