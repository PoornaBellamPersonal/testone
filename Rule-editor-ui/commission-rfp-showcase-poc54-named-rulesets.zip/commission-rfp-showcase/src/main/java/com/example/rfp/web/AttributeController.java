package com.example.rfp.web;

import com.example.rfp.model.AttributeDataType;
import com.example.rfp.repository.RfpRepository;
import com.example.rfp.service.EngineRegistry;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/attributes")
public class AttributeController {
    private final RfpRepository repo;
    private final EngineRegistry engines;

    public AttributeController(RfpRepository repo, EngineRegistry engines){this.repo=repo;this.engines=engines;}

    @GetMapping
    public String list(Model m){
        m.addAttribute("attributes",repo.attributes());
        m.addAttribute("types",AttributeDataType.values());
        return "attributes";
    }

    @PostMapping
    public String create(@RequestParam String code,
                         @RequestParam String displayName,
                         @RequestParam AttributeDataType dataType,
                         @RequestParam(required=false) String sourceKey,
                         @RequestParam(defaultValue="EQ,NE,IN") String operators){
        repo.createAttribute(code,displayName,dataType,sourceKey,operators);
        engines.invalidate();
        return "redirect:/attributes?created";
    }

    @GetMapping("/{id}/edit")
    public String edit(@PathVariable long id, Model m){
        m.addAttribute("attribute",repo.attribute(id));
        m.addAttribute("usageCount",repo.attributeUsageCount(id));
        return "attribute-edit";
    }

    @PostMapping("/{id}")
    public String update(@PathVariable long id,
                         @RequestParam String displayName,
                         @RequestParam(required=false) String sourceKey,
                         @RequestParam String operators,
                         @RequestParam(defaultValue="false") boolean active,
                         Model m){
        long usage=repo.attributeUsageCount(id);
        if(!active && usage>0){
            m.addAttribute("attribute",repo.attribute(id));
            m.addAttribute("usageCount",usage);
            m.addAttribute("error","This attribute is referenced by "+usage+" active rule conditions and cannot be deactivated.");
            return "attribute-edit";
        }
        repo.updateAttribute(id,displayName,sourceKey,operators,active);
        engines.invalidate();
        return "redirect:/attributes?updated";
    }
}
