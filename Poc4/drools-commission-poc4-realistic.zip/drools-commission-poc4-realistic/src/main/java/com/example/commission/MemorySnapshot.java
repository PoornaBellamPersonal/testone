package com.example.commission;

import java.lang.management.ManagementFactory;
import java.lang.management.MemoryUsage;

public record MemorySnapshot(long heapUsed, long heapCommitted, long nonHeapUsed) {
    public static MemorySnapshot capture() {
        MemoryUsage heap = ManagementFactory.getMemoryMXBean().getHeapMemoryUsage();
        MemoryUsage nonHeap = ManagementFactory.getMemoryMXBean().getNonHeapMemoryUsage();
        return new MemorySnapshot(heap.getUsed(), heap.getCommitted(), nonHeap.getUsed());
    }

    public static MemorySnapshot afterGc() {
        System.gc();
        try { Thread.sleep(500); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        return capture();
    }

    public double heapUsedMb() { return heapUsed / 1024.0 / 1024.0; }
    public double heapCommittedMb() { return heapCommitted / 1024.0 / 1024.0; }
    public double nonHeapUsedMb() { return nonHeapUsed / 1024.0 / 1024.0; }
}
