package com.example.commission;

import org.kie.api.runtime.KieSession;
import org.kie.api.runtime.rule.FactHandle;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public final class H2BatchProcessor {
    private final H2BenchmarkConfig config;
    private final H2Database database;
    private final DatabaseRuleSessions ruleSessions;

    public H2BatchProcessor(H2BenchmarkConfig config, H2Database database, DatabaseRuleSessions ruleSessions) {
        this.config = config;
        this.database = database;
        this.ruleSessions = ruleSessions;
    }

    public DbBenchmarkResult process() throws Exception {
        database.clearResults();
        List<Callable<DbPartitionResult>> tasks = new ArrayList<>();
        for (int partition = 0; partition < config.partitions(); partition++) {
            int p = partition;
            tasks.add(() -> processPartition(p));
        }

        ExecutorService pool = Executors.newFixedThreadPool(Math.min(config.workerThreads(), tasks.size()));
        long started = System.nanoTime();
        try {
            List<Future<DbPartitionResult>> futures = pool.invokeAll(tasks);
            long transactions = 0, matched = 0, noMatch = 0, incorrect = 0;
            long multipleMatches = 0, topRankAmbiguous = 0, totalCandidates = 0;
            int maxCandidates = 0;
            long readNanos = 0, engineNanos = 0, writeNanos = 0;
            List<Long> batchTotals = new ArrayList<>();

            for (Future<DbPartitionResult> future : futures) {
                DbPartitionResult result;
                try {
                    result = future.get();
                } catch (ExecutionException e) {
                    Throwable cause = e.getCause();
                    if (cause instanceof Exception ex) throw ex;
                    throw new RuntimeException(cause);
                }
                transactions += result.transactions();
                matched += result.matched();
                noMatch += result.noMatch();
                incorrect += result.incorrect();
                multipleMatches += result.multipleMatches();
                topRankAmbiguous += result.topRankAmbiguous();
                totalCandidates += result.totalCandidates();
                maxCandidates = Math.max(maxCandidates, result.maxCandidates());
                readNanos += result.readNanos();
                engineNanos += result.engineNanos();
                writeNanos += result.writeNanos();
                batchTotals.addAll(result.batchTotalNanos());
            }

            long elapsed = System.nanoTime() - started;
            Collections.sort(batchTotals);
            MemorySnapshot afterRun = MemorySnapshot.afterGc();
            return new DbBenchmarkResult(
                    transactions, matched, noMatch, incorrect,
                    multipleMatches, topRankAmbiguous, totalCandidates, maxCandidates,
                    elapsed, readNanos, engineNanos, writeNanos,
                    transactions / (elapsed / 1_000_000_000.0),
                    percentileMillis(batchTotals, 0.50),
                    percentileMillis(batchTotals, 0.95),
                    percentileMillis(batchTotals, 0.99),
                    afterRun
            );
        } finally {
            pool.shutdownNow();
        }
    }

    private DbPartitionResult processPartition(int partition) throws SQLException {
        String selectSql = "SELECT " + CommissionSql.TRANSACTION_COLUMNS + " "
                + "FROM COMMISSION_TRANSACTION "
                + "WHERE PARTITION_ID = ? AND TRANSACTION_ID > ? "
                + "ORDER BY TRANSACTION_ID LIMIT ?";
        String insertSql = """
                INSERT INTO COMMISSION_RESULT
                (TRANSACTION_ID, EXPECTED_RULE_ID, MATCHED_RULE_ID,
                 COMMISSION_PERCENTAGE, WINNING_PRIORITY, WINNING_SPECIFICITY,
                 CANDIDATE_COUNT, TOP_RANK_COUNT, RESULT_STATUS)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """;

        KieSession session = ruleSessions.session(partition);
        long transactionsProcessed = 0, matched = 0, noMatch = 0, incorrect = 0;
        long multipleMatches = 0, topRankAmbiguous = 0, totalCandidates = 0;
        int maxCandidates = 0;
        long totalRead = 0, totalEngine = 0, totalWrite = 0;
        List<Long> batchTotals = new ArrayList<>();
        long lastTransactionId = 0;

        try (Connection connection = database.connect();
             PreparedStatement select = connection.prepareStatement(selectSql);
             PreparedStatement insert = connection.prepareStatement(insertSql)) {
            connection.setAutoCommit(false);
            select.setFetchSize(config.readBatchSize());

            while (true) {
                long batchStarted = System.nanoTime();
                long readStarted = System.nanoTime();
                List<CommissionTransaction> batch = new ArrayList<>(config.readBatchSize());
                select.setInt(1, partition);
                select.setLong(2, lastTransactionId);
                select.setInt(3, config.readBatchSize());
                try (ResultSet rs = select.executeQuery()) {
                    while (rs.next()) {
                        CommissionTransaction tx = JdbcMappers.mapTransaction(rs);
                        batch.add(tx);
                        lastTransactionId = tx.getTransactionId();
                    }
                }
                totalRead += System.nanoTime() - readStarted;
                if (batch.isEmpty()) break;

                long engineStarted = System.nanoTime();
                FactHandle[] handles = new FactHandle[batch.size()];
                for (int i = 0; i < batch.size(); i++) handles[i] = session.insert(batch.get(i));
                session.fireAllRules();
                for (FactHandle handle : handles) session.delete(handle);
                totalEngine += System.nanoTime() - engineStarted;

                long writeStarted = System.nanoTime();
                int pending = 0;
                for (CommissionTransaction tx : batch) {
                    String status;
                    if (tx.getExpectedRuleId() < 0) {
                        if (tx.getMatchedRuleId() == -1) {
                            noMatch++;
                            status = "NO_MATCH";
                        } else {
                            incorrect++;
                            status = "INCORRECT";
                        }
                    } else if (tx.getMatchedRuleId() == tx.getExpectedRuleId()) {
                        matched++;
                        status = tx.getTopRankCount() > 1 ? "MATCHED_AMBIGUOUS" : "MATCHED";
                    } else {
                        incorrect++;
                        status = "INCORRECT";
                    }

                    if (tx.getCandidateCount() > 1) multipleMatches++;
                    if (tx.getTopRankCount() > 1) topRankAmbiguous++;
                    totalCandidates += tx.getCandidateCount();
                    maxCandidates = Math.max(maxCandidates, tx.getCandidateCount());

                    insert.setLong(1, tx.getTransactionId());
                    insert.setInt(2, tx.getExpectedRuleId());
                    insert.setInt(3, tx.getMatchedRuleId());
                    if (Double.isNaN(tx.getCommissionPercentage())) insert.setNull(4, Types.DOUBLE);
                    else insert.setDouble(4, tx.getCommissionPercentage());
                    if (tx.getMatchedRuleId() < 0) {
                        insert.setNull(5, Types.INTEGER);
                        insert.setNull(6, Types.INTEGER);
                    } else {
                        insert.setInt(5, tx.getWinningPriority());
                        insert.setInt(6, tx.getWinningSpecificity());
                    }
                    insert.setInt(7, tx.getCandidateCount());
                    insert.setInt(8, tx.getTopRankCount());
                    insert.setString(9, status);
                    insert.addBatch();
                    if (++pending == config.writeBatchSize()) {
                        insert.executeBatch();
                        pending = 0;
                    }
                }
                if (pending > 0) insert.executeBatch();
                connection.commit();
                totalWrite += System.nanoTime() - writeStarted;

                transactionsProcessed += batch.size();
                batchTotals.add(System.nanoTime() - batchStarted);
            }
        }

        System.out.printf("Partition %02d completed: %,d tx; avg candidates %.2f; max %d%n",
                partition, transactionsProcessed,
                transactionsProcessed == 0 ? 0.0 : (double) totalCandidates / transactionsProcessed,
                maxCandidates);
        return new DbPartitionResult(
                transactionsProcessed, matched, noMatch, incorrect,
                multipleMatches, topRankAmbiguous, totalCandidates, maxCandidates,
                totalRead, totalEngine, totalWrite, batchTotals
        );
    }

    private static double percentileMillis(List<Long> values, double quantile) {
        if (values.isEmpty()) return 0.0;
        int index = (int) Math.ceil(quantile * values.size()) - 1;
        index = Math.max(0, Math.min(values.size() - 1, index));
        return values.get(index) / 1_000_000.0;
    }
}
