package com.example.commission;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.Instant;
import java.util.Locale;

public final class H2CsvResultWriter {
    private H2CsvResultWriter() {}

    public static void append(
            Path path,
            H2BenchmarkConfig c,
            SeedResult seed,
            DatabaseRuleSessions sessions,
            DbBenchmarkResult result,
            double dbSizeMb) throws IOException {
        boolean exists = Files.exists(path);
        Path parent = path.toAbsolutePath().getParent();
        if (parent != null) Files.createDirectories(parent);
        StringBuilder out = new StringBuilder();
        if (!exists) {
            out.append("timestamp,rules,transactions,partitions,threads,readBatch,writeBatch,seedBatch,")
                    .append("noMatchPercent,hotPartition,hotSharePercent,")
                    .append("ruleSeedMs,transactionSeedMs,baseBuildMs,ruleLoadMs,maxPartitionRuleLoadMs,")
                    .append("heapAfterRuleLoadMB,elapsedMs,tps,cumulativeReadMs,cumulativeEngineMs,cumulativeWriteMs,")
                    .append("p50BatchMs,p95BatchMs,p99BatchMs,matched,noMatch,incorrect,multipleMatches,")
                    .append("topRankAmbiguous,avgCandidates,maxCandidates,heapAfterRunMB,dbSizeMB\n");
        }
        out.append(Instant.now()).append(',')
                .append(c.ruleCount()).append(',')
                .append(c.transactionCount()).append(',')
                .append(c.partitions()).append(',')
                .append(c.workerThreads()).append(',')
                .append(c.readBatchSize()).append(',')
                .append(c.writeBatchSize()).append(',')
                .append(c.seedBatchSize()).append(',')
                .append(fmt(c.noMatchPercent())).append(',')
                .append(c.hotPartition()).append(',')
                .append(fmt(c.hotSharePercent())).append(',')
                .append(seed.ruleSeedMillis()).append(',')
                .append(seed.transactionSeedMillis()).append(',')
                .append(sessions.baseBuildMillis()).append(',')
                .append(sessions.totalRuleLoadMillis()).append(',')
                .append(sessions.maxPartitionRuleLoadMillis()).append(',')
                .append(fmt(sessions.afterRuleLoad().heapUsedMb())).append(',')
                .append(result.elapsedNanos() / 1_000_000L).append(',')
                .append(fmt(result.transactionsPerSecond())).append(',')
                .append(result.readNanos() / 1_000_000L).append(',')
                .append(result.engineNanos() / 1_000_000L).append(',')
                .append(result.writeNanos() / 1_000_000L).append(',')
                .append(fmt(result.p50BatchMillis())).append(',')
                .append(fmt(result.p95BatchMillis())).append(',')
                .append(fmt(result.p99BatchMillis())).append(',')
                .append(result.matched()).append(',')
                .append(result.noMatch()).append(',')
                .append(result.incorrect()).append(',')
                .append(result.multipleMatches()).append(',')
                .append(result.topRankAmbiguous()).append(',')
                .append(fmt(result.averageCandidatesPerTransaction())).append(',')
                .append(result.maxCandidates()).append(',')
                .append(fmt(result.afterRun().heapUsedMb())).append(',')
                .append(fmt(dbSizeMb)).append('\n');
        Files.writeString(path, out.toString(), StandardCharsets.UTF_8,
                StandardOpenOption.CREATE, StandardOpenOption.APPEND);
    }

    private static String fmt(double value) {
        return String.format(Locale.ROOT, "%.3f", value);
    }
}
