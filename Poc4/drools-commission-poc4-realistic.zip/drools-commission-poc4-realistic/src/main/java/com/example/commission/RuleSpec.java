package com.example.commission;

/**
 * One persisted business commission definition.
 *
 * <p>POC #4 stores five deliberately overlapping rows per logical rule group:
 * one exact winner, three wildcard/range variants and one exact fallback/tie row.
 * This creates realistic multiple-match work while retaining a deterministic expected winner.</p>
 */
public record RuleSpec(
        int ruleId,
        String ruleType,
        int priority,
        int specificity,
        String carrier,
        String product,
        String state,
        String channel,
        String agentType,
        String registrationType,
        String commissionType,
        String transactionType,
        String policyType,
        String currency,
        String planCode,
        String producerLevel,
        String customerSegment,
        String paymentMode,
        boolean renewal,
        boolean replacement,
        boolean specialProgram,
        boolean internalBusiness,
        double premiumMin,
        double premiumMax,
        double faceAmountMin,
        double faceAmountMax,
        double productionAmountMin,
        double productionAmountMax,
        int policyDurationMin,
        int policyDurationMax,
        int issueAgeMin,
        int issueAgeMax,
        long effectiveEpochDayMin,
        long effectiveEpochDayMax,
        double commissionPercentage
) {
    public static final String ANY = "*";
    public static final int RULES_PER_GROUP = 5;

    public static RuleSpec fromRuleId(int ruleId) {
        if (ruleId < 0) throw new IllegalArgumentException("ruleId must be >= 0");
        int groupId = ruleId / RULES_PER_GROUP;
        int variant = ruleId % RULES_PER_GROUP;
        RuleSpec base = exactBase(groupId, groupId * RULES_PER_GROUP);

        return switch (variant) {
            case 0 -> base;
            case 1 -> new RuleSpec(
                    ruleId,
                    groupId % 10 == 0 ? "PRIORITY_OVERRIDE" : "GEO_WILDCARD",
                    groupId % 10 == 0 ? 110 : 80,
                    22,
                    base.carrier(), base.product(), ANY, ANY,
                    base.agentType(), base.registrationType(), base.commissionType(), base.transactionType(),
                    base.policyType(), base.currency(), base.planCode(), base.producerLevel(),
                    base.customerSegment(), base.paymentMode(),
                    base.renewal(), base.replacement(), base.specialProgram(), base.internalBusiness(),
                    expandMin(base.premiumMin(), 100_000), expandMax(base.premiumMax(), 100_000),
                    expandMin(base.faceAmountMin(), 500_000), expandMax(base.faceAmountMax(), 500_000),
                    base.productionAmountMin(), base.productionAmountMax(),
                    base.policyDurationMin(), base.policyDurationMax(), base.issueAgeMin(), base.issueAgeMax(),
                    base.effectiveEpochDayMin() - 365, base.effectiveEpochDayMax() + 365,
                    base.commissionPercentage() + 0.25
            );
            case 2 -> new RuleSpec(
                    ruleId, "DISTRIBUTION_WILDCARD", 70, 21,
                    base.carrier(), base.product(), base.state(), base.channel(),
                    ANY, ANY, base.commissionType(), base.transactionType(),
                    base.policyType(), base.currency(), base.planCode(), base.producerLevel(),
                    base.customerSegment(), ANY,
                    base.renewal(), base.replacement(), base.specialProgram(), base.internalBusiness(),
                    base.premiumMin(), base.premiumMax(), base.faceAmountMin(), base.faceAmountMax(),
                    expandMin(base.productionAmountMin(), 300_000), expandMax(base.productionAmountMax(), 300_000),
                    Math.max(0, base.policyDurationMin() - 24), base.policyDurationMax() + 24,
                    base.issueAgeMin(), base.issueAgeMax(),
                    base.effectiveEpochDayMin(), base.effectiveEpochDayMax(),
                    base.commissionPercentage() - 0.10
            );
            case 3 -> new RuleSpec(
                    ruleId, "POLICY_WILDCARD", 60, 21,
                    base.carrier(), base.product(), base.state(), base.channel(),
                    base.agentType(), base.registrationType(), base.commissionType(), base.transactionType(),
                    ANY, base.currency(), base.planCode(), ANY, ANY, base.paymentMode(),
                    base.renewal(), base.replacement(), base.specialProgram(), base.internalBusiness(),
                    expandMin(base.premiumMin(), 250_000), expandMax(base.premiumMax(), 250_000),
                    expandMin(base.faceAmountMin(), 1_000_000), expandMax(base.faceAmountMax(), 1_000_000),
                    expandMin(base.productionAmountMin(), 500_000), expandMax(base.productionAmountMax(), 500_000),
                    Math.max(0, base.policyDurationMin() - 36), base.policyDurationMax() + 36,
                    Math.max(0, base.issueAgeMin() - 10), base.issueAgeMax() + 10,
                    base.effectiveEpochDayMin() - 730, base.effectiveEpochDayMax() + 730,
                    base.commissionPercentage() - 0.20
            );
            case 4 -> new RuleSpec(
                    ruleId,
                    groupId % 4 == 0 ? "EXACT_TIE" : "EXACT_FALLBACK",
                    groupId % 4 == 0 ? 100 : 90,
                    24,
                    base.carrier(), base.product(), base.state(), base.channel(),
                    base.agentType(), base.registrationType(), base.commissionType(), base.transactionType(),
                    base.policyType(), base.currency(), base.planCode(), base.producerLevel(),
                    base.customerSegment(), base.paymentMode(),
                    base.renewal(), base.replacement(), base.specialProgram(), base.internalBusiness(),
                    base.premiumMin(), base.premiumMax(), base.faceAmountMin(), base.faceAmountMax(),
                    base.productionAmountMin(), base.productionAmountMax(),
                    base.policyDurationMin(), base.policyDurationMax(), base.issueAgeMin(), base.issueAgeMax(),
                    base.effectiveEpochDayMin(), base.effectiveEpochDayMax(),
                    base.commissionPercentage() + 0.50
            );
            default -> throw new IllegalStateException("Unexpected variant: " + variant);
        };
    }

    /** Expected deterministic winner for a transaction generated from this logical group. */
    public static int expectedWinnerRuleId(int groupId) {
        return groupId * RULES_PER_GROUP + (groupId % 10 == 0 ? 1 : 0);
    }

    public static int groupCountForRuleCount(int ruleCount) {
        if (ruleCount % RULES_PER_GROUP != 0) {
            throw new IllegalArgumentException("rules must be divisible by " + RULES_PER_GROUP);
        }
        return ruleCount / RULES_PER_GROUP;
    }

    public int groupId() {
        return ruleId / RULES_PER_GROUP;
    }

    public int partition(int partitionCount) {
        int carrierIndex = Integer.parseInt(carrier.substring(3));
        return carrierIndex % partitionCount;
    }

    private static RuleSpec exactBase(int groupId, int ruleId) {
        int[] x = RuleDimensions.exactIndexes(groupId);
        long mixed = RuleDimensions.mixedKey(groupId);

        int premiumBand = (int) ((mixed >>> 3) % 20);
        int faceBand = (int) ((mixed >>> 9) % 20);
        int productionBand = (int) ((mixed >>> 15) % 20);
        int durationBand = (int) ((mixed >>> 21) % 10);
        int ageBand = (int) ((mixed >>> 27) % 12);
        int effectiveYearOffset = (int) ((mixed >>> 33) % 6);

        double premiumMin = premiumBand * 50_000.0;
        double faceMin = faceBand * 250_000.0;
        double productionMin = productionBand * 100_000.0;
        int durationMin = durationBand * 12;
        int ageMin = 18 + ageBand * 4;
        long effectiveMin = 19_723L + effectiveYearOffset * 365L;

        return new RuleSpec(
                ruleId, "EXACT", 100, 24,
                RuleDimensions.CARRIERS[x[0]],
                RuleDimensions.PRODUCTS[x[1]],
                RuleDimensions.STATES[x[2]],
                RuleDimensions.CHANNELS[x[3]],
                RuleDimensions.AGENT_TYPES[x[4]],
                RuleDimensions.REGISTRATION_TYPES[x[5]],
                RuleDimensions.COMMISSION_TYPES[x[6]],
                RuleDimensions.TRANSACTION_TYPES[x[7]],
                RuleDimensions.POLICY_TYPES[x[8]],
                RuleDimensions.CURRENCIES[x[9]],
                "PLAN" + groupId,
                RuleDimensions.PRODUCER_LEVELS[x[11]],
                RuleDimensions.CUSTOMER_SEGMENTS[x[12]],
                RuleDimensions.PAYMENT_MODES[x[13]],
                (mixed & 1L) == 0,
                (mixed & 2L) == 0,
                (mixed & 4L) == 0,
                (mixed & 8L) == 0,
                premiumMin, premiumMin + 49_999.99,
                faceMin, faceMin + 249_999.99,
                productionMin, productionMin + 99_999.99,
                durationMin, durationMin + 11,
                ageMin, ageMin + 3,
                effectiveMin, effectiveMin + 364,
                0.50 + (groupId % 1500) / 100.0
        );
    }

    private static double expandMin(double value, double amount) {
        return Math.max(0.0, value - amount);
    }

    private static double expandMax(double value, double amount) {
        return value + amount;
    }
}
