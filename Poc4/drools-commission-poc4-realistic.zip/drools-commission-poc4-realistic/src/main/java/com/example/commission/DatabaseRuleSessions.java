package com.example.commission;

import org.drools.model.codegen.ExecutableModelProject;
import org.kie.api.KieBase;
import org.kie.api.KieBaseConfiguration;
import org.kie.api.KieServices;
import org.kie.api.io.ResourceType;
import org.kie.api.runtime.KieSession;
import org.kie.internal.utils.KieHelper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public final class DatabaseRuleSessions implements AutoCloseable {
    private final KieBase kieBase;
    private final KieSession[] sessions;
    private final long baseBuildMillis;
    private final long totalRuleLoadMillis;
    private final long maxPartitionRuleLoadMillis;
    private final long loadedRules;
    private final MemorySnapshot afterBaseBuild;
    private final MemorySnapshot afterRuleLoad;

    private DatabaseRuleSessions(
            KieBase kieBase,
            KieSession[] sessions,
            long baseBuildMillis,
            long totalRuleLoadMillis,
            long maxPartitionRuleLoadMillis,
            long loadedRules,
            MemorySnapshot afterBaseBuild,
            MemorySnapshot afterRuleLoad) {
        this.kieBase = kieBase;
        this.sessions = sessions;
        this.baseBuildMillis = baseBuildMillis;
        this.totalRuleLoadMillis = totalRuleLoadMillis;
        this.maxPartitionRuleLoadMillis = maxPartitionRuleLoadMillis;
        this.loadedRules = loadedRules;
        this.afterBaseBuild = afterBaseBuild;
        this.afterRuleLoad = afterRuleLoad;
    }

    public static DatabaseRuleSessions load(H2BenchmarkConfig config, H2Database database) throws Exception {
        System.setProperty("drools.betaNodeRangeIndexEnabled", Boolean.toString(config.betaRangeIndex()));

        KieServices services = KieServices.Factory.get();
        KieBaseConfiguration baseConfig = services.newKieBaseConfiguration();
        System.out.println("Building ONE generic KieBase (1 DRL rule)...");
        long baseStarted = System.nanoTime();
        KieHelper helper = new KieHelper()
                .setClassLoader(CommissionTransaction.class.getClassLoader())
                .addContent(GenericCommissionDrl.content(), ResourceType.DRL);
        KieBase base = config.executableModel()
                ? helper.build(ExecutableModelProject.class, baseConfig)
                : helper.build(baseConfig);
        long baseMillis = (System.nanoTime() - baseStarted) / 1_000_000L;
        MemorySnapshot afterBase = MemorySnapshot.afterGc();
        System.out.printf("Generic KieBase built in %,d ms; heap after GC: %,.1f MB%n%n",
                baseMillis, afterBase.heapUsedMb());

        KieSession[] sessions = new KieSession[config.partitions()];
        long totalLoad = 0;
        long maxLoad = 0;
        long loaded = 0;
        String sql = "SELECT " + CommissionSql.RULE_COLUMNS
                + " FROM COMMISSION_RULE WHERE PARTITION_ID = ? ORDER BY RULE_ID";

        try (Connection connection = database.connect(); PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setFetchSize(Math.max(1_000, config.readBatchSize()));
            for (int partition = 0; partition < config.partitions(); partition++) {
                long started = System.nanoTime();
                KieSession session = base.newKieSession();
                ps.setInt(1, partition);
                long partitionCount = 0;
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        session.insert(new CommissionRule(JdbcMappers.mapRule(rs)));
                        partitionCount++;
                    }
                }
                sessions[partition] = session;
                long millis = (System.nanoTime() - started) / 1_000_000L;
                totalLoad += millis;
                maxLoad = Math.max(maxLoad, millis);
                loaded += partitionCount;
                System.out.printf("Loaded partition %d/%d: %,d rules in %,d ms%n",
                        partition + 1, config.partitions(), partitionCount, millis);
            }
        }

        MemorySnapshot afterRules = MemorySnapshot.afterGc();
        System.out.printf("%nLoaded %,d rule facts from H2 in %,d ms; max partition %,d ms%n",
                loaded, totalLoad, maxLoad);
        System.out.printf("Heap after rule load/GC: %,.1f MB; non-heap: %,.1f MB%n%n",
                afterRules.heapUsedMb(), afterRules.nonHeapUsedMb());

        return new DatabaseRuleSessions(base, sessions, baseMillis, totalLoad, maxLoad,
                loaded, afterBase, afterRules);
    }

    public KieSession session(int partition) { return sessions[partition]; }
    public int partitionCount() { return sessions.length; }
    public long baseBuildMillis() { return baseBuildMillis; }
    public long totalRuleLoadMillis() { return totalRuleLoadMillis; }
    public long maxPartitionRuleLoadMillis() { return maxPartitionRuleLoadMillis; }
    public long loadedRules() { return loadedRules; }
    public MemorySnapshot afterBaseBuild() { return afterBaseBuild; }
    public MemorySnapshot afterRuleLoad() { return afterRuleLoad; }

    @Override
    public void close() {
        for (KieSession session : sessions) {
            if (session != null) session.dispose();
        }
    }
}
