package com.example.commission;

import java.util.Arrays;

public final class RulePartitioner {
    private RulePartitioner() {}

    public static int[][] partitionGroupIds(int ruleCount, int partitions) {
        int groupCount = RuleSpec.groupCountForRuleCount(ruleCount);
        int[] counts = new int[partitions];
        for (int group = 0; group < groupCount; group++) {
            counts[partitionOfGroup(group, partitions)]++;
        }
        int[][] groups = new int[partitions][];
        for (int p = 0; p < partitions; p++) groups[p] = new int[counts[p]];
        Arrays.fill(counts, 0);
        for (int group = 0; group < groupCount; group++) {
            int p = partitionOfGroup(group, partitions);
            groups[p][counts[p]++] = group;
        }
        return groups;
    }

    public static int partitionOfGroup(int groupId, int partitions) {
        return RuleSpec.fromRuleId(groupId * RuleSpec.RULES_PER_GROUP).partition(partitions);
    }
}
