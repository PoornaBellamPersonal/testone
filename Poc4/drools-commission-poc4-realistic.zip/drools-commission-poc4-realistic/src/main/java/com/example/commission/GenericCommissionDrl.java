package com.example.commission;

public final class GenericCommissionDrl {
    private GenericCommissionDrl() {}

    public static String content() {
        return """
                package com.example.commission.generated;

                import com.example.commission.CommissionRule;
                import com.example.commission.CommissionTransaction;

                rule "MATCH_REALISTIC_COMMISSION_CANDIDATES"
                when
                    $t : CommissionTransaction(
                        $carrier : carrier,
                        $product : product,
                        $state : state,
                        $channel : channel,
                        $agentType : agentType,
                        $registrationType : registrationType,
                        $commissionType : commissionType,
                        $transactionType : transactionType,
                        $policyType : policyType,
                        $currency : currency,
                        $planCode : planCode,
                        $producerLevel : producerLevel,
                        $customerSegment : customerSegment,
                        $paymentMode : paymentMode,
                        $renewal : renewal,
                        $replacement : replacement,
                        $specialProgram : specialProgram,
                        $internalBusiness : internalBusiness,
                        $premium : premium,
                        $faceAmount : faceAmount,
                        $productionAmount : productionAmount,
                        $policyDurationMonths : policyDurationMonths,
                        $issueAge : issueAge,
                        $effectiveEpochDay : effectiveEpochDay
                    )
                    $r : CommissionRule(
                        carrier == $carrier,
                        product == $product,
                        (state == "*" || state == $state),
                        (channel == "*" || channel == $channel),
                        (agentType == "*" || agentType == $agentType),
                        (registrationType == "*" || registrationType == $registrationType),
                        commissionType == $commissionType,
                        transactionType == $transactionType,
                        (policyType == "*" || policyType == $policyType),
                        currency == $currency,
                        planCode == $planCode,
                        (producerLevel == "*" || producerLevel == $producerLevel),
                        (customerSegment == "*" || customerSegment == $customerSegment),
                        (paymentMode == "*" || paymentMode == $paymentMode),
                        renewal == $renewal,
                        replacement == $replacement,
                        specialProgram == $specialProgram,
                        internalBusiness == $internalBusiness,
                        premiumMin <= $premium,
                        premiumMax >= $premium,
                        faceAmountMin <= $faceAmount,
                        faceAmountMax >= $faceAmount,
                        productionAmountMin <= $productionAmount,
                        productionAmountMax >= $productionAmount,
                        policyDurationMin <= $policyDurationMonths,
                        policyDurationMax >= $policyDurationMonths,
                        issueAgeMin <= $issueAge,
                        issueAgeMax >= $issueAge,
                        effectiveEpochDayMin <= $effectiveEpochDay,
                        effectiveEpochDayMax >= $effectiveEpochDay
                    )
                then
                    $t.considerCandidate(
                        $r.getRuleId(),
                        $r.getPriority(),
                        $r.getSpecificity(),
                        $r.getCommissionPercentage()
                    );
                end
                """;
    }
}
