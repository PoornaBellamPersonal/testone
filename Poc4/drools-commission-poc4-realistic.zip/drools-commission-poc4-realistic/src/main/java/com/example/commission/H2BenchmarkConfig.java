package com.example.commission;

import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

public record H2BenchmarkConfig(
        Mode mode,
        int ruleCount,
        long transactionCount,
        int partitions,
        int workerThreads,
        int readBatchSize,
        int writeBatchSize,
        int seedBatchSize,
        boolean resetDatabase,
        boolean executableModel,
        boolean betaRangeIndex,
        double noMatchPercent,
        int hotPartition,
        double hotSharePercent,
        long seed,
        Path databasePath,
        Path csvOutput
) {
    public enum Mode { ALL, SEED, RUN, INSPECT, CLEAN, COMPACT }

    public static H2BenchmarkConfig fromArgs(String[] args) {
        Map<String, String> values = new HashMap<>();
        for (String arg : args) {
            if (!arg.startsWith("--") || !arg.contains("=")) {
                throw new IllegalArgumentException("Arguments must be --name=value. Invalid: " + arg);
            }
            int equals = arg.indexOf('=');
            values.put(arg.substring(2, equals), arg.substring(equals + 1));
        }

        H2BenchmarkConfig config = new H2BenchmarkConfig(
                Mode.valueOf(values.getOrDefault("mode", "all").trim().toUpperCase()),
                intValue(values, "rules", 200_000),
                longValue(values, "transactions", 200_000),
                intValue(values, "partitions", 32),
                intValue(values, "threads", Math.max(1, Math.min(8, Runtime.getRuntime().availableProcessors()))),
                intValue(values, "read-batch", 2_000),
                intValue(values, "write-batch", 2_000),
                intValue(values, "seed-batch", 5_000),
                boolValue(values, "reset-db", false),
                boolValue(values, "executable-model", true),
                boolValue(values, "beta-range-index", true),
                doubleValue(values, "no-match-percent", 5.0),
                intValue(values, "hot-partition", 0),
                doubleValue(values, "hot-share-percent", 40.0),
                longValue(values, "seed", 42L),
                Path.of(values.getOrDefault("db", "data/commission-realistic")),
                Path.of(values.getOrDefault("csv", "benchmark-results-realistic.csv"))
        );
        config.validate();
        return config;
    }

    public String jdbcUrl() {
        String normalized = databasePath.toAbsolutePath().normalize().toString().replace('\\', '/');
        return "jdbc:h2:file:" + normalized + ";DB_CLOSE_ON_EXIT=FALSE;LOCK_TIMEOUT=60000";
    }

    public Path databaseFile() {
        return Path.of(databasePath.toAbsolutePath().normalize() + ".mv.db");
    }

    private void validate() {
        if (ruleCount <= 0) throw new IllegalArgumentException("rules must be > 0");
        RuleSpec.groupCountForRuleCount(ruleCount);
        if (transactionCount <= 0) throw new IllegalArgumentException("transactions must be > 0");
        if (partitions <= 0 || partitions > RuleDimensions.CARRIERS.length) {
            throw new IllegalArgumentException("partitions must be between 1 and " + RuleDimensions.CARRIERS.length);
        }
        if (hotPartition < 0 || hotPartition >= partitions) {
            throw new IllegalArgumentException("hot-partition must be within configured partitions");
        }
        if (workerThreads <= 0) throw new IllegalArgumentException("threads must be > 0");
        if (readBatchSize <= 0 || writeBatchSize <= 0 || seedBatchSize <= 0) {
            throw new IllegalArgumentException("batch sizes must be > 0");
        }
        if (noMatchPercent < 0 || noMatchPercent > 100) {
            throw new IllegalArgumentException("no-match-percent must be 0..100");
        }
        if (hotSharePercent < 0 || hotSharePercent > 100) {
            throw new IllegalArgumentException("hot-share-percent must be 0..100");
        }
        if (ruleCount / RuleSpec.RULES_PER_GROUP > RuleDimensions.maxUniqueRuleCount()) {
            throw new IllegalArgumentException("Requested logical rule groups exceed deterministic unique combinations");
        }
    }

    private static int intValue(Map<String, String> m, String k, int d) {
        return Integer.parseInt(m.getOrDefault(k, Integer.toString(d)));
    }

    private static long longValue(Map<String, String> m, String k, long d) {
        return Long.parseLong(m.getOrDefault(k, Long.toString(d)));
    }

    private static double doubleValue(Map<String, String> m, String k, double d) {
        return Double.parseDouble(m.getOrDefault(k, Double.toString(d)));
    }

    private static boolean boolValue(Map<String, String> m, String k, boolean d) {
        return Boolean.parseBoolean(m.getOrDefault(k, Boolean.toString(d)));
    }
}
