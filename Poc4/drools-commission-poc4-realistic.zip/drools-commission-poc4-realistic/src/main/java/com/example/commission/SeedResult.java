package com.example.commission;

public record SeedResult(long ruleSeedMillis, long transactionSeedMillis, long rulesSeeded, long transactionsSeeded) {}
