package com.example.commission;

public record DbBenchmarkResult(
        long transactions,
        long matched,
        long noMatch,
        long incorrect,
        long multipleMatches,
        long topRankAmbiguous,
        long totalCandidates,
        int maxCandidates,
        long elapsedNanos,
        long readNanos,
        long engineNanos,
        long writeNanos,
        double transactionsPerSecond,
        double p50BatchMillis,
        double p95BatchMillis,
        double p99BatchMillis,
        MemorySnapshot afterRun
) {
    public double averageCandidatesPerTransaction() {
        return transactions == 0 ? 0.0 : (double) totalCandidates / transactions;
    }
}
