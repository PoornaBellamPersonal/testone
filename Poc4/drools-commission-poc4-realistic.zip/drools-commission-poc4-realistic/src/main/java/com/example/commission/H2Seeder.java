package com.example.commission;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.SplittableRandom;

public final class H2Seeder {
    private final H2BenchmarkConfig config;
    private final H2Database database;

    public H2Seeder(H2BenchmarkConfig config, H2Database database) {
        this.config = config;
        this.database = database;
    }

    public SeedResult seedIfRequired() throws SQLException {
        long existingRules = database.count("COMMISSION_RULE");
        long existingTransactions = database.count("COMMISSION_TRANSACTION");
        if (existingRules == config.ruleCount() && existingTransactions == config.transactionCount()) {
            System.out.printf("Database already contains %,d rules and %,d transactions; seeding skipped.%n%n",
                    existingRules, existingTransactions);
            return new SeedResult(0, 0, existingRules, existingTransactions);
        }
        return reseed();
    }

    public SeedResult reseed() throws SQLException {
        try (Connection connection = database.connect(); Statement statement = connection.createStatement()) {
            statement.execute("TRUNCATE TABLE COMMISSION_RESULT");
            statement.execute("TRUNCATE TABLE COMMISSION_TRANSACTION");
            statement.execute("TRUNCATE TABLE COMMISSION_RULE");
        }

        long ruleStarted = System.nanoTime();
        seedRules();
        long ruleMillis = (System.nanoTime() - ruleStarted) / 1_000_000L;

        long txStarted = System.nanoTime();
        seedTransactions();
        long txMillis = (System.nanoTime() - txStarted) / 1_000_000L;

        System.out.printf("Seeded %,d realistic rules in %,d ms%n", config.ruleCount(), ruleMillis);
        System.out.printf("Seeded %,d transactions in %,d ms%n%n", config.transactionCount(), txMillis);
        return new SeedResult(ruleMillis, txMillis, config.ruleCount(), config.transactionCount());
    }

    private void seedRules() throws SQLException {
        String placeholders = "?,".repeat(35) + "?";
        String sql = "INSERT INTO COMMISSION_RULE (" + CommissionSql.RULE_COLUMNS + ") VALUES (" + placeholders + ")";
        try (Connection connection = database.connect(); PreparedStatement ps = connection.prepareStatement(sql)) {
            connection.setAutoCommit(false);
            int pending = 0;
            for (int id = 0; id < config.ruleCount(); id++) {
                RuleSpec rule = RuleSpec.fromRuleId(id);
                JdbcMappers.bindRule(ps, rule, rule.partition(config.partitions()));
                ps.addBatch();
                if (++pending == config.seedBatchSize()) {
                    ps.executeBatch();
                    connection.commit();
                    pending = 0;
                }
            }
            if (pending > 0) ps.executeBatch();
            connection.commit();
        }
    }

    private void seedTransactions() throws SQLException {
        int[][] groupIds = RulePartitioner.partitionGroupIds(config.ruleCount(), config.partitions());
        long[] partitionCounts = transactionCountsByPartition();
        String placeholders = "?,".repeat(26) + "?";
        String sql = "INSERT INTO COMMISSION_TRANSACTION (" + CommissionSql.TRANSACTION_COLUMNS + ") VALUES (" + placeholders + ")";

        try (Connection connection = database.connect(); PreparedStatement ps = connection.prepareStatement(sql)) {
            connection.setAutoCommit(false);
            long txId = 1;
            int pending = 0;
            for (int partition = 0; partition < config.partitions(); partition++) {
                long count = partitionCounts[partition];
                int[] candidates = groupIds[partition];
                if (candidates.length == 0 && count > 0) {
                    throw new IllegalStateException("Partition " + partition + " has transactions but no rule groups");
                }
                SplittableRandom random = new SplittableRandom(mix64(config.seed() ^ partition));
                for (long n = 0; n < count; n++) {
                    int groupId = candidates[random.nextInt(candidates.length)];
                    boolean noMatch = random.nextDouble(100.0) < config.noMatchPercent();
                    CommissionTransaction tx = noMatch
                            ? TransactionFactory.nonMatching(txId++, groupId)
                            : TransactionFactory.matching(txId++, groupId);
                    JdbcMappers.bindTransaction(ps, tx, partition);
                    ps.addBatch();
                    if (++pending == config.seedBatchSize()) {
                        ps.executeBatch();
                        connection.commit();
                        pending = 0;
                    }
                }
            }
            if (pending > 0) ps.executeBatch();
            connection.commit();
        }
    }

    private long[] transactionCountsByPartition() {
        long[] counts = new long[config.partitions()];
        if (config.partitions() == 1) {
            counts[0] = config.transactionCount();
            return counts;
        }

        long hot = Math.round(config.transactionCount() * config.hotSharePercent() / 100.0);
        hot = Math.max(0, Math.min(config.transactionCount(), hot));
        long remaining = config.transactionCount() - hot;
        long base = remaining / (config.partitions() - 1);
        long remainder = remaining % (config.partitions() - 1);

        counts[config.hotPartition()] = hot;
        int ordinal = 0;
        for (int p = 0; p < config.partitions(); p++) {
            if (p == config.hotPartition()) continue;
            counts[p] = base + (ordinal++ < remainder ? 1 : 0);
        }
        return counts;
    }

    private static long mix64(long z) {
        z = (z ^ (z >>> 30)) * 0xbf58476d1ce4e5b9L;
        z = (z ^ (z >>> 27)) * 0x94d049bb133111ebL;
        return z ^ (z >>> 31);
    }
}
