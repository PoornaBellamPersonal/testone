package com.example.commission;

public final class RuleDimensions {
    private RuleDimensions() {}

    public static final String[] CARRIERS = values("CAR", 64);
    public static final String[] PRODUCTS = values("PROD", 64);
    public static final String[] STATES = values("ST", 32);
    public static final String[] CHANNELS = values("CH", 8);
    public static final String[] AGENT_TYPES = values("AG", 8);
    public static final String[] REGISTRATION_TYPES = values("REG", 8);
    public static final String[] COMMISSION_TYPES = values("COMM", 8);
    public static final String[] TRANSACTION_TYPES = values("TXN", 8);
    public static final String[] POLICY_TYPES = values("POL", 8);
    public static final String[] CURRENCIES = values("CUR", 4);
    public static final String[] PLAN_CODES = values("PLAN", 16);
    public static final String[] PRODUCER_LEVELS = values("LEVEL", 8);
    public static final String[] CUSTOMER_SEGMENTS = values("SEG", 8);
    public static final String[] PAYMENT_MODES = values("PAY", 8);

    private static final int[] RADICES = {
            CARRIERS.length,
            PRODUCTS.length,
            STATES.length,
            CHANNELS.length,
            AGENT_TYPES.length,
            REGISTRATION_TYPES.length,
            COMMISSION_TYPES.length,
            TRANSACTION_TYPES.length,
            POLICY_TYPES.length,
            CURRENCIES.length,
            PLAN_CODES.length,
            PRODUCER_LEVELS.length,
            CUSTOMER_SEGMENTS.length,
            PAYMENT_MODES.length
    };

    // Product of all radices is 2^50. Multiplication by an odd number is a
    // permutation modulo 2^50, so distinct int rule IDs remain distinct while
    // their bits are spread across all categorical dimensions.
    private static final long MASK_50 = (1L << 50) - 1L;
    private static final long MIX_MULTIPLIER = 0x9E3779B97F4A7C15L; // odd
    private static final long MIX_OFFSET = 0x0002D5A5A5A5A5A5L & MASK_50;

    public static long maxUniqueRuleCount() {
        long product = 1L;
        for (int radix : RADICES) product *= radix;
        return product;
    }

    public static int[] exactIndexes(int ruleId) {
        long value = mixedKey(ruleId);
        int[] indexes = new int[RADICES.length];
        for (int i = 0; i < RADICES.length; i++) {
            indexes[i] = (int) (value % RADICES[i]);
            value /= RADICES[i];
        }
        return indexes;
    }

    public static long mixedKey(int ruleId) {
        return (Integer.toUnsignedLong(ruleId) * MIX_MULTIPLIER + MIX_OFFSET) & MASK_50;
    }

    private static String[] values(String prefix, int count) {
        String[] values = new String[count];
        for (int i = 0; i < count; i++) values[i] = prefix + String.format("%02d", i);
        return values;
    }
}
