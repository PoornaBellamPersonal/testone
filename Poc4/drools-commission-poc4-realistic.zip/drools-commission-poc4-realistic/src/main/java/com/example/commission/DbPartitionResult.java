package com.example.commission;

import java.util.List;

public record DbPartitionResult(
        long transactions,
        long matched,
        long noMatch,
        long incorrect,
        long multipleMatches,
        long topRankAmbiguous,
        long totalCandidates,
        int maxCandidates,
        long readNanos,
        long engineNanos,
        long writeNanos,
        List<Long> batchTotalNanos
) {}
