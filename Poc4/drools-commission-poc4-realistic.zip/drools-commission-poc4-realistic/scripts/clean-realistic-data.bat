@echo off
setlocal
pushd "%~dp0.."
echo Removing POC #4 H2 databases...
if exist data\commission-realistic-smoke.mv.db del /q data\commission-realistic-smoke.mv.db
if exist data\commission-realistic-medium.mv.db del /q data\commission-realistic-medium.mv.db
if exist data\commission-realistic-2m.mv.db del /q data\commission-realistic-2m.mv.db
if exist data\commission-realistic-smoke.trace.db del /q data\commission-realistic-smoke.trace.db
if exist data\commission-realistic-medium.trace.db del /q data\commission-realistic-medium.trace.db
if exist data\commission-realistic-2m.trace.db del /q data\commission-realistic-2m.trace.db
echo Done.
popd
endlocal
