@echo off
setlocal
pushd "%~dp0.."
echo This removes generated H2 databases, Maven output, benchmark CSV history, and heap dumps in this project.
if exist data rmdir /s /q data
if exist target rmdir /s /q target
if exist benchmark-results-realistic.csv del /q benchmark-results-realistic.csv
for %%F in (*.hprof) do del /q "%%F"
echo Cleanup complete.
popd
endlocal
