#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
export MAVEN_OPTS="-Xms2g -Xmx8g -XX:+UseG1GC -XX:+HeapDumpOnOutOfMemoryError"
mvn -q clean compile exec:java -Dexec.args="--mode=all --reset-db=true --rules=200000 --transactions=2000000 --partitions=32 --threads=8 --read-batch=5000 --write-batch=5000 --seed-batch=10000 --no-match-percent=5 --hot-partition=0 --hot-share-percent=40 --db=data/commission-realistic-2m --csv=benchmark-results-realistic.csv"
