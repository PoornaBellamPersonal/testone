@echo off
setlocal
pushd "%~dp0.."
mvn -q compile exec:java -Dexec.args="--mode=compact --db=data/commission-realistic-2m"
popd
endlocal
