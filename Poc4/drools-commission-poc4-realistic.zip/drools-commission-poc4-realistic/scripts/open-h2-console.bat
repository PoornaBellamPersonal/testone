@echo off
setlocal
pushd "%~dp0.."
echo Use this JDBC URL in the console:
echo jdbc:h2:file:./data/commission-realistic-2m
echo User: sa
echo Password: leave blank
echo.
mvn -q -Dexec.mainClass=org.h2.tools.Console exec:java
popd
endlocal
