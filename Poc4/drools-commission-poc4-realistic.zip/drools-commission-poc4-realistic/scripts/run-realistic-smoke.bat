@echo off
setlocal
pushd "%~dp0.."
set MAVEN_OPTS=-Xms512m -Xmx4g -XX:+UseG1GC -XX:+HeapDumpOnOutOfMemoryError
mvn -q clean compile exec:java -Dexec.args="--mode=all --reset-db=true --rules=20000 --transactions=100000 --partitions=8 --threads=4 --read-batch=1000 --write-batch=1000 --seed-batch=2000 --no-match-percent=5 --hot-partition=0 --hot-share-percent=30 --db=data/commission-realistic-smoke --csv=benchmark-results-realistic.csv"
popd
endlocal
