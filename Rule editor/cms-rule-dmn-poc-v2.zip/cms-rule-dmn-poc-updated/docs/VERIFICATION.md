# Verification Notes

## Performed in the generation environment

- Reviewed controllers, services, repositories, entities, templates, JavaScript, CSS and configuration after the V2 changes.
- Parsed all Java source compilation units with the JDK 17 language level (`--release 17`) using the Java compiler parser.
- Ran `node --check` successfully against `rule-editor.js`.
- Parsed all Thymeleaf HTML files with an HTML parser.
- Parsed `pom.xml` and the seeded DMN file as XML.
- Ran `bash -n mvnw` successfully.
- Checked that the UI routes used by Thymeleaf/JavaScript match the MVC and REST controller mappings.

## Build/runtime limitation of this environment

A dependency-resolved Maven build could not be executed here because Maven is not preinstalled and this runtime blocks the normal outbound download path used by Maven. Therefore this package is **source/static verified**, not claimed as fully runtime-verified in this environment.

The project includes `mvnw` and `mvnw.cmd` convenience launchers. On a normal developer machine, run:

```bat
mvnw.cmd clean test
mvnw.cmd spring-boot:run
```

or on macOS/Linux:

```bash
./mvnw clean test
./mvnw spring-boot:run
```

## Recommended acceptance checks

1. Sign in with `admin / admin`.
2. Open the seeded **Commission Rules** rule set.
3. View the seeded Base Commission DMN.
4. Switch to Edit and change a decision-table cell; save and confirm a new version appears.
5. Edit the same DMN in the **DMN XML** tab, choose **Apply to Modeler**, and verify the visual model changes.
6. Create a new blank DMN rule and edit it visually.
7. Import an existing `.dmn` file and verify it opens directly in edit mode.
8. Export the imported/edited DMN and verify the downloaded XML.
9. Evaluate the seeded rule with the sample JSON and verify the expected match.
10. Restart the application and confirm rule/rule-version data remains in the file-based H2 database.
