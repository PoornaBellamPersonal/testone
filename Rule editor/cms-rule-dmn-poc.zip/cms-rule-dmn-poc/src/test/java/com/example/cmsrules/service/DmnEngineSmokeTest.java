package com.example.cmsrules.service;

import org.camunda.bpm.dmn.engine.DmnEngineConfiguration;
import org.junit.jupiter.api.Test;

import java.io.InputStream;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

class DmnEngineSmokeTest {

    @Test
    void evaluatesSeededCommissionRule() {
        var engine = DmnEngineConfiguration.createDefaultDmnEngineConfiguration().buildEngine();
        try (InputStream in = getClass().getResourceAsStream("/dmn/base-commission.dmn")) {
            assertThat(in).isNotNull();
            var decision = engine.parseDecision("baseCommission", in);
            var result = engine.evaluateDecision(decision, Map.of(
                "region", "APAC",
                "product", "LIFE",
                "amount", 25000
            ));
            assertThat(result.getSingleResult().getEntry("commissionPercentage"))
                .isEqualTo(8.0d);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
