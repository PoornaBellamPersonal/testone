package com.example.cmsrules.service;

import com.example.cmsrules.domain.*;
import com.example.cmsrules.dto.CreateRuleRequest;
import com.example.cmsrules.dto.CreateRuleSetRequest;
import com.example.cmsrules.repository.RuleDefinitionRepository;
import com.example.cmsrules.repository.RuleSetRepository;
import com.example.cmsrules.repository.RuleVersionRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.core.io.ClassPathResource;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.List;

@Service
public class RuleManagementService {

    private final RuleSetRepository ruleSetRepository;
    private final RuleDefinitionRepository ruleRepository;
    private final RuleVersionRepository versionRepository;
    private final DmnExecutionService dmnExecutionService;

    public RuleManagementService(RuleSetRepository ruleSetRepository,
                                 RuleDefinitionRepository ruleRepository,
                                 RuleVersionRepository versionRepository,
                                 DmnExecutionService dmnExecutionService) {
        this.ruleSetRepository = ruleSetRepository;
        this.ruleRepository = ruleRepository;
        this.versionRepository = versionRepository;
        this.dmnExecutionService = dmnExecutionService;
    }

    @Transactional(readOnly = true)
    public List<RuleSetEntity> listRuleSets() {
        return ruleSetRepository.findByStatusNotOrderByUpdatedAtDesc(RuleStatus.DELETED);
    }

    @Transactional(readOnly = true)
    public RuleSetEntity getRuleSet(Long id) {
        return ruleSetRepository.findById(id).orElseThrow(() -> new EntityNotFoundException("Rule set not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<RuleDefinitionEntity> listRules(Long ruleSetId) {
        return ruleRepository.findByRuleSetIdAndStatusNotOrderByUpdatedAtDesc(ruleSetId, RuleStatus.DELETED);
    }

    @Transactional(readOnly = true)
    public RuleDefinitionEntity getRule(Long id) {
        return ruleRepository.findById(id).orElseThrow(() -> new EntityNotFoundException("Rule not found: " + id));
    }

    @Transactional(readOnly = true)
    public RuleVersionEntity currentVersion(Long ruleId) {
        var rule = getRule(ruleId);
        return versionRepository.findByRuleIdAndVersionNumber(ruleId, rule.getCurrentVersion())
            .orElseThrow(() -> new EntityNotFoundException("Current rule version not found for rule: " + ruleId));
    }

    @Transactional(readOnly = true)
    public List<RuleVersionEntity> versions(Long ruleId) {
        return versionRepository.findByRuleIdOrderByVersionNumberDesc(ruleId);
    }

    @Transactional
    public RuleSetEntity createRuleSet(CreateRuleSetRequest request, Authentication auth) {
        var entity = new RuleSetEntity();
        entity.setCode(normalizeCode(request.getCode()));
        entity.setName(request.getName());
        entity.setDescription(request.getDescription());
        entity.setStatus(RuleStatus.ACTIVE);
        entity.setCreatedBy(username(auth));
        entity.setUpdatedBy(username(auth));
        return ruleSetRepository.save(entity);
    }

    @Transactional
    public RuleDefinitionEntity createRule(Long ruleSetId, CreateRuleRequest request, Authentication auth) {
        var ruleSet = getRuleSet(ruleSetId);
        var rule = new RuleDefinitionEntity();
        rule.setRuleSet(ruleSet);
        rule.setCode(normalizeCode(request.getCode()));
        rule.setName(request.getName());
        rule.setDescription(request.getDescription());
        rule.setRuleType(RuleType.DMN);
        rule.setStatus(RuleStatus.DRAFT);
        rule.setCurrentVersion(1);
        rule.setCreatedBy(username(auth));
        rule.setUpdatedBy(username(auth));
        rule = ruleRepository.save(rule);

        var version = new RuleVersionEntity();
        version.setRule(rule);
        version.setVersionNumber(1);
        version.setDmnXml(blankDmn(rule));
        version.setStatus(RuleStatus.DRAFT);
        version.setComment("Initial version");
        version.setCreatedBy(username(auth));
        versionRepository.save(version);
        return rule;
    }

    @Transactional
    public RuleVersionEntity saveNewVersion(Long ruleId, String xml, String comment, Authentication auth) {
        if (xml == null || xml.isBlank()) {
            throw new IllegalArgumentException("DMN XML must not be empty");
        }
        var rule = getRule(ruleId);
        dmnExecutionService.validate(xml, rule.getCode());

        var next = rule.getCurrentVersion() + 1;
        var version = new RuleVersionEntity();
        version.setRule(rule);
        version.setVersionNumber(next);
        version.setDmnXml(xml);
        version.setStatus(RuleStatus.ACTIVE);
        version.setComment(comment == null || comment.isBlank() ? "Updated from CMS editor" : comment.trim());
        version.setCreatedBy(username(auth));
        versionRepository.save(version);

        rule.setCurrentVersion(next);
        rule.setStatus(RuleStatus.ACTIVE);
        rule.setUpdatedBy(username(auth));
        ruleRepository.save(rule);
        dmnExecutionService.evict(ruleId);
        return version;
    }

    @Transactional
    public void deleteRule(Long ruleId, Authentication auth) {
        var rule = getRule(ruleId);
        rule.setStatus(RuleStatus.DELETED);
        rule.setUpdatedBy(username(auth));
        ruleRepository.save(rule);
        dmnExecutionService.evict(ruleId);
    }

    public long ruleCount(Long ruleSetId) {
        return ruleRepository.countByRuleSetIdAndStatusNot(ruleSetId, RuleStatus.DELETED);
    }

    private String username(Authentication auth) {
        return auth == null ? "system" : auth.getName();
    }

    private String normalizeCode(String code) {
        if (code == null || code.isBlank()) throw new IllegalArgumentException("Code is required");
        return code.trim().toUpperCase().replaceAll("[^A-Z0-9_]+", "_");
    }

    private String blankDmn(RuleDefinitionEntity rule) {
        String decisionId = "Decision_" + rule.getCode();
        return """
            <?xml version="1.0" encoding="UTF-8"?>
            <definitions xmlns="https://www.omg.org/spec/DMN/20191111/MODEL/"
                         xmlns:dmndi="https://www.omg.org/spec/DMN/20191111/DMNDI/"
                         xmlns:dc="http://www.omg.org/spec/DMN/20180521/DC/"
                         xmlns:di="http://www.omg.org/spec/DMN/20180521/DI/"
                         xmlns:camunda="http://camunda.org/schema/1.0/dmn"
                         id="Definitions_%s"
                         name="%s"
                         namespace="http://example.com/cms/dmn">
              <decision id="%s" name="%s">
                <decisionTable id="DecisionTable_1" hitPolicy="FIRST">
                  <input id="Input_1" label="Input">
                    <inputExpression id="InputExpression_1" typeRef="string">
                      <text>input</text>
                    </inputExpression>
                  </input>
                  <output id="Output_1" label="Result" name="result" typeRef="string" />
                  <rule id="Rule_1">
                    <inputEntry id="InputEntry_1"><text>-</text></inputEntry>
                    <outputEntry id="OutputEntry_1"><text>"OK"</text></outputEntry>
                  </rule>
                </decisionTable>
              </decision>
            </definitions>
            """.formatted(rule.getCode(), rule.getName(), decisionId, rule.getName());
    }
}
