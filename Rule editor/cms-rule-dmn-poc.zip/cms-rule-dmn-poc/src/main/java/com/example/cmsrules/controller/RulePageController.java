package com.example.cmsrules.controller;

import com.example.cmsrules.dto.CreateRuleRequest;
import com.example.cmsrules.dto.CreateRuleSetRequest;
import com.example.cmsrules.service.RuleManagementService;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class RulePageController {

    private final RuleManagementService service;

    public RulePageController(RuleManagementService service) {
        this.service = service;
    }

    @GetMapping("/rulesets")
    String ruleSets(Model model) {
        var sets = service.listRuleSets();
        model.addAttribute("ruleSets", sets);
        model.addAttribute("ruleCount", sets.stream().collect(java.util.stream.Collectors.toMap(
            s -> s.getId(), s -> service.ruleCount(s.getId()))));
        return "rulesets";
    }

    @PostMapping("/rulesets")
    String createRuleSet(@ModelAttribute CreateRuleSetRequest request,
                         Authentication auth,
                         RedirectAttributes redirect) {
        var saved = service.createRuleSet(request, auth);
        redirect.addFlashAttribute("message", "Rule set created");
        return "redirect:/rulesets/" + saved.getId();
    }

    @GetMapping("/rulesets/{id}")
    String ruleSet(@PathVariable Long id,
                   @RequestParam(required = false) Long ruleId,
                   @RequestParam(defaultValue = "view") String mode,
                   Model model) {
        var ruleSet = service.getRuleSet(id);
        model.addAttribute("ruleSet", ruleSet);
        model.addAttribute("rules", service.listRules(id));

        if (ruleId != null) {
            var rule = service.getRule(ruleId);
            if (!rule.getRuleSet().getId().equals(id)) {
                throw new IllegalArgumentException("Rule does not belong to this rule set");
            }
            model.addAttribute("selectedRule", rule);
            model.addAttribute("selectedVersion", service.currentVersion(ruleId));
            model.addAttribute("versions", service.versions(ruleId));
            model.addAttribute("editable", "edit".equalsIgnoreCase(mode));
        }
        return "ruleset-detail";
    }

    @PostMapping("/rulesets/{id}/rules")
    String createRule(@PathVariable Long id,
                      @ModelAttribute CreateRuleRequest request,
                      Authentication auth,
                      RedirectAttributes redirect) {
        var rule = service.createRule(id, request, auth);
        redirect.addFlashAttribute("message", "DMN rule created");
        return "redirect:/rulesets/" + id + "?ruleId=" + rule.getId() + "&mode=edit#editor";
    }

    @GetMapping("/rules/{id}/view")
    String view(@PathVariable Long id) {
        var rule = service.getRule(id);
        return "redirect:/rulesets/" + rule.getRuleSet().getId() + "?ruleId=" + id + "&mode=view#editor";
    }

    @GetMapping("/rules/{id}/edit")
    String edit(@PathVariable Long id) {
        var rule = service.getRule(id);
        return "redirect:/rulesets/" + rule.getRuleSet().getId() + "?ruleId=" + id + "&mode=edit#editor";
    }

    @PostMapping("/rules/{id}/delete")
    String delete(@PathVariable Long id, Authentication auth, RedirectAttributes redirect) {
        var rule = service.getRule(id);
        var setId = rule.getRuleSet().getId();
        service.deleteRule(id, auth);
        redirect.addFlashAttribute("message", "Rule deleted");
        return "redirect:/rulesets/" + setId;
    }
}
