package com.example.cmsrules.repository;

import com.example.cmsrules.domain.RuleDefinitionEntity;
import com.example.cmsrules.domain.RuleStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface RuleDefinitionRepository extends JpaRepository<RuleDefinitionEntity, Long> {
    List<RuleDefinitionEntity> findByRuleSetIdAndStatusNotOrderByUpdatedAtDesc(Long ruleSetId, RuleStatus status);
    long countByRuleSetIdAndStatusNot(Long ruleSetId, RuleStatus status);
}
