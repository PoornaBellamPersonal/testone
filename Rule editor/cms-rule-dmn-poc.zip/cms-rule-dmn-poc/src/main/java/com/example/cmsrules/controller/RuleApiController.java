package com.example.cmsrules.controller;

import com.example.cmsrules.dto.EvaluateDmnRequest;
import com.example.cmsrules.dto.SaveDmnRequest;
import com.example.cmsrules.service.DmnExecutionService;
import com.example.cmsrules.service.RuleManagementService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/rules")
public class RuleApiController {

    private final RuleManagementService ruleService;
    private final DmnExecutionService executionService;

    public RuleApiController(RuleManagementService ruleService, DmnExecutionService executionService) {
        this.ruleService = ruleService;
        this.executionService = executionService;
    }

    @GetMapping("/{id}/dmn")
    ResponseEntity<String> dmn(@PathVariable Long id) {
        return ResponseEntity.ok()
            .header("Content-Type", "application/xml;charset=UTF-8")
            .body(ruleService.currentVersion(id).getDmnXml());
    }

    @PutMapping("/{id}/dmn")
    Map<String, Object> save(@PathVariable Long id,
                             @RequestBody SaveDmnRequest request,
                             Authentication auth) {
        var saved = ruleService.saveNewVersion(id, request.xml(), request.comment(), auth);
        return Map.of(
            "ruleId", id,
            "version", saved.getVersionNumber(),
            "message", "DMN saved as version " + saved.getVersionNumber()
        );
    }

    @PostMapping("/{id}/evaluate")
    Object evaluate(@PathVariable Long id, @RequestBody EvaluateDmnRequest request) {
        return executionService.evaluate(id, request.variables());
    }
}
