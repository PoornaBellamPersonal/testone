(() => {
  const cfg = window.cmsRuleEditor;
  const canvas = document.getElementById('dmnCanvas');
  const saveBtn = document.getElementById('saveBtn');
  const testBtn = document.getElementById('testBtn');
  const testInput = document.getElementById('testInput');
  const testResult = document.getElementById('testResult');
  const pageMessage = document.getElementById('pageMessage');

  const dmn = new DmnJS({ container: canvas });

  function showMessage(text, type = 'success') {
    pageMessage.innerHTML = `<div class="alert ${type}">${escapeHtml(text)}</div>`;
  }

  function escapeHtml(value) {
    return String(value).replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
  }

  async function load() {
    try {
      const response = await fetch(`/api/rules/${cfg.ruleId}/dmn`);
      if (!response.ok) throw new Error(await response.text());
      const xml = await response.text();
      const result = await dmn.importXML(xml);
      if (result.warnings && result.warnings.length) console.warn(result.warnings);

    } catch (e) {
      showMessage(`Unable to load DMN: ${e.message}`, 'error');
    }
  }

  if (saveBtn) {
    saveBtn.addEventListener('click', async () => {
      saveBtn.disabled = true;
      try {
        const { xml } = await dmn.saveXML({ format: true });
        const response = await fetch(`/api/rules/${cfg.ruleId}/dmn`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ xml, comment: 'Updated from inline dmn-js editor' })
        });
        const body = await response.json();
        if (!response.ok) throw new Error(body.error || 'Save failed');
        showMessage(body.message);
        setTimeout(() => window.location.reload(), 500);
      } catch (e) {
        showMessage(e.message, 'error');
      } finally {
        saveBtn.disabled = false;
      }
    });
  }

  testBtn.addEventListener('click', async () => {
    testResult.textContent = 'Evaluating...';
    try {
      const variables = JSON.parse(testInput.value);
      const response = await fetch(`/api/rules/${cfg.ruleId}/evaluate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ variables })
      });
      const body = await response.json();
      if (!response.ok) throw new Error(body.error || 'Evaluation failed');
      testResult.textContent = JSON.stringify(body, null, 2);
    } catch (e) {
      testResult.textContent = `ERROR: ${e.message}`;
    }
  });

  load();
})();
