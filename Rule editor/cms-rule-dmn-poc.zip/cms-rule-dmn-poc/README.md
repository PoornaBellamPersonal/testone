# CMS Rule Management POC

A runnable demonstration module for managing DMN business rules inside a CMS-style application.

## Technology

- Java 17
- Spring Boot 3.3.13
- Spring MVC + Thymeleaf
- Spring Security (POC in-memory login)
- Spring Data JPA
- File-based H2
- Camunda 7.24 standalone DMN engine
- dmn-js 17.10.1 embedded in the Thymeleaf editor page (official pre-packaged browser distribution)

## Features in V1

- Login (`admin` / `admin`)
- Rule-set dashboard
- Create rule sets
- Open a rule set and list its DMN rules
- Create a DMN rule
- View / edit / soft-delete rules
- View or edit a selected DMN inline on the same rule-set page with dmn-js
- Every save creates a new rule version
- Validate DMN before persistence
- Execute the current rule version from the same page
- In-memory parsed-DMN cache for repeated evaluation
- Version-history panel
- File-based H2 persistence across restarts

## Run

```bash
mvn spring-boot:run
```

Open:

- Application: `http://localhost:8080`
- H2 console: `http://localhost:8080/h2-console`

Login:

- Username: `admin`
- Password: `admin`

H2 JDBC URL:

```text
jdbc:h2:file:./data/cms-rule-db;DB_CLOSE_ON_EXIT=FALSE
```

## Demo test

The application seeds a `Commission Rules` rule set with `Base Commission` DMN.

Use this test input:

```json
{
  "region": "APAC",
  "product": "LIFE",
  "amount": 25000
}
```

Expected output contains:

```json
{
  "commissionPercentage": 8.0
}
```

## Important POC choices

1. The UI is server-rendered Thymeleaf. Only the DMN modeling surface is JavaScript (`dmn-js`).
2. Camunda is used as a standalone DMN library, so this module does not need to deploy a BPMN process engine just to evaluate DMN.
3. The domain is `RuleSet -> RuleDefinition -> RuleVersion`; `DMN` is a rule type rather than the domain itself.
4. Delete is soft delete.
5. Save creates a new immutable version.
6. The `/api/**` endpoints are excluded from CSRF only to keep this local POC simple. Production code should send CSRF tokens instead.
7. The demo user is in-memory. Replace it with CMS authentication / RBAC when integrating.
8. The DMN editor browser assets are loaded from unpkg in V1; vendor them under `static/` if the demo must run fully offline.

## Suggested next increment

- Draft vs Published versions
- Activate / rollback version
- Import / export DMN
- DMN semantic validation report
- Test-case persistence and bulk tests
- Execution audit history
- Rule-set orchestration / ordered execution
- Maker-checker approval workflow
