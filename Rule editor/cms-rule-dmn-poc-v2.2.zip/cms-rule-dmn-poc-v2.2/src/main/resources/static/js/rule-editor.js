(() => {
  'use strict';

  const cfg = window.cmsRuleEditor;
  if (!cfg) return;

  const canvas = document.getElementById('dmnCanvas');
  const saveBtn = document.getElementById('saveBtn');
  const testBtn = document.getElementById('testBtn');
  const testInput = document.getElementById('testInput');
  const testResult = document.getElementById('testResult');
  const testStatus = document.getElementById('testStatus');
  const pageMessage = document.getElementById('pageMessage');
  const xmlEditor = document.getElementById('xmlEditor');
  const applyXmlBtn = document.getElementById('applyXmlBtn');
  const xmlFromModelerBtn = document.getElementById('xmlFromModelerBtn');
  const refreshXmlBtn = document.getElementById('refreshXmlBtn');
  const xmlTab = document.getElementById('xml-tab');

  if (!canvas || typeof DmnJS === 'undefined') {
    showMessage('DMN editor library could not be loaded. Check network access to unpkg.com.', 'danger');
    return;
  }

  const dmn = new DmnJS({ container: canvas });
  let loadedXml = '';
  let modelerReady = false;

  function showMessage(text, type = 'success') {
    if (!pageMessage) return;
    pageMessage.replaceChildren();
    const alert = document.createElement('div');
    alert.className = `alert alert-${type} alert-dismissible fade show py-2 mb-3`;
    alert.setAttribute('role', 'alert');
    const icon = document.createElement('i');
    icon.className = type === 'success'
      ? 'bi bi-check-circle-fill me-2'
      : type === 'warning'
        ? 'bi bi-exclamation-triangle-fill me-2'
        : 'bi bi-x-circle-fill me-2';
    const span = document.createElement('span');
    span.textContent = text;
    const close = document.createElement('button');
    close.type = 'button';
    close.className = 'btn-close';
    close.dataset.bsDismiss = 'alert';
    alert.append(icon, span, close);
    pageMessage.append(alert);
  }

  async function fetchSavedXml() {
    const response = await fetch(`/api/rules/${cfg.ruleId}/dmn`, {
      headers: { 'Accept': 'application/xml' }
    });
    if (!response.ok) throw new Error(await safeError(response));
    return response.text();
  }

  async function importIntoModeler(xml, successMessage) {
    const result = await dmn.importXML(xml);
    modelerReady = true;
    loadedXml = xml;
    if (xmlEditor) xmlEditor.value = xml;
    try {
      const activeViewer = dmn.getActiveViewer && dmn.getActiveViewer();
      const activeCanvas = activeViewer && activeViewer.get && activeViewer.get('canvas');
      if (activeCanvas && activeCanvas.zoom) activeCanvas.zoom('fit-viewport');
    } catch (ignored) {
      // Decision-table views do not always expose the same canvas API as DRD views.
    }
    if (result.warnings && result.warnings.length) {
      console.warn('DMN import warnings', result.warnings);
      showMessage(`DMN loaded with ${result.warnings.length} warning(s). See browser console for details.`, 'warning');
    } else if (successMessage) {
      showMessage(successMessage, 'success');
    }
  }

  async function xmlFromModeler() {
    if (!cfg.editable || !modelerReady) return loadedXml;
    const { xml } = await dmn.saveXML({ format: true });
    loadedXml = xml;
    if (xmlEditor) xmlEditor.value = xml;
    return xml;
  }

  async function load() {
    try {
      const xml = await fetchSavedXml();
      loadedXml = xml;
      if (xmlEditor) xmlEditor.value = xml;
      await importIntoModeler(xml);
    } catch (e) {
      showMessage(`Unable to load DMN: ${e.message}`, 'danger');
    }
  }

  if (saveBtn) {
    saveBtn.addEventListener('click', async () => {
      saveBtn.disabled = true;
      const original = saveBtn.innerHTML;
      saveBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Saving...';
      try {
        let xml;
        const xmlPaneActive = document.getElementById('xml-pane')?.classList.contains('active');
        if (xmlPaneActive && xmlEditor) {
          xml = xmlEditor.value;
          await importIntoModeler(xml);
        } else {
          xml = await xmlFromModeler();
        }
        if (!xml || !xml.trim()) throw new Error('DMN XML is empty');

        const response = await fetch(`/api/rules/${cfg.ruleId}/dmn`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
          body: JSON.stringify({ xml, comment: 'Updated from CMS DMN editor' })
        });
        const body = await readJson(response);
        if (!response.ok) throw new Error(body.error || body.message || 'Save failed');
        showMessage(body.message || 'DMN saved successfully');
        window.setTimeout(() => window.location.reload(), 650);
      } catch (e) {
        showMessage(e.message, 'danger');
      } finally {
        saveBtn.disabled = false;
        saveBtn.innerHTML = original;
      }
    });
  }

  if (applyXmlBtn) {
    applyXmlBtn.addEventListener('click', async () => {
      applyXmlBtn.disabled = true;
      try {
        const xml = xmlEditor.value;
        if (!xml.trim()) throw new Error('DMN XML is empty');
        await importIntoModeler(xml, 'XML is valid and has been applied to the visual modeler.');
      } catch (e) {
        showMessage(`XML could not be applied: ${e.message}`, 'danger');
      } finally {
        applyXmlBtn.disabled = false;
      }
    });
  }

  if (xmlFromModelerBtn) {
    xmlFromModelerBtn.addEventListener('click', async () => {
      try {
        await xmlFromModeler();
        showMessage('XML refreshed from the visual modeler.');
      } catch (e) {
        showMessage(`Unable to generate XML: ${e.message}`, 'danger');
      }
    });
  }

  if (refreshXmlBtn) {
    refreshXmlBtn.addEventListener('click', async () => {
      try {
        await xmlFromModeler();
        if (xmlTab && window.bootstrap) bootstrap.Tab.getOrCreateInstance(xmlTab).show();
      } catch (e) {
        showMessage(`Unable to sync XML: ${e.message}`, 'danger');
      }
    });
  }

  if (xmlTab && cfg.editable) {
    xmlTab.addEventListener('show.bs.tab', async () => {
      try {
        await xmlFromModeler();
      } catch (e) {
        showMessage(`Unable to sync XML: ${e.message}`, 'danger');
      }
    });
  }

  if (xmlEditor && cfg.editable) {
    xmlEditor.addEventListener('keydown', event => {
      if (event.key !== 'Tab') return;
      event.preventDefault();
      const start = xmlEditor.selectionStart;
      const end = xmlEditor.selectionEnd;
      xmlEditor.value = xmlEditor.value.substring(0, start) + '  ' + xmlEditor.value.substring(end);
      xmlEditor.selectionStart = xmlEditor.selectionEnd = start + 2;
    });
  }

  if (testBtn) {
    testBtn.addEventListener('click', async () => {
      const original = testBtn.innerHTML;
      testBtn.disabled = true;
      testBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Evaluating...';
      setTestStatus('Running', 'primary');
      testResult.textContent = 'Evaluating saved DMN...';
      try {
        const variables = JSON.parse(testInput.value);
        if (variables === null || Array.isArray(variables) || typeof variables !== 'object') {
          throw new Error('Input must be a JSON object');
        }
        const response = await fetch(`/api/rules/${cfg.ruleId}/evaluate`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
          body: JSON.stringify({ variables })
        });
        const body = await readJson(response);
        if (!response.ok) throw new Error(body.error || body.message || 'Evaluation failed');
        testResult.textContent = JSON.stringify(body, null, 2);
        setTestStatus(body.matched ? 'Matched' : 'No match', body.matched ? 'success' : 'warning');
      } catch (e) {
        testResult.textContent = `ERROR\n${e.message}`;
        setTestStatus('Error', 'danger');
      } finally {
        testBtn.disabled = false;
        testBtn.innerHTML = original;
      }
    });
  }

  function setTestStatus(text, variant) {
    if (!testStatus) return;
    testStatus.className = `badge text-bg-${variant}`;
    testStatus.textContent = text;
  }

  async function readJson(response) {
    const text = await response.text();
    if (!text) return {};
    try { return JSON.parse(text); } catch { return { message: text }; }
  }

  async function safeError(response) {
    const body = await readJson(response);
    return body.error || body.message || `${response.status} ${response.statusText}`;
  }

  load();
})();
