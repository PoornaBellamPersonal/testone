package com.example.cmsrules;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CmsRuleDmnPocApplication {
    public static void main(String[] args) {
        SpringApplication.run(CmsRuleDmnPocApplication.class, args);
    }
}
