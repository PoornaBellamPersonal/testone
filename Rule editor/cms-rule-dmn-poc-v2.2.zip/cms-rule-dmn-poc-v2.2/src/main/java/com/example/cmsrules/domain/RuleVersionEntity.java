package com.example.cmsrules.domain;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "rule_version",
       uniqueConstraints = @UniqueConstraint(name = "uk_rule_version", columnNames = {"rule_id", "version_number"}))
public class RuleVersionEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "rule_id", nullable = false)
    private RuleDefinitionEntity rule;

    @Column(name = "version_number", nullable = false)
    private Integer versionNumber;

    @Lob
    @Column(name = "dmn_xml", nullable = false, columnDefinition = "CLOB")
    private String dmnXml;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private RuleStatus status = RuleStatus.ACTIVE;

    @Column(length = 500)
    private String comment;

    @Column(nullable = false, length = 80)
    private String createdBy;

    @Column(nullable = false)
    private LocalDateTime createdAt;

    @PrePersist
    void prePersist() {
        createdAt = createdAt == null ? LocalDateTime.now() : createdAt;
        createdBy = createdBy == null ? "system" : createdBy;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public RuleDefinitionEntity getRule() { return rule; }
    public void setRule(RuleDefinitionEntity rule) { this.rule = rule; }
    public Integer getVersionNumber() { return versionNumber; }
    public void setVersionNumber(Integer versionNumber) { this.versionNumber = versionNumber; }
    public String getDmnXml() { return dmnXml; }
    public void setDmnXml(String dmnXml) { this.dmnXml = dmnXml; }
    public RuleStatus getStatus() { return status; }
    public void setStatus(RuleStatus status) { this.status = status; }
    public String getComment() { return comment; }
    public void setComment(String comment) { this.comment = comment; }
    public String getCreatedBy() { return createdBy; }
    public void setCreatedBy(String createdBy) { this.createdBy = createdBy; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}
