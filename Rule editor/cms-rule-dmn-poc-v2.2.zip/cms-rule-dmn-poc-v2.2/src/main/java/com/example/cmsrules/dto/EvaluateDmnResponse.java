package com.example.cmsrules.dto;

import java.util.List;
import java.util.Map;

public record EvaluateDmnResponse(
    Long ruleId,
    Integer version,
    String decisionKey,
    boolean matched,
    List<Map<String, Object>> results,
    long executionTimeMs
) {}
