package com.example.cmsrules.service;

import com.example.cmsrules.domain.*;
import com.example.cmsrules.dto.CreateRuleRequest;
import com.example.cmsrules.dto.CreateRuleSetRequest;
import com.example.cmsrules.repository.RuleDefinitionRepository;
import com.example.cmsrules.repository.RuleSetRepository;
import com.example.cmsrules.repository.RuleVersionRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;

@Service
public class RuleManagementService {

    private static final long MAX_IMPORT_BYTES = 5L * 1024 * 1024;

    private final RuleSetRepository ruleSetRepository;
    private final RuleDefinitionRepository ruleRepository;
    private final RuleVersionRepository versionRepository;
    private final DmnExecutionService dmnExecutionService;

    public RuleManagementService(RuleSetRepository ruleSetRepository,
                                 RuleDefinitionRepository ruleRepository,
                                 RuleVersionRepository versionRepository,
                                 DmnExecutionService dmnExecutionService) {
        this.ruleSetRepository = ruleSetRepository;
        this.ruleRepository = ruleRepository;
        this.versionRepository = versionRepository;
        this.dmnExecutionService = dmnExecutionService;
    }

    @Transactional(readOnly = true)
    public List<RuleSetEntity> listRuleSets() {
        return ruleSetRepository.findByStatusNotOrderByUpdatedAtDesc(RuleStatus.DELETED);
    }

    @Transactional(readOnly = true)
    public RuleSetEntity getRuleSet(Long id) {
        return ruleSetRepository.findById(id)
            .filter(rs -> rs.getStatus() != RuleStatus.DELETED)
            .orElseThrow(() -> new EntityNotFoundException("Rule set not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<RuleDefinitionEntity> listRules(Long ruleSetId) {
        return ruleRepository.findByRuleSetIdAndStatusNotOrderByUpdatedAtDesc(ruleSetId, RuleStatus.DELETED);
    }

    @Transactional(readOnly = true)
    public RuleDefinitionEntity getRule(Long id) {
        return ruleRepository.findById(id)
            .filter(rule -> rule.getStatus() != RuleStatus.DELETED)
            .orElseThrow(() -> new EntityNotFoundException("Rule not found: " + id));
    }

    @Transactional(readOnly = true)
    public RuleVersionEntity currentVersion(Long ruleId) {
        var rule = getRule(ruleId);
        return versionRepository.findByRuleIdAndVersionNumber(ruleId, rule.getCurrentVersion())
            .orElseThrow(() -> new EntityNotFoundException("Current rule version not found for rule: " + ruleId));
    }

    @Transactional(readOnly = true)
    public List<RuleVersionEntity> versions(Long ruleId) {
        return versionRepository.findByRuleIdOrderByVersionNumberDesc(ruleId);
    }

    @Transactional
    public RuleSetEntity createRuleSet(CreateRuleSetRequest request, Authentication auth) {
        String code = normalizeCode(request.getCode());
        if (ruleSetRepository.findByCode(code).isPresent()) {
            throw new IllegalArgumentException("A rule set with code '" + code + "' already exists");
        }
        if (request.getName() == null || request.getName().isBlank()) {
            throw new IllegalArgumentException("Rule set name is required");
        }

        var entity = new RuleSetEntity();
        entity.setCode(code);
        entity.setName(request.getName().trim());
        entity.setDescription(trimToNull(request.getDescription()));
        entity.setStatus(RuleStatus.ACTIVE);
        entity.setCreatedBy(username(auth));
        entity.setUpdatedBy(username(auth));
        return ruleSetRepository.save(entity);
    }

    @Transactional
    public RuleDefinitionEntity createRule(Long ruleSetId, CreateRuleRequest request, Authentication auth) {
        var ruleSet = getRuleSet(ruleSetId);
        String code = normalizeCode(request.getCode());
        ensureUniqueRuleCode(ruleSetId, code);
        if (request.getName() == null || request.getName().isBlank()) {
            throw new IllegalArgumentException("Rule name is required");
        }

        var rule = new RuleDefinitionEntity();
        rule.setRuleSet(ruleSet);
        rule.setCode(code);
        rule.setName(request.getName().trim());
        rule.setDescription(trimToNull(request.getDescription()));
        rule.setRuleType(RuleType.DMN);
        rule.setStatus(RuleStatus.DRAFT);
        rule.setCurrentVersion(1);
        rule.setCreatedBy(username(auth));
        rule.setUpdatedBy(username(auth));
        rule = ruleRepository.save(rule);

        var version = new RuleVersionEntity();
        version.setRule(rule);
        version.setVersionNumber(1);
        version.setDmnXml(blankDmn(rule));
        version.setStatus(RuleStatus.DRAFT);
        version.setComment("Initial version created in CMS");
        version.setCreatedBy(username(auth));
        versionRepository.save(version);
        return rule;
    }

    @Transactional
    public RuleDefinitionEntity importDmn(Long ruleSetId,
                                          MultipartFile file,
                                          String requestedCode,
                                          String requestedName,
                                          String description,
                                          Authentication auth) {
        var ruleSet = getRuleSet(ruleSetId);
        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException("Choose a DMN file to import");
        }
        if (file.getSize() > MAX_IMPORT_BYTES) {
            throw new IllegalArgumentException("DMN file is larger than the 5 MB POC import limit");
        }

        final String xml;
        try {
            xml = new String(file.getBytes(), StandardCharsets.UTF_8);
        } catch (Exception e) {
            throw new IllegalArgumentException("Unable to read the uploaded DMN file", e);
        }
        if (xml.isBlank()) {
            throw new IllegalArgumentException("Uploaded DMN file is empty");
        }

        dmnExecutionService.validate(xml, null);
        var metadata = readDmnMetadata(xml, file.getOriginalFilename());

        String codeSource = hasText(requestedCode) ? requestedCode : metadata.decisionId();
        if (!hasText(codeSource)) codeSource = stripExtension(file.getOriginalFilename());
        String code = normalizeCode(codeSource);
        ensureUniqueRuleCode(ruleSetId, code);

        String name = hasText(requestedName) ? requestedName.trim() : metadata.decisionName();
        if (!hasText(name)) name = humanize(stripExtension(file.getOriginalFilename()));
        if (!hasText(name)) name = code;

        var rule = new RuleDefinitionEntity();
        rule.setRuleSet(ruleSet);
        rule.setCode(code);
        rule.setName(name);
        rule.setDescription(trimToNull(description));
        rule.setRuleType(RuleType.DMN);
        rule.setStatus(RuleStatus.ACTIVE);
        rule.setCurrentVersion(1);
        rule.setCreatedBy(username(auth));
        rule.setUpdatedBy(username(auth));
        rule = ruleRepository.save(rule);

        var version = new RuleVersionEntity();
        version.setRule(rule);
        version.setVersionNumber(1);
        version.setDmnXml(xml);
        version.setStatus(RuleStatus.ACTIVE);
        version.setComment("Imported from " + safeFilename(file.getOriginalFilename()));
        version.setCreatedBy(username(auth));
        versionRepository.save(version);
        return rule;
    }

    @Transactional
    public RuleVersionEntity saveNewVersion(Long ruleId, String xml, String comment, Authentication auth) {
        if (xml == null || xml.isBlank()) {
            throw new IllegalArgumentException("DMN XML must not be empty");
        }
        var rule = getRule(ruleId);
        dmnExecutionService.validate(xml, rule.getCode());

        var next = rule.getCurrentVersion() + 1;
        var version = new RuleVersionEntity();
        version.setRule(rule);
        version.setVersionNumber(next);
        version.setDmnXml(xml);
        version.setStatus(RuleStatus.ACTIVE);
        version.setComment(hasText(comment) ? comment.trim() : "Updated from CMS editor");
        version.setCreatedBy(username(auth));
        versionRepository.save(version);

        rule.setCurrentVersion(next);
        rule.setStatus(RuleStatus.ACTIVE);
        rule.setUpdatedBy(username(auth));
        ruleRepository.save(rule);
        dmnExecutionService.evict(ruleId);
        return version;
    }

    @Transactional
    public void deleteRule(Long ruleId, Authentication auth) {
        var rule = getRule(ruleId);
        rule.setStatus(RuleStatus.DELETED);
        rule.setUpdatedBy(username(auth));
        ruleRepository.save(rule);
        dmnExecutionService.evict(ruleId);
    }

    public long ruleCount(Long ruleSetId) {
        return ruleRepository.countByRuleSetIdAndStatusNot(ruleSetId, RuleStatus.DELETED);
    }

    private void ensureUniqueRuleCode(Long ruleSetId, String code) {
        if (ruleRepository.existsByRuleSetIdAndCode(ruleSetId, code)) {
            throw new IllegalArgumentException("A rule with code '" + code + "' already exists in this rule set");
        }
    }

    private String username(Authentication auth) {
        return auth == null ? "system" : auth.getName();
    }

    private String normalizeCode(String code) {
        if (!hasText(code)) throw new IllegalArgumentException("Code is required");
        String normalized = code.trim().toUpperCase().replaceAll("[^A-Z0-9_]+", "_")
            .replaceAll("^_+|_+$", "");
        if (normalized.isBlank()) throw new IllegalArgumentException("Code must contain letters or numbers");
        return normalized;
    }

    private String blankDmn(RuleDefinitionEntity rule) {
        String decisionId = "Decision_" + rule.getCode();
        return """
            <?xml version="1.0" encoding="UTF-8"?>
            <definitions xmlns="https://www.omg.org/spec/DMN/20191111/MODEL/"
                         xmlns:dmndi="https://www.omg.org/spec/DMN/20191111/DMNDI/"
                         xmlns:dc="http://www.omg.org/spec/DMN/20180521/DC/"
                         xmlns:di="http://www.omg.org/spec/DMN/20180521/DI/"
                         xmlns:camunda="http://camunda.org/schema/1.0/dmn"
                         id="Definitions_%s"
                         name="%s"
                         namespace="http://example.com/cms/dmn">
              <decision id="%s" name="%s">
                <decisionTable id="DecisionTable_1" hitPolicy="FIRST">
                  <input id="Input_1" label="Input">
                    <inputExpression id="InputExpression_1" typeRef="string">
                      <text>input</text>
                    </inputExpression>
                  </input>
                  <output id="Output_1" label="Result" name="result" typeRef="string" />
                  <rule id="Rule_1">
                    <inputEntry id="InputEntry_1"><text>-</text></inputEntry>
                    <outputEntry id="OutputEntry_1"><text>"OK"</text></outputEntry>
                  </rule>
                </decisionTable>
              </decision>
            </definitions>
            """.formatted(rule.getCode(), xmlEscape(rule.getName()), decisionId, xmlEscape(rule.getName()));
    }

    private ImportedDmnMetadata readDmnMetadata(String xml, String originalFilename) {
        try {
            var factory = DocumentBuilderFactory.newInstance();
            factory.setNamespaceAware(true);
            factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
            factory.setFeature("http://xml.org/sax/features/external-general-entities", false);
            factory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
            factory.setXIncludeAware(false);
            factory.setExpandEntityReferences(false);
            factory.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "");
            factory.setAttribute(XMLConstants.ACCESS_EXTERNAL_SCHEMA, "");
            var document = factory.newDocumentBuilder().parse(
                new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)));
            var decisions = document.getElementsByTagNameNS("*", "decision");
            if (decisions.getLength() == 0) {
                return new ImportedDmnMetadata(stripExtension(originalFilename), null);
            }
            var decision = decisions.item(0);
            var attrs = decision.getAttributes();
            var id = attrs.getNamedItem("id");
            var name = attrs.getNamedItem("name");
            return new ImportedDmnMetadata(
                id == null ? null : id.getNodeValue(),
                name == null ? null : name.getNodeValue());
        } catch (Exception e) {
            throw new IllegalArgumentException("Unable to inspect DMN metadata: " + e.getMessage(), e);
        }
    }

    private String stripExtension(String filename) {
        if (!hasText(filename)) return null;
        String safe = safeFilename(filename);
        int dot = safe.lastIndexOf('.');
        return dot > 0 ? safe.substring(0, dot) : safe;
    }

    private String safeFilename(String filename) {
        if (!hasText(filename)) return "uploaded.dmn";
        String normalized = filename.replace('\\', '/');
        int slash = normalized.lastIndexOf('/');
        return slash >= 0 ? normalized.substring(slash + 1) : normalized;
    }

    private String humanize(String value) {
        if (!hasText(value)) return null;
        String normalized = value.replace('_', ' ').replace('-', ' ').trim();
        if (normalized.isBlank()) return null;
        String[] parts = normalized.split("\\s+");
        var out = new StringBuilder();
        for (String part : parts) {
            if (part.isBlank()) continue;
            if (!out.isEmpty()) out.append(' ');
            out.append(Character.toUpperCase(part.charAt(0)));
            if (part.length() > 1) out.append(part.substring(1));
        }
        return out.toString();
    }

    private String trimToNull(String value) {
        return hasText(value) ? value.trim() : null;
    }

    private boolean hasText(String value) {
        return value != null && !value.isBlank();
    }

    private String xmlEscape(String value) {
        if (value == null) return "";
        return value.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
            .replace("'", "&apos;");
    }

    private record ImportedDmnMetadata(String decisionId, String decisionName) {}
}
