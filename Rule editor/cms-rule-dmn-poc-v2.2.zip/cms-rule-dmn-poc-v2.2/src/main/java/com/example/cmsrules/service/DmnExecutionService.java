package com.example.cmsrules.service;

import com.example.cmsrules.dto.EvaluateDmnResponse;
import com.example.cmsrules.repository.RuleDefinitionRepository;
import com.example.cmsrules.repository.RuleVersionRepository;
import jakarta.persistence.EntityNotFoundException;
import org.camunda.bpm.dmn.engine.DmnDecision;
import org.camunda.bpm.dmn.engine.DmnDecisionResult;
import org.camunda.bpm.dmn.engine.DmnEngine;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class DmnExecutionService {

    private final DmnEngine dmnEngine;
    private final RuleDefinitionRepository ruleRepository;
    private final RuleVersionRepository versionRepository;
    private final Map<String, DmnDecision> cache = new ConcurrentHashMap<>();

    public DmnExecutionService(DmnEngine dmnEngine,
                               RuleDefinitionRepository ruleRepository,
                               RuleVersionRepository versionRepository) {
        this.dmnEngine = dmnEngine;
        this.ruleRepository = ruleRepository;
        this.versionRepository = versionRepository;
    }

    @Transactional(readOnly = true)
    public EvaluateDmnResponse evaluate(Long ruleId, Map<String, Object> variables) {
        var rule = ruleRepository.findById(ruleId)
            .orElseThrow(() -> new EntityNotFoundException("Rule not found: " + ruleId));
        var version = versionRepository.findByRuleIdAndVersionNumber(ruleId, rule.getCurrentVersion())
            .orElseThrow(() -> new EntityNotFoundException("Rule version not found: " + rule.getCurrentVersion()));

        var cacheKey = ruleId + ":" + version.getVersionNumber();
        var decision = cache.computeIfAbsent(cacheKey,
            key -> parse(version.getDmnXml(), null));

        long start = System.nanoTime();
        DmnDecisionResult result = dmnEngine.evaluateDecision(decision, variables == null ? Map.of() : variables);
        long elapsedMs = (System.nanoTime() - start) / 1_000_000L;

        return new EvaluateDmnResponse(
            ruleId,
            version.getVersionNumber(),
            decision.getKey(),
            !result.isEmpty(),
            result.getResultList(),
            elapsedMs
        );
    }

    public void validate(String xml, String expectedRuleCode) {
        var decision = parse(xml, null);
        if (decision.getKey() == null || decision.getKey().isBlank()) {
            throw new IllegalArgumentException("DMN must contain a decision id/key");
        }
    }

    public void evict(Long ruleId) {
        String prefix = ruleId + ":";
        cache.keySet().removeIf(key -> key.startsWith(prefix));
    }

    private DmnDecision parse(String xml, String decisionKey) {
        try (var in = new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8))) {
            if (decisionKey == null || decisionKey.isBlank()) {
                var decisions = dmnEngine.parseDecisions(in);
                if (decisions.isEmpty()) throw new IllegalArgumentException("No DMN decision found");
                return decisions.get(0);
            }
            return dmnEngine.parseDecision(decisionKey, in);
        } catch (Exception e) {
            throw new IllegalArgumentException("Invalid DMN XML: " + e.getMessage(), e);
        }
    }
}
