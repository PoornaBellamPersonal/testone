package com.example.cmsrules.dto;

import java.util.Map;

public record EvaluateDmnRequest(Map<String, Object> variables) {}
