package com.example.cmsrules.config;

import com.example.cmsrules.domain.*;
import com.example.cmsrules.repository.RuleDefinitionRepository;
import com.example.cmsrules.repository.RuleSetRepository;
import com.example.cmsrules.repository.RuleVersionRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;

import java.nio.charset.StandardCharsets;

@Configuration
public class DemoDataConfig {

    @Bean
    CommandLineRunner seedDemoData(RuleSetRepository ruleSetRepository,
                                   RuleDefinitionRepository ruleRepository,
                                   RuleVersionRepository versionRepository) {
        return args -> {
            if (ruleSetRepository.count() > 0) return;

            var set = new RuleSetEntity();
            set.setCode("COMMISSION");
            set.setName("Commission Rules");
            set.setDescription("Demo rules used to determine commission percentage.");
            set.setStatus(RuleStatus.ACTIVE);
            set.setCreatedBy("admin");
            set.setUpdatedBy("admin");
            set = ruleSetRepository.save(set);

            var rule = new RuleDefinitionEntity();
            rule.setRuleSet(set);
            rule.setCode("BASE_COMMISSION");
            rule.setName("Base Commission");
            rule.setDescription("Determines commission percentage by region, product and amount.");
            rule.setRuleType(RuleType.DMN);
            rule.setStatus(RuleStatus.ACTIVE);
            rule.setCurrentVersion(1);
            rule.setCreatedBy("admin");
            rule.setUpdatedBy("admin");
            rule = ruleRepository.save(rule);

            var resource = new ClassPathResource("dmn/base-commission.dmn");
            String xml;
            try (var in = resource.getInputStream()) {
                xml = new String(in.readAllBytes(), StandardCharsets.UTF_8);
            }
            var version = new RuleVersionEntity();
            version.setRule(rule);
            version.setVersionNumber(1);
            version.setDmnXml(xml);
            version.setStatus(RuleStatus.ACTIVE);
            version.setComment("Seeded demonstration rule");
            version.setCreatedBy("admin");
            versionRepository.save(version);
        };
    }
}
