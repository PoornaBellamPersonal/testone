package com.example.cmsrules.controller;

import com.example.cmsrules.dto.CreateRuleRequest;
import com.example.cmsrules.dto.CreateRuleSetRequest;
import com.example.cmsrules.service.RuleManagementService;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.LinkedHashMap;

@Controller
public class RulePageController {

    private final RuleManagementService service;

    public RulePageController(RuleManagementService service) {
        this.service = service;
    }

    @GetMapping("/rulesets")
    String ruleSets(Model model) {
        var sets = service.listRuleSets();
        var counts = new LinkedHashMap<Long, Long>();
        long totalRules = 0;
        for (var set : sets) {
            long count = service.ruleCount(set.getId());
            counts.put(set.getId(), count);
            totalRules += count;
        }
        model.addAttribute("ruleSets", sets);
        model.addAttribute("ruleCount", counts);
        model.addAttribute("totalRuleCount", totalRules);
        return "rulesets";
    }

    @PostMapping("/rulesets")
    String createRuleSet(@ModelAttribute CreateRuleSetRequest request,
                         Authentication auth,
                         RedirectAttributes redirect) {
        try {
            var saved = service.createRuleSet(request, auth);
            redirect.addFlashAttribute("message", "Rule set created successfully");
            return "redirect:/rulesets/" + saved.getId();
        } catch (RuntimeException e) {
            redirect.addFlashAttribute("error", userMessage(e));
            return "redirect:/rulesets";
        }
    }

    @GetMapping("/rulesets/{id}")
    String ruleSet(@PathVariable Long id,
                   @RequestParam(required = false) Long ruleId,
                   @RequestParam(defaultValue = "view") String mode,
                   Model model) {
        var ruleSet = service.getRuleSet(id);
        var rules = service.listRules(id);
        model.addAttribute("ruleSet", ruleSet);
        model.addAttribute("rules", rules);
        model.addAttribute("ruleCount", rules.size());

        if (ruleId != null) {
            var rule = service.getRule(ruleId);
            if (!rule.getRuleSet().getId().equals(id)) {
                throw new IllegalArgumentException("Rule does not belong to this rule set");
            }
            model.addAttribute("selectedRule", rule);
            model.addAttribute("selectedVersion", service.currentVersion(ruleId));
            model.addAttribute("versions", service.versions(ruleId));
            model.addAttribute("editable", "edit".equalsIgnoreCase(mode));
        }
        return "ruleset-detail";
    }

    @PostMapping("/rulesets/{id}/rules")
    String createRule(@PathVariable Long id,
                      @ModelAttribute CreateRuleRequest request,
                      Authentication auth,
                      RedirectAttributes redirect) {
        try {
            var rule = service.createRule(id, request, auth);
            redirect.addFlashAttribute("message", "Blank DMN rule created. You can model it below.");
            return "redirect:/rulesets/" + id + "?ruleId=" + rule.getId() + "&mode=edit#editor";
        } catch (RuntimeException e) {
            redirect.addFlashAttribute("error", userMessage(e));
            return "redirect:/rulesets/" + id;
        }
    }

    @PostMapping("/rulesets/{id}/rules/import")
    String importRule(@PathVariable Long id,
                      @RequestParam("file") MultipartFile file,
                      @RequestParam(required = false) String code,
                      @RequestParam(required = false) String name,
                      @RequestParam(required = false) String description,
                      Authentication auth,
                      RedirectAttributes redirect) {
        try {
            var rule = service.importDmn(id, file, code, name, description, auth);
            redirect.addFlashAttribute("message", "DMN imported successfully as rule '" + rule.getName() + "'.");
            return "redirect:/rulesets/" + id + "?ruleId=" + rule.getId() + "&mode=edit#editor";
        } catch (RuntimeException e) {
            redirect.addFlashAttribute("error", userMessage(e));
            return "redirect:/rulesets/" + id;
        }
    }

    @GetMapping("/rules/{id}/view")
    String view(@PathVariable Long id) {
        var rule = service.getRule(id);
        return "redirect:/rulesets/" + rule.getRuleSet().getId() + "?ruleId=" + id + "&mode=view#editor";
    }

    @GetMapping("/rules/{id}/edit")
    String edit(@PathVariable Long id) {
        var rule = service.getRule(id);
        return "redirect:/rulesets/" + rule.getRuleSet().getId() + "?ruleId=" + id + "&mode=edit#editor";
    }

    @PostMapping("/rules/{id}/delete")
    String delete(@PathVariable Long id, Authentication auth, RedirectAttributes redirect) {
        var rule = service.getRule(id);
        var setId = rule.getRuleSet().getId();
        service.deleteRule(id, auth);
        redirect.addFlashAttribute("message", "Rule removed from the active rule set");
        return "redirect:/rulesets/" + setId;
    }

    private String userMessage(RuntimeException e) {
        String message = e.getMessage();
        if (message == null || message.isBlank()) return "The requested operation could not be completed";
        return message.length() > 300 ? message.substring(0, 300) : message;
    }
}
