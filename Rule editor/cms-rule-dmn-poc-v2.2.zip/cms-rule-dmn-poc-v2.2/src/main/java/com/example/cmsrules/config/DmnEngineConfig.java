package com.example.cmsrules.config;

import org.camunda.bpm.dmn.engine.DmnEngine;
import org.camunda.bpm.dmn.engine.DmnEngineConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DmnEngineConfig {

    @Bean
    DmnEngine dmnEngine() {
        return DmnEngineConfiguration
            .createDefaultDmnEngineConfiguration()
            .buildEngine();
    }
}
