package com.example.cmsrules.domain;

public enum RuleType {
    DMN
}
