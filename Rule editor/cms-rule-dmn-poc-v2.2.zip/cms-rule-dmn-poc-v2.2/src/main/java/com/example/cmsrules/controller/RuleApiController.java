package com.example.cmsrules.controller;

import com.example.cmsrules.dto.EvaluateDmnRequest;
import com.example.cmsrules.dto.SaveDmnRequest;
import com.example.cmsrules.service.DmnExecutionService;
import com.example.cmsrules.service.RuleManagementService;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.nio.charset.StandardCharsets;
import java.util.Map;

@RestController
@RequestMapping("/api/rules")
public class RuleApiController {

    private final RuleManagementService ruleService;
    private final DmnExecutionService executionService;

    public RuleApiController(RuleManagementService ruleService, DmnExecutionService executionService) {
        this.ruleService = ruleService;
        this.executionService = executionService;
    }

    @GetMapping(value = "/{id}/dmn", produces = "application/xml;charset=UTF-8")
    ResponseEntity<String> dmn(@PathVariable Long id) {
        return ResponseEntity.ok(ruleService.currentVersion(id).getDmnXml());
    }

    @GetMapping("/{id}/dmn/download")
    ResponseEntity<byte[]> download(@PathVariable Long id) {
        var rule = ruleService.getRule(id);
        var xml = ruleService.currentVersion(id).getDmnXml();
        var filename = rule.getCode().toLowerCase() + "-v" + rule.getCurrentVersion() + ".dmn";
        return ResponseEntity.ok()
            .contentType(MediaType.parseMediaType("application/xml"))
            .header(HttpHeaders.CONTENT_DISPOSITION,
                ContentDisposition.attachment().filename(filename, StandardCharsets.UTF_8).build().toString())
            .body(xml.getBytes(StandardCharsets.UTF_8));
    }

    @PutMapping("/{id}/dmn")
    Map<String, Object> save(@PathVariable Long id,
                             @RequestBody SaveDmnRequest request,
                             Authentication auth) {
        var saved = ruleService.saveNewVersion(id, request.xml(), request.comment(), auth);
        return Map.of(
            "ruleId", id,
            "version", saved.getVersionNumber(),
            "message", "DMN saved as version " + saved.getVersionNumber()
        );
    }

    @PostMapping("/{id}/evaluate")
    Object evaluate(@PathVariable Long id, @RequestBody EvaluateDmnRequest request) {
        return executionService.evaluate(id, request.variables());
    }
}
