package com.example.cmsrules.repository;

import com.example.cmsrules.domain.RuleVersionEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface RuleVersionRepository extends JpaRepository<RuleVersionEntity, Long> {
    Optional<RuleVersionEntity> findByRuleIdAndVersionNumber(Long ruleId, Integer versionNumber);
    List<RuleVersionEntity> findByRuleIdOrderByVersionNumberDesc(Long ruleId);
}
