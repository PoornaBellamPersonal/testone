package com.example.cmsrules.domain;

public enum RuleStatus {
    DRAFT,
    ACTIVE,
    INACTIVE,
    DELETED
}
