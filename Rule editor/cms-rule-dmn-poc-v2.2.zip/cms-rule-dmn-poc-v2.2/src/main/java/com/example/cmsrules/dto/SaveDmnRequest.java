package com.example.cmsrules.dto;

public record SaveDmnRequest(String xml, String comment) {}
