package com.example.cmsrules.repository;

import com.example.cmsrules.domain.RuleSetEntity;
import com.example.cmsrules.domain.RuleStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface RuleSetRepository extends JpaRepository<RuleSetEntity, Long> {
    List<RuleSetEntity> findByStatusNotOrderByUpdatedAtDesc(RuleStatus status);
    Optional<RuleSetEntity> findByCode(String code);
}
