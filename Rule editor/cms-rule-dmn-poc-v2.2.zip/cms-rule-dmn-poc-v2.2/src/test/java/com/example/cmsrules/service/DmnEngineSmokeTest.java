package com.example.cmsrules.service;

import org.camunda.bpm.dmn.engine.DmnEngineConfiguration;
import org.junit.jupiter.api.Test;

import java.io.InputStream;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class DmnEngineSmokeTest {

    @Test
    void evaluatesSeededCommissionRule() {
        var engine = DmnEngineConfiguration.createDefaultDmnEngineConfiguration().buildEngine();

        try (InputStream in = getClass().getResourceAsStream("/dmn/base-commission.dmn")) {
            assertNotNull(in, "Seed DMN resource must be available");

            var decision = engine.parseDecision("baseCommission", in);
            var result = engine.evaluateDecision(decision, Map.of(
                "region", "APAC",
                "product", "LIFE",
                "amount", 25000
            ));

            Object commissionValue = result.getSingleResult().getEntry("commissionPercentage");
            Number commission = assertInstanceOf(Number.class, commissionValue);
            assertEquals(8.0d, commission.doubleValue(), 0.000001d);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
