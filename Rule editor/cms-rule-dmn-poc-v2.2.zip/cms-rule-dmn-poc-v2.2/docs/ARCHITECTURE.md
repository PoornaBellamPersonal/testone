# CMS Rule Management POC – Architecture

## Runtime shape

```text
Browser
  |
  | Spring MVC / Thymeleaf pages + JSON/XML API calls
  v
CMS Rule Management Spring Boot application
  |
  +-- Rule-set / rule / version services
  +-- Camunda standalone DMN engine
  +-- Parsed-decision cache
  +-- File-based H2
```

The UI is server-rendered Thymeleaf. `dmn-js` is embedded only inside the selected rule editor area.

## Domain model

### RuleSetEntity

Logical grouping such as Commission Rules, Eligibility Rules or Validation Rules.

### RuleDefinitionEntity

The stable identity and metadata for a managed rule. It currently has `ruleType = DMN`, but the domain model does not require every future rule type to be DMN.

### RuleVersionEntity

Immutable stored rule source. For DMN rules the source is the complete DMN XML document.

Saving never overwrites an existing `RuleVersionEntity`; it creates the next version and moves `currentVersion` forward.

## Create vs import

### Create

CMS generates a minimal executable decision table and opens it in the embedded modeler.

### Import

1. Browser posts a multipart `.dmn`/XML file.
2. Backend enforces the POC size limit.
3. Camunda DMN engine parses/validates the source.
4. The importer safely reads decision metadata for default rule code/name suggestions.
5. CMS creates `RuleDefinitionEntity` + version 1 containing the original XML.
6. User is redirected to inline edit mode.

## Editor synchronization

```text
               +--------------------+
               |  dmn-js modeler    |
               +---------+----------+
                         |
                  saveXML / importXML
                         |
               +---------v----------+
               |  Raw XML editor    |
               +---------+----------+
                         |
                    Save version
                         |
               +---------v----------+
               | Spring REST API    |
               +---------+----------+
                         |
               +---------v----------+
               | RuleVersionEntity  |
               +--------------------+
```

The graphical model and XML source are two editing views over the same DMN document.

## Execution

Evaluation always uses the latest **saved** version:

```text
ruleId
  -> currentVersion
  -> DMN XML
  -> cached parsed DmnDecision
  -> evaluate with variables
  -> JSON result
```

Saving a new version evicts cached decisions for that rule.

## Deletion

The POC performs a soft delete by setting rule status to `DELETED`. Version rows are retained.

## POC limitations / next design decisions

- Imported DMN documents containing multiple decisions are accepted; the current execution service evaluates the first parsed decision. A production design should persist/select an explicit execution decision key.
- dmn-js assets are currently loaded from unpkg; vendor them locally for restricted/offline runtime environments.
- Approval/publish/effective-date lifecycle is not yet implemented.
- API authorization is authenticated-user only; granular roles are a future increment.
