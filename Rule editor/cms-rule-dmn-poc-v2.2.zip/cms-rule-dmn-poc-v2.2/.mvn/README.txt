The included mvnw / mvnw.cmd launchers use an installed Maven if present.
If Maven is not on PATH they download Apache Maven 3.9.16 into this directory on first use.
