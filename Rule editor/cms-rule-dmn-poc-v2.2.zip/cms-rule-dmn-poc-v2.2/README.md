# CMS Rule Management – Camunda DMN POC

A server-rendered CMS demonstration module for managing business rule sets and Camunda DMN rules.

## Technology stack

- Java 17
- Spring Boot 3.3.13
- Spring MVC + Thymeleaf
- Spring Security
- Spring Data JPA
- File-based H2
- Camunda DMN Engine 7.24.0 (standalone DMN engine)
- Bootstrap 5.3.8 via WebJar
- Bootstrap Icons 1.13.1 via WebJar
- dmn-js 17.10.1 pre-packaged browser modeler/viewer

No React, npm build, Docker, Kafka, or external application server is required.

## V1 POC features

### Rule-set management

- Login page (`admin / admin`)
- Simple professional Bootstrap UI
- Create rule sets
- Data-table rule-set listing with search/filter
- Open a rule set and list all managed rules

### DMN rule management

- Add a rule (DMN currently supported) from a blank executable decision-table template
- Import an existing `.dmn` or XML DMN file as a rule
- Optional rule code/name overrides during import
- Camunda-engine validation before imported XML is stored
- View a DMN inline on the rule-set page
- Edit a DMN inline using `dmn-js`
- Edit raw DMN XML in the same screen
- Synchronize graphical changes -> XML
- Apply XML changes -> graphical modeler
- Save edits as a new immutable rule version
- Test/evaluate the latest saved version using JSON variables
- View version history
- Export/download the current version as a `.dmn` file
- Soft delete rules

## Important POC rule model

```text
RuleSet
  └── RuleDefinition
        └── RuleVersion 1
        └── RuleVersion 2
        └── RuleVersion 3
```

`RuleDefinition.ruleType` is currently `DMN`, leaving room for future rule types such as Drools, scripts, Excel decision tables or external APIs.

## Run

### If Maven is installed

```bash
mvn clean test
mvn spring-boot:run
```

### Windows convenience launcher

```bat
mvnw.cmd clean test
mvnw.cmd spring-boot:run
```

### Linux/macOS convenience launcher

```bash
./mvnw clean test
./mvnw spring-boot:run
```

The included launcher uses Maven from `PATH` when available. Otherwise it downloads Apache Maven 3.9.16 on first use.

Open:

```text
http://localhost:8080
```

Credentials:

```text
admin / admin
```

## Demo walkthrough

1. Sign in.
2. Open **Commission Rules**.
3. Open **Base Commission** in View or Edit mode.
4. Use **DMN Modeler** for graphical editing.
5. Use **DMN XML** to inspect/edit the XML source.
6. Click **Save New Version**.
7. Open **Test** and evaluate with:

```json
{
  "region": "APAC",
  "product": "LIFE",
  "amount": 25000
}
```

The seeded rule should return `commissionPercentage = 8`.

### Import flow

1. Open a rule set.
2. Click **Import DMN**.
3. Select a `.dmn` or `.xml` file.
4. Optionally provide a CMS rule code/name.
5. Click **Import & Edit**.
6. The backend validates the XML with the Camunda DMN engine and stores it as version 1.
7. The imported rule opens immediately in edit mode.

## Persistence

H2 is file based:

```text
./data/cms-rule-db.mv.db
```

To start with an empty database, stop the application and remove the `data` directory.

H2 console:

```text
http://localhost:8080/h2-console
```

JDBC URL:

```text
jdbc:h2:file:./data/cms-rule-db
```

User: `sa`, password blank.

## Front-end asset note

Bootstrap and Bootstrap Icons are packaged by Maven as WebJars. The dmn-js pre-packaged assets are referenced from `unpkg.com` in this POC, matching the official bpmn.io pre-packaged integration pattern. Therefore the DMN editor/viewer needs browser access to `unpkg.com`.

For a locked-down CMS environment, the same dmn-js files can be copied into `src/main/resources/static/vendor/dmn-js/` and the template URLs changed to local `/vendor/...` paths. No application code changes are required.

## Security note

This is a demonstration POC. The hard-coded Spring Security user, H2 console and API CSRF exemptions should be replaced/tightened when integrated into the real CMS authentication and authorization model.

## Suggested next increment

- Draft -> Review -> Publish -> Activate lifecycle
- Rollback to a previous version
- Compare two rule versions
- Effective-from/effective-to dates
- Role-based permissions (viewer/editor/approver/admin)
- Rule audit trail
- Bulk test cases and regression packs
- Rule-set execution/orchestration

## V2.1 correction

The smoke test now uses JUnit assertions with an explicit `Number` conversion for the DMN output value. This avoids a Java 17 compilation ambiguity caused by passing Camunda's generic `getEntry(...)` result directly to AssertJ's overloaded `assertThat(...)` methods.

## V2.2 UI refinements

- Compact, simple Bootstrap login page.
- Rule-set dashboard uses a searchable professional data table instead of cards.
- Rule creation action is named **Add Rule** so the UI is not coupled to DMN terminology.
- The Add Rule dialog shows **Rule Type: DMN Decision Table** as the currently supported POC option, leaving the UX ready for additional rule types later.
