@echo off
setlocal

where mvn >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  mvn %*
  exit /b %ERRORLEVEL%
)

set MAVEN_VERSION=3.9.16
set BASE_DIR=%~dp0
set INSTALL_DIR=%BASE_DIR%.mvn\apache-maven-%MAVEN_VERSION%
set ARCHIVE=%BASE_DIR%.mvn\apache-maven-%MAVEN_VERSION%-bin.zip
set URL=https://dlcdn.apache.org/maven/maven-3/%MAVEN_VERSION%/binaries/apache-maven-%MAVEN_VERSION%-bin.zip

if not exist "%INSTALL_DIR%\bin\mvn.cmd" (
  if not exist "%BASE_DIR%.mvn" mkdir "%BASE_DIR%.mvn"
  echo Maven not found. Downloading Apache Maven %MAVEN_VERSION%...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -UseBasicParsing -Uri '%URL%' -OutFile '%ARCHIVE%'; Expand-Archive -Force -Path '%ARCHIVE%' -DestinationPath '%BASE_DIR%.mvn'; Remove-Item '%ARCHIVE%'"
  if %ERRORLEVEL% NEQ 0 exit /b %ERRORLEVEL%
)

call "%INSTALL_DIR%\bin\mvn.cmd" %*
exit /b %ERRORLEVEL%
