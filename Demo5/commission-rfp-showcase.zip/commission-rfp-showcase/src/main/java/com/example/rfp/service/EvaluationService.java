package com.example.rfp.service;

import com.example.rfp.model.AttributeBag;
import com.example.rfp.model.EvaluationResult;
import com.example.rfp.repository.RfpRepository;
import org.springframework.stereotype.Service;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class EvaluationService {
    private final RfpRepository repo; private final EngineRegistry engines;
    public EvaluationService(RfpRepository repo,EngineRegistry engines){this.repo=repo;this.engines=engines;}
    public EvaluationResult evaluate(List<Long> attributeIds,List<String> values){
        Long version=repo.activeVersionId(); if(version==null) return EvaluationResult.noMatch(0,0);
        Map<Long,String> bag=new LinkedHashMap<>();
        for(int i=0;i<Math.min(attributeIds.size(),values.size());i++)if(attributeIds.get(i)!=null&&values.get(i)!=null&&!values.get(i).isBlank())bag.put(attributeIds.get(i),values.get(i));
        return engines.engine(version).evaluate(new AttributeBag(bag),true);
    }
}
