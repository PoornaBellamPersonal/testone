package com.example.rfp.repository;

import com.example.rfp.model.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import java.math.BigDecimal;
import java.sql.ResultSet;
import java.time.LocalDateTime;
import java.util.*;

@Repository
public class RfpRepository {
    private final JdbcTemplate jdbc;
    public RfpRepository(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    public long attributeCount() { return jdbc.queryForObject("select count(*) from attribute_definition where active=true", Long.class); }
    public List<AttributeDefinition> attributes() {
        return jdbc.query("select id,code,display_name,data_type,source_key,allowed_operators,active from attribute_definition order by id",
                (rs,n) -> new AttributeDefinition(rs.getLong(1), rs.getString(2), rs.getString(3), AttributeDataType.valueOf(rs.getString(4)), rs.getString(5), rs.getString(6), rs.getBoolean(7)));
    }
    public Map<Long, AttributeDefinition> attributeMap() {
        Map<Long,AttributeDefinition> m=new LinkedHashMap<>(); for (var a:attributes()) m.put(a.id(),a); return m;
    }
    public Map<String, AttributeDefinition> attributeMapByCode() {
        Map<String,AttributeDefinition> m=new LinkedHashMap<>(); for (var a:attributes()) m.put(a.code().toUpperCase(Locale.ROOT),a); return m;
    }
    public void createAttribute(String code, String display, AttributeDataType type, String sourceKey, String operators) {
        jdbc.update("insert into attribute_definition(code,display_name,data_type,source_key,allowed_operators,active) values(?,?,?,?,?,true)",
                code.trim().toUpperCase(Locale.ROOT), display.trim(), type.name(), sourceKey, operators);
    }

    public List<Map<String,Object>> versions() { return jdbc.queryForList("select * from rule_set_version order by created_at desc"); }
    public Long activeVersionId() {
        List<Long> ids = jdbc.query("select id from rule_set_version where status='ACTIVE' order by activated_at desc, id desc limit 1", (rs,n)->rs.getLong(1));
        return ids.isEmpty()?null:ids.getFirst();
    }
    public String activeVersionCode() {
        List<String> v=jdbc.query("select version_code from rule_set_version where status='ACTIVE' order by activated_at desc,id desc limit 1",(rs,n)->rs.getString(1));
        return v.isEmpty()?"NONE":v.getFirst();
    }
    public long createVersion(String code, String description) {
        jdbc.update("insert into rule_set_version(version_code,status,description) values(?, 'DRAFT', ?)", code, description);
        return jdbc.queryForObject("select id from rule_set_version where version_code=?", Long.class, code);
    }
    public long cloneActiveVersion(String newCode) {
        Long active=activeVersionId(); if(active==null) return createVersion(newCode,"Initial draft");
        long newId=createVersion(newCode,"Cloned from "+activeVersionCode());
        long offset=newId*1_000_000_000L;
        jdbc.update("insert into commission_rule(id,rule_set_id,name,priority,commission_percentage,status,created_at) select ?+id,?,name,priority,commission_percentage,status,current_timestamp from commission_rule where rule_set_id=?",offset,newId,active);
        jdbc.update("insert into rule_condition(rule_id,attribute_id,operator_code,value_1,value_2) select ?+c.rule_id,c.attribute_id,c.operator_code,c.value_1,c.value_2 from rule_condition c join commission_rule r on r.id=c.rule_id where r.rule_set_id=?",offset,active);
        return newId;
    }
    public void activateVersion(long id) {
        jdbc.update("update rule_set_version set status='RETIRED' where status='ACTIVE'");
        jdbc.update("update rule_set_version set status='ACTIVE', activated_at=current_timestamp where id=?",id);
    }

    public long ruleCount(long versionId) { return jdbc.queryForObject("select count(*) from commission_rule where rule_set_id=?",Long.class,versionId); }
    public long conditionCount(long versionId) { return jdbc.queryForObject("select count(*) from rule_condition c join commission_rule r on r.id=c.rule_id where r.rule_set_id=?",Long.class,versionId); }
    public long transactionCount() { return jdbc.queryForObject("select count(*) from transaction_record",Long.class); }

    public List<Map<String,Object>> rulePage(long versionId, String search, int page, int size) {
        String q=(search==null?"":search.trim().toUpperCase(Locale.ROOT));
        return jdbc.queryForList("select r.id,r.name,r.priority,r.commission_percentage,r.status,count(c.id) condition_count from commission_rule r left join rule_condition c on c.rule_id=r.id where r.rule_set_id=? and (?='' or upper(r.name) like ? or cast(r.id as varchar)=?) group by r.id,r.name,r.priority,r.commission_percentage,r.status order by r.id limit ? offset ?",
                versionId,q,"%"+q+"%",q,size,Math.max(0,page)*size);
    }
    public RuleDefinition rule(long ruleId) {
        Map<Long,AttributeDefinition> attrs=attributeMap();
        Map<String,Object> r=jdbc.queryForMap("select id,rule_set_id,name,priority,commission_percentage from commission_rule where id=?",ruleId);
        List<RuleCondition> conditions=jdbc.query("select attribute_id,operator_code,value_1,value_2 from rule_condition where rule_id=? order by id",(rs,n)->{
            long aid=rs.getLong(1); var a=attrs.get(aid); return new RuleCondition(aid,a==null?("ATTR_"+aid):a.code(),ConditionOperator.valueOf(rs.getString(2)),rs.getString(3),rs.getString(4));
        },ruleId);
        return new RuleDefinition(((Number)r.get("ID")).longValue(),((Number)r.get("RULE_SET_ID")).longValue(),(String)r.get("NAME"),((Number)r.get("PRIORITY")).intValue(),(BigDecimal)r.get("COMMISSION_PERCENTAGE"),conditions);
    }
    public long createRule(long versionId, String name, int priority, BigDecimal percentage, List<RuleCondition> conditions) {
        jdbc.update("insert into commission_rule(rule_set_id,name,priority,commission_percentage,status) values(?,?,?,?, 'ACTIVE')",versionId,name,priority,percentage);
        long id=jdbc.queryForObject("select max(id) from commission_rule",Long.class);
        for(var c:conditions) jdbc.update("insert into rule_condition(rule_id,attribute_id,operator_code,value_1,value_2) values(?,?,?,?,?)",id,c.attributeId(),c.operator().name(),c.value1(),c.value2());
        return id;
    }

    public List<RuleDefinition> loadRules(long versionId) {
        Map<Long,AttributeDefinition> attrs=attributeMap();
        List<RuleDefinition> base=jdbc.query("select id,rule_set_id,name,priority,commission_percentage from commission_rule where rule_set_id=? and status='ACTIVE' order by id",
                (rs,n)->new RuleDefinition(rs.getLong(1),rs.getLong(2),rs.getString(3),rs.getInt(4),rs.getBigDecimal(5),new ArrayList<>()),versionId);
        Map<Long,List<RuleCondition>> conds=new HashMap<>();
        jdbc.query("select c.rule_id,c.attribute_id,c.operator_code,c.value_1,c.value_2 from rule_condition c join commission_rule r on r.id=c.rule_id where r.rule_set_id=? order by c.rule_id,c.id",rs->{
            long rid=rs.getLong(1), aid=rs.getLong(2); var a=attrs.get(aid);
            conds.computeIfAbsent(rid,k->new ArrayList<>()).add(new RuleCondition(aid,a==null?("ATTR_"+aid):a.code(),ConditionOperator.valueOf(rs.getString(3)),rs.getString(4),rs.getString(5)));
        },versionId);
        List<RuleDefinition> out=new ArrayList<>(base.size());
        for(var r:base) out.add(new RuleDefinition(r.id(),r.ruleSetId(),r.name(),r.priority(),r.commissionPercentage(),List.copyOf(conds.getOrDefault(r.id(),List.of()))));
        return out;
    }

    public List<Map<String,Object>> executionHistory() { return jdbc.queryForList("select * from execution_run order by id desc limit 100"); }
    public Map<String,Object> execution(long id) { return jdbc.queryForMap("select * from execution_run where id=?",id); }
    public long createExecution(long ruleSetId,int workers,int batch,boolean persist,long sla) {
        jdbc.update("insert into execution_run(rule_set_id,engine_type,status,workers,batch_size,persist_results,sla_seconds,created_at) values(?, 'SPARSE_INDEXED', 'QUEUED', ?, ?, ?, ?, current_timestamp)",ruleSetId,workers,batch,persist,sla);
        return jdbc.queryForObject("select max(id) from execution_run",Long.class);
    }
    public void markRunning(long id,long rules,long attrs,long activeAttrs,long tx,long compileMs,double heap) {
        jdbc.update("update execution_run set status='RUNNING',started_at=current_timestamp,rule_count=?,attribute_count=?,active_attribute_count=?,transaction_count=?,engine_compile_ms=?,heap_after_engine_mb=? where id=?",rules,attrs,activeAttrs,tx,compileMs,heap,id);
    }
    public void progress(long id,long processed,long matched,long noMatch,long ambiguous,long incorrect,double avgCandidates,int maxCandidates,double throughput,long readMs,long engineMs,long writeMs) {
        jdbc.update("update execution_run set processed=?,matched=?,no_match=?,ambiguous=?,incorrect=?,avg_candidates=?,max_candidates=?,throughput=?,db_read_ms=?,engine_ms=?,db_write_ms=? where id=?",processed,matched,noMatch,ambiguous,incorrect,avgCandidates,maxCandidates,throughput,readMs,engineMs,writeMs,id);
    }
    public void finish(long id,long processed,long matched,long noMatch,long ambiguous,long incorrect,double avgCandidates,int maxCandidates,long readMs,long engineMs,long writeMs,long processingMs,long totalMs,double throughput,String message) {
        jdbc.update("update execution_run set status='SUCCESS',processed=?,matched=?,no_match=?,ambiguous=?,incorrect=?,avg_candidates=?,max_candidates=?,db_read_ms=?,engine_ms=?,db_write_ms=?,processing_ms=?,total_ms=?,throughput=?,ended_at=current_timestamp,message=? where id=?",
                processed,matched,noMatch,ambiguous,incorrect,avgCandidates,maxCandidates,readMs,engineMs,writeMs,processingMs,totalMs,throughput,message,id);
    }
    public void fail(long id,String message) { jdbc.update("update execution_run set status='FAILED',ended_at=current_timestamp,message=? where id=?",message,id); }
}
