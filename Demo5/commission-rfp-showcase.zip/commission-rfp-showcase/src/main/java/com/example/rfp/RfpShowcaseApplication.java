package com.example.rfp;

import com.example.rfp.service.DemoDataSeeder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableAsync;

@SpringBootApplication
@EnableAsync
public class RfpShowcaseApplication {
    public static void main(String[] args) { SpringApplication.run(RfpShowcaseApplication.class, args); }

    @Bean
    CommandLineRunner seedRunner(DemoDataSeeder seeder,
                                 @Value("${rfp.demo.seed-profile:none}") String profile,
                                 @Value("${rfp.demo.reset:false}") boolean reset,
                                 @Value("${rfp.demo.exit-after-seed:false}") boolean exit) {
        return args -> {
            if (!"none".equalsIgnoreCase(profile)) {
                seeder.seedProfile(profile, reset);
                if (exit) System.exit(0);
            }
        };
    }
}
