package com.example.rfp.web;

import com.example.rfp.repository.RfpRepository;
import com.example.rfp.service.BatchExecutionService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@Controller
@RequestMapping("/executions")
public class ExecutionController {
    private final RfpRepository repo;private final BatchExecutionService batch;
    public ExecutionController(RfpRepository repo,BatchExecutionService batch){this.repo=repo;this.batch=batch;}
    @GetMapping public String history(Model m){m.addAttribute("runs",repo.executionHistory());m.addAttribute("txCount",repo.transactionCount());return "executions";}
    @PostMapping public String start(@RequestParam(defaultValue="8") int workers,@RequestParam(defaultValue="5000") int batchSize,@RequestParam(defaultValue="true") boolean persistResults){long id=batch.start(Math.max(1,workers),Math.max(100,batchSize),persistResults);return "redirect:/executions/"+id;}
    @GetMapping("/{id}") public String detail(@PathVariable long id,Model m){m.addAttribute("run",repo.execution(id));return "execution-detail";}
    @GetMapping("/{id}/progress") @ResponseBody public Map<String,Object> progress(@PathVariable long id){return repo.execution(id);}
}
