package com.example.rfp.web;

import com.example.rfp.repository.RfpRepository;
import com.example.rfp.service.EngineRegistry;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/versions")
public class VersionController {
    private final RfpRepository repo;private final EngineRegistry engines;
    public VersionController(RfpRepository repo,EngineRegistry engines){this.repo=repo;this.engines=engines;}
    @GetMapping public String list(Model m){m.addAttribute("versions",repo.versions());return "versions";}
    @PostMapping("/clone") public String clone(@RequestParam String versionCode){repo.cloneActiveVersion(versionCode);return "redirect:/versions";}
    @PostMapping("/{id}/activate") public String activate(@PathVariable long id){repo.activateVersion(id);engines.invalidate();return "redirect:/versions";}
}
