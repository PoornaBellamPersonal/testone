package com.example.rfp.web;

import com.example.rfp.model.AttributeDataType;
import com.example.rfp.repository.RfpRepository;
import com.example.rfp.service.EngineRegistry;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/attributes")
public class AttributeController {
    private final RfpRepository repo;private final EngineRegistry engines;
    public AttributeController(RfpRepository repo,EngineRegistry engines){this.repo=repo;this.engines=engines;}
    @GetMapping public String list(Model m){m.addAttribute("attributes",repo.attributes());m.addAttribute("types",AttributeDataType.values());return "attributes";}
    @PostMapping public String create(@RequestParam String code,@RequestParam String displayName,@RequestParam AttributeDataType dataType,@RequestParam(required=false) String sourceKey,@RequestParam(defaultValue="EQ,NE,IN") String operators){repo.createAttribute(code,displayName,dataType,sourceKey,operators);engines.invalidate();return "redirect:/attributes?created";}
}
