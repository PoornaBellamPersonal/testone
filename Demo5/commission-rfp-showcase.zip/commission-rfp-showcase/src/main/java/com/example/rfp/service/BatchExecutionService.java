package com.example.rfp.service;

import com.example.rfp.codec.SparsePayloadCodec;
import com.example.rfp.engine.CommissionEngine;
import com.example.rfp.model.EvaluationResult;
import com.example.rfp.repository.RfpRepository;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import javax.sql.DataSource;
import java.sql.*;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;
import java.util.concurrent.atomic.LongAdder;

@Service
public class BatchExecutionService {
    private final RfpRepository repo; private final EngineRegistry engines; private final DataSource ds; private final long slaSeconds; private final java.util.concurrent.Executor batchExecutor;
    public BatchExecutionService(RfpRepository repo,EngineRegistry engines,DataSource ds,@Qualifier("batchExecutor") java.util.concurrent.Executor batchExecutor,@Value("${rfp.sla-seconds:7200}") long slaSeconds){this.repo=repo;this.engines=engines;this.ds=ds;this.batchExecutor=batchExecutor;this.slaSeconds=slaSeconds;}

    public long start(int workers,int batchSize,boolean persist){Long version=repo.activeVersionId();if(version==null)throw new IllegalStateException("No ACTIVE rule version");long id=repo.createExecution(version,workers,batchSize,persist,slaSeconds);batchExecutor.execute(() -> execute(runIdSafe(id),version,workers,batchSize,persist));return id;}
    private static long runIdSafe(long id){ return id; }

    public void execute(long runId,long versionId,int workers,int batchSize,boolean persist){
        long totalStarted=System.nanoTime();
        try{
            long compileStart=System.nanoTime(); CommissionEngine engine=engines.engine(versionId); long compileMs=(System.nanoTime()-compileStart)/1_000_000;
            long txCount=repo.transactionCount(); long rules=engine.stats().ruleCount(); long attrs=repo.attributeCount(); double heap=usedHeapMb();
            repo.markRunning(runId,rules,attrs,engine.stats().activeAttributes(),txCount,compileMs,heap);
            Totals totals=new Totals(); long processingStart=System.nanoTime(); totals.processingStartedNanos=processingStart;
            ExecutorService pool=Executors.newFixedThreadPool(Math.max(1,workers)); List<Future<?>> futures=new ArrayList<>();
            for(int worker=0;worker<workers;worker++){final int w=worker;futures.add(pool.submit(()->processWorker(runId,w,workers,batchSize,persist,engine,totals)));}
            for(Future<?> f:futures)f.get(); pool.shutdown();
            long processingMs=(System.nanoTime()-processingStart)/1_000_000; long totalMs=(System.nanoTime()-totalStarted)/1_000_000;
            long processed=totals.processed.sum(); double avg=processed==0?0:(double)totals.candidates.sum()/processed; double tps=processingMs==0?0:processed/(processingMs/1000.0);
            repo.finish(runId,processed,totals.matched.sum(),totals.noMatch.sum(),totals.ambiguous.sum(),totals.incorrect.sum(),avg,totals.maxCandidates.get(),totals.readMs.sum(),totals.engineNanos.sum()/1_000_000,totals.writeMs.sum(),processingMs,totalMs,tps,"Completed successfully");
        }catch(Exception ex){repo.fail(runId,ex.getClass().getSimpleName()+": "+ex.getMessage());}
    }

    private void processWorker(long runId,int worker,int workers,int batchSize,boolean persist,CommissionEngine engine,Totals totals){
        for(int partition=worker;partition<32;partition+=workers){long lastId=0;while(true){List<Tx> batch;long rs=System.nanoTime();batch=readBatch(partition,lastId,batchSize);totals.readMs.add((System.nanoTime()-rs)/1_000_000);if(batch.isEmpty())break;lastId=batch.getLast().id;List<ResultRow> rows=new ArrayList<>(batch.size());
                for(Tx tx:batch){long es=System.nanoTime();EvaluationResult r=engine.evaluate(SparsePayloadCodec.decode(tx.payload),false);totals.engineNanos.add(System.nanoTime()-es);totals.processed.increment();totals.candidates.add(r.candidateCount());totals.maxCandidates.accumulateAndGet(r.candidateCount(), Math::max);if(r.matchedRuleId()==null)totals.noMatch.increment();else totals.matched.increment();if(r.topRankCount()>1)totals.ambiguous.increment();boolean incorrect=!same(tx.expected,r.matchedRuleId());if(incorrect)totals.incorrect.increment();if(persist)rows.add(new ResultRow(tx.id,tx.expected,r,incorrect));}
                if(persist){long ws=System.nanoTime();writeResults(runId,rows);totals.writeMs.add((System.nanoTime()-ws)/1_000_000);} long p=totals.processed.sum();if(p%50_000<batch.size()){double avg=(double)totals.candidates.sum()/Math.max(1,p);double liveTps=p/Math.max(0.001,(System.nanoTime()-totals.processingStartedNanos)/1_000_000_000.0);repo.progress(runId,p,totals.matched.sum(),totals.noMatch.sum(),totals.ambiguous.sum(),totals.incorrect.sum(),avg,totals.maxCandidates.get(),liveTps,totals.readMs.sum(),totals.engineNanos.sum()/1_000_000,totals.writeMs.sum());}
            }}
    }
    private List<Tx> readBatch(int partition,long lastId,int limit){try(Connection c=ds.getConnection();PreparedStatement ps=c.prepareStatement("select id,attributes_payload,expected_rule_id from transaction_record where partition_id=? and id>? order by id limit ?")){ps.setInt(1,partition);ps.setLong(2,lastId);ps.setInt(3,limit);try(ResultSet rs=ps.executeQuery()){List<Tx> out=new ArrayList<>(limit);while(rs.next()){Long exp=(Long)rs.getObject(3);out.add(new Tx(rs.getLong(1),rs.getString(2),exp));}return out;}}catch(SQLException e){throw new IllegalStateException(e);}}
    private void writeResults(long runId,List<ResultRow> rows){if(rows.isEmpty())return;try(Connection c=ds.getConnection();PreparedStatement ps=c.prepareStatement("insert into execution_result(run_id,transaction_id,expected_rule_id,matched_rule_id,commission_percentage,candidate_count,matched_count,top_rank_count,evaluation_nanos,result_status) values(?,?,?,?,?,?,?,?,?,?)")){c.setAutoCommit(false);for(ResultRow x:rows){EvaluationResult r=x.result;ps.setLong(1,runId);ps.setLong(2,x.txId);if(x.expected==null)ps.setNull(3,Types.BIGINT);else ps.setLong(3,x.expected);if(r.matchedRuleId()==null)ps.setNull(4,Types.BIGINT);else ps.setLong(4,r.matchedRuleId());ps.setBigDecimal(5,r.commissionPercentage());ps.setInt(6,r.candidateCount());ps.setInt(7,r.matchedCount());ps.setInt(8,r.topRankCount());ps.setLong(9,r.evaluationNanos());ps.setString(10,x.incorrect?"INCORRECT":r.status());ps.addBatch();}ps.executeBatch();c.commit();}catch(SQLException e){throw new IllegalStateException(e);}}
    private static boolean same(Long a,Long b){return a==null?b==null:a.equals(b);}
    private static double usedHeapMb(){Runtime r=Runtime.getRuntime();return (r.totalMemory()-r.freeMemory())/1024d/1024d;}
    private record Tx(long id,String payload,Long expected){}
    private record ResultRow(long txId,Long expected,EvaluationResult result,boolean incorrect){}
    private static class Totals{final LongAdder processed=new LongAdder(),matched=new LongAdder(),noMatch=new LongAdder(),ambiguous=new LongAdder(),incorrect=new LongAdder(),candidates=new LongAdder(),readMs=new LongAdder(),engineNanos=new LongAdder(),writeMs=new LongAdder();final java.util.concurrent.atomic.AtomicInteger maxCandidates=new java.util.concurrent.atomic.AtomicInteger();volatile long processingStartedNanos;}
}
