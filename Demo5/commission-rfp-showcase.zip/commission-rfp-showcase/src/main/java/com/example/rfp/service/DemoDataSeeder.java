package com.example.rfp.service;

import com.example.rfp.codec.SparsePayloadCodec;
import com.example.rfp.model.AttributeDataType;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import javax.sql.DataSource;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.*;

@Service
public class DemoDataSeeder {
    private final JdbcTemplate jdbc;
    private final DataSource dataSource;
    private final EngineRegistry engines;
    public DemoDataSeeder(JdbcTemplate jdbc, DataSource dataSource, EngineRegistry engines) { this.jdbc=jdbc; this.dataSource=dataSource; this.engines=engines; }

    public void seedProfile(String profile, boolean reset) throws Exception {
        int rules, tx;
        switch (profile.toLowerCase(Locale.ROOT)) {
            case "quick" -> { rules=5_000; tx=50_000; }
            case "medium" -> { rules=50_000; tx=200_000; }
            case "target" -> { rules=200_000; tx=2_000_000; }
            default -> throw new IllegalArgumentException("Unknown seed profile: "+profile);
        }
        if (reset) reset();
        if (jdbc.queryForObject("select count(*) from commission_rule",Long.class)>0) return;
        seedAttributes(); seedVersion(); seedRules(rules); seedTransactions(rules,tx); engines.invalidate();
    }

    public void reset() {
        jdbc.execute("delete from execution_result"); jdbc.execute("delete from execution_run"); jdbc.execute("delete from transaction_record");
        jdbc.execute("delete from rule_condition"); jdbc.execute("delete from commission_rule"); jdbc.execute("delete from rule_set_version"); jdbc.execute("delete from attribute_definition");
        engines.invalidate();
    }

    private void seedAttributes() {
        String[] names={"CARRIER","PRODUCT","STATE","PROGRAM_CODE","PREMIUM","CHANNEL","AGENT_TYPE","PRODUCER_TIER","REGISTRATION_TYPE","EFFECTIVE_MONTH"};
        for(int id=1;id<=220;id++){
            String code=id<=names.length?names[id-1]:String.format("ATTR_%03d",id);
            AttributeDataType type;
            if(id==5) type=AttributeDataType.DECIMAL; else if(id==10) type=AttributeDataType.INTEGER;
            else if(id>10) type=switch((id-11)%4){case 1->AttributeDataType.DECIMAL;case 2->AttributeDataType.INTEGER;case 3->AttributeDataType.BOOLEAN;default->AttributeDataType.STRING;};
            else type=AttributeDataType.STRING;
            String ops=type==AttributeDataType.STRING?"EQ,NE,IN,NOT_IN,IS_NULL,IS_NOT_NULL":"EQ,NE,GT,GE,LT,LE,BETWEEN,IS_NULL,IS_NOT_NULL";
            jdbc.update("insert into attribute_definition(id,code,display_name,data_type,source_key,allowed_operators,active) values(?,?,?,?,?,?,true)",id,code,pretty(code),type.name(),code,ops);
        }
    }
    private void seedVersion(){ jdbc.update("insert into rule_set_version(id,version_code,status,description,activated_at) values(1,'2026.08-RFP','ACTIVE','RFP showcase baseline',current_timestamp)"); }

    private void seedRules(int requestedRows) throws Exception {
        int groups=Math.max(1,requestedRows/5); long conditionId=1;
        try(Connection c=dataSource.getConnection(); PreparedStatement r=c.prepareStatement("insert into commission_rule(id,rule_set_id,name,priority,commission_percentage,status) values(?,1,?,?,?,'ACTIVE')"); PreparedStatement rc=c.prepareStatement("insert into rule_condition(id,rule_id,attribute_id,operator_code,value_1,value_2) values(?,?,?,?,?,?)")){
            c.setAutoCommit(false); int pending=0;
            for(int g=0;g<groups;g++){
                List<Cond> exact=baseConditions(g);
                for(int v=0;v<5;v++){
                    long ruleId=(long)g*5+v+1; int priority; List<Cond> cs; String type;
                    if(v==0){priority=100;cs=exact;type="EXACT";}
                    else if(v==1){priority=80;cs=drop(exact,2,5);type="GEO_WILDCARD";}
                    else if(v==2){priority=70;cs=drop(exact,6,7,8);type="SPARSE_WILDCARD";}
                    else if(v==3){priority=60;cs=List.of(exact.get(0),exact.get(3),new Cond(5,"BETWEEN","0","9999999"));type="BROAD_RANGE";}
                    else if(g%10==0){priority=120;cs=List.of(exact.get(0),exact.get(1),exact.get(3));type="PRIORITY_OVERRIDE";}
                    else if(g%20==1){priority=100;cs=exact;type="EXACT_TIE";}
                    else {priority=50;cs=List.of(exact.get(3));type="FALLBACK";}
                    BigDecimal pct=BigDecimal.valueOf(100+(g%1500)).movePointLeft(2);
                    r.setLong(1,ruleId);r.setString(2,type+" / Program "+g);r.setInt(3,priority);r.setBigDecimal(4,pct);r.addBatch();
                    for(Cond x:cs){rc.setLong(1,conditionId++);rc.setLong(2,ruleId);rc.setLong(3,x.attr);rc.setString(4,x.op);rc.setString(5,x.v1);rc.setString(6,x.v2);rc.addBatch();}
                    if(++pending%2000==0){r.executeBatch();rc.executeBatch();c.commit();}
                }
            }
            r.executeBatch();rc.executeBatch();c.commit();
        }
    }

    private void seedTransactions(int ruleRows,int txCount) throws Exception {
        int groups=Math.max(1,ruleRows/5);
        try(Connection c=dataSource.getConnection(); PreparedStatement ps=c.prepareStatement("insert into transaction_record(id,partition_id,attributes_payload,expected_rule_id) values(?,?,?,?)")){
            c.setAutoCommit(false);
            for(int i=1;i<=txCount;i++){
                int g=(int)(((long)i*37)%groups); boolean noMatch=i%20==0; Map<Long,String> values=transactionValues(g,noMatch);
                Long expected=noMatch?null:((g%10==0)?((long)g*5+5):((long)g*5+1));
                ps.setLong(1,i);ps.setInt(2,g%32);ps.setString(3,SparsePayloadCodec.encode(values));if(expected==null)ps.setNull(4,java.sql.Types.BIGINT);else ps.setLong(4,expected);ps.addBatch();
                if(i%10_000==0){ps.executeBatch();c.commit();}
            }
            ps.executeBatch();c.commit();
        }
    }

    private List<Cond> baseConditions(int g){
        int dynString=findDynamic(g,AttributeDataType.STRING), dynNumber=findDynamic(g+17,AttributeDataType.DECIMAL);
        return List.of(new Cond(1,"EQ","CAR"+(g%64),null),new Cond(2,"EQ","PROD"+((g*7)%128),null),new Cond(3,"EQ","ST"+((g*11)%50),null),
                new Cond(4,"EQ",String.format("PRG%05d",g),null),new Cond(5,"BETWEEN",String.valueOf((g%20)*50_000),String.valueOf((g%20)*50_000+49_999)),
                new Cond(6,"EQ","CH"+(g%8),null),new Cond(7,"EQ","AG"+(g%8),null),new Cond(8,"EQ","TIER"+(g%6),null),
                new Cond(dynString,"EQ","V"+(g%37),null),new Cond(dynNumber,"BETWEEN",String.valueOf(g%1000),String.valueOf(g%1000+100)));
    }
    private Map<Long,String> transactionValues(int g,boolean noMatch){Map<Long,String> m=new LinkedHashMap<>();for(Cond c:baseConditions(g)){String val="BETWEEN".equals(c.op)?mid(c.v1,c.v2):c.v1;m.put(c.attr,val);}if(noMatch)m.put(4L,"NO_MATCH");return m;}
    private static String mid(String a,String b){return new BigDecimal(a).add(new BigDecimal(b)).divide(BigDecimal.valueOf(2)).stripTrailingZeros().toPlainString();}
    private int findDynamic(int seed,AttributeDataType type){for(int k=0;k<210;k++){int id=11+Math.floorMod(seed*13+k,210);AttributeDataType t=switch((id-11)%4){case 1->AttributeDataType.DECIMAL;case 2->AttributeDataType.INTEGER;case 3->AttributeDataType.BOOLEAN;default->AttributeDataType.STRING;};if(t==type)return id;}return 11;}
    private static List<Cond> drop(List<Cond> src,int... positions){Set<Integer>s=new HashSet<>();for(int p:positions)s.add(p);List<Cond>o=new ArrayList<>();for(int i=0;i<src.size();i++)if(!s.contains(i))o.add(src.get(i));return List.copyOf(o);}
    private static String pretty(String code){String[]p=code.toLowerCase(Locale.ROOT).split("_");StringBuilder b=new StringBuilder();for(String x:p){if(!x.isEmpty())b.append(Character.toUpperCase(x.charAt(0))).append(x.substring(1)).append(' ');}return b.toString().trim();}
    private record Cond(long attr,String op,String v1,String v2){}
}
