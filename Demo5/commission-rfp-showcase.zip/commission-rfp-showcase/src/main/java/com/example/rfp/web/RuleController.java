package com.example.rfp.web;

import com.example.rfp.model.*;
import com.example.rfp.repository.RfpRepository;
import com.example.rfp.service.EngineRegistry;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;
import org.springframework.web.multipart.MultipartFile;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.io.OutputStreamWriter;
import java.io.BufferedWriter;
import java.util.*;
import java.io.*;

@Controller
@RequestMapping("/rules")
public class RuleController {
    private final RfpRepository repo;private final EngineRegistry engines;
    public RuleController(RfpRepository repo,EngineRegistry engines){this.repo=repo;this.engines=engines;}
    @GetMapping public String list(@RequestParam(defaultValue="0") int page,@RequestParam(defaultValue="") String search,Model m){Long v=repo.activeVersionId();m.addAttribute("version",repo.activeVersionCode());m.addAttribute("rules",v==null?List.of():repo.rulePage(v,search,page,50));m.addAttribute("page",page);m.addAttribute("search",search);return "rules";}
    @GetMapping("/{id}") public String detail(@PathVariable long id,Model m){m.addAttribute("rule",repo.rule(id));return "rule-detail";}
    @GetMapping("/new") public String createForm(Model m){m.addAttribute("attributes",repo.attributes());m.addAttribute("operators",ConditionOperator.values());return "rule-new";}
    @PostMapping public String create(@RequestParam String name,@RequestParam int priority,@RequestParam BigDecimal commissionPercentage,@RequestParam(required=false) List<Long> attributeId,@RequestParam(required=false) List<String> operator,@RequestParam(required=false) List<String> value1,@RequestParam(required=false) List<String> value2){Long v=repo.activeVersionId();if(v==null)throw new IllegalStateException("No ACTIVE rule version");Map<Long,AttributeDefinition> defs=repo.attributeMap();List<RuleCondition> cs=new ArrayList<>();if(attributeId!=null){for(int i=0;i<attributeId.size();i++){Long aid=attributeId.get(i);if(aid==null)continue;String op=i<operator.size()?operator.get(i):"EQ";String v1=i<value1.size()?value1.get(i):"";String v2=i<value2.size()?value2.get(i):"";ConditionOperator parsed=ConditionOperator.valueOf(op);if((v1==null||v1.isBlank()) && parsed!=ConditionOperator.IS_NULL && parsed!=ConditionOperator.IS_NOT_NULL) continue;var d=defs.get(aid);cs.add(new RuleCondition(aid,d==null?("ATTR_"+aid):d.code(),parsed,v1,v2));}}long id=repo.createRule(v,name,priority,commissionPercentage,cs);engines.invalidate();return "redirect:/rules/"+id;}

    @GetMapping("/import") public String importForm(){ return "rule-import"; }
    @PostMapping("/import") public String importCsv(@RequestParam MultipartFile file) throws IOException {
        Long version=repo.activeVersionId(); if(version==null) throw new IllegalStateException("No ACTIVE rule version");
        Map<String,AttributeDefinition> defs=repo.attributeMapByCode();
        record Pending(String name,int priority,BigDecimal pct,List<RuleCondition> conditions){}
        Map<String,Pending> pending=new LinkedHashMap<>();
        try(BufferedReader br=new BufferedReader(new InputStreamReader(file.getInputStream(),StandardCharsets.UTF_8))){
            String line; boolean first=true;
            while((line=br.readLine())!=null){ if(line.isBlank()) continue; if(first && line.toLowerCase(Locale.ROOT).startsWith("rule_name")){first=false;continue;} first=false;
                String[] x=line.split(",",-1); if(x.length<7) continue; String name=x[0].trim(); if(name.isBlank()) continue; int pri=Integer.parseInt(x[1].trim()); BigDecimal pct=new BigDecimal(x[2].trim());
                AttributeDefinition d=defs.get(x[3].trim().toUpperCase(Locale.ROOT)); if(d==null) throw new IllegalArgumentException("Unknown attribute: "+x[3]);
                RuleCondition c=new RuleCondition(d.id(),d.code(),ConditionOperator.valueOf(x[4].trim().toUpperCase(Locale.ROOT)),x[5].trim(),x[6].trim());
                Pending old=pending.get(name); if(old==null) pending.put(name,new Pending(name,pri,pct,new ArrayList<>(List.of(c)))); else old.conditions().add(c);
            }
        }
        for(Pending r:pending.values()) repo.createRule(version,r.name(),r.priority(),r.pct(),r.conditions());
        engines.invalidate(); return "redirect:/rules?imported="+pending.size();
    }
    @GetMapping(value="/export.csv",produces="text/csv") @ResponseBody public StreamingResponseBody export(){Long v=repo.activeVersionId();return out->{var writer=new BufferedWriter(new OutputStreamWriter(out, StandardCharsets.UTF_8));writer.write("rule_id,name,priority,commission_percentage,conditions\\n");if(v!=null)for(var r:repo.loadRules(v)){String cond=r.conditions().stream().map(c->c.attributeCode()+" "+c.operator()+" "+safe(c.value1())+(c.value2()==null?"":".."+safe(c.value2()))).reduce((a,b)->a+"; "+b).orElse("");writer.write(r.id()+",\""+safe(r.name())+"\","+r.priority()+","+r.commissionPercentage()+",\""+safe(cond)+"\"\\n");}writer.flush();};}
    private static String safe(String s){return s==null?"":s.replace("\"","\"\"").replace("\\n"," ");}
}
