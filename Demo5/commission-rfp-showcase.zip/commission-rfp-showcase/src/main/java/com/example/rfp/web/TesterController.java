package com.example.rfp.web;

import com.example.rfp.service.EvaluationService;
import com.example.rfp.repository.RfpRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@Controller
@RequestMapping("/tester")
public class TesterController {
    private final RfpRepository repo;private final EvaluationService eval;
    public TesterController(RfpRepository repo,EvaluationService eval){this.repo=repo;this.eval=eval;}
    @GetMapping public String page(Model m){m.addAttribute("attributes",repo.attributes());return "tester";}
    @PostMapping public String test(@RequestParam List<Long> attributeId,@RequestParam List<String> value,Model m){m.addAttribute("attributes",repo.attributes());m.addAttribute("result",eval.evaluate(attributeId,value));m.addAttribute("selectedIds",attributeId);m.addAttribute("selectedValues",value);return "tester";}
}
