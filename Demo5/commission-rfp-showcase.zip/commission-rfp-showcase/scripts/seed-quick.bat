@echo off
setlocal
pushd "%~dp0.."
set MAVEN_OPTS=-Xms512m -Xmx4g -XX:+UseG1GC
mvn -q spring-boot:run -Dspring-boot.run.arguments="--spring.main.web-application-type=none --rfp.demo.seed-profile=quick --rfp.demo.reset=true --rfp.demo.exit-after-seed=true"
popd
endlocal
