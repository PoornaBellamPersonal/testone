@echo off
setlocal
pushd "%~dp0.."
set MAVEN_OPTS=-Xms512m -Xmx4g -XX:+UseG1GC
mvn spring-boot:run
popd
endlocal
