package com.example.rfp.engine;

import com.example.rfp.model.*;
import java.util.*;

/**
 * Metadata-driven sparse rule matcher.
 *
 * Equality/IN conditions are compiled into compact posting lists. This avoids
 * allocating one full BitSet per distinct value, which is important for
 * high-cardinality attributes such as compensation-program identifiers.
 */
public final class SparseIndexedCommissionEngine implements CommissionEngine {
    private final List<RuleDefinition> rules;
    private final BitSet allRules;
    private final List<EqualityIndex> indexes;
    private final EngineStats stats;

    public SparseIndexedCommissionEngine(List<RuleDefinition> inputRules, int maxIndexedAttributes) {
        long started = System.nanoTime();
        this.rules = List.copyOf(inputRules);
        this.allRules = new BitSet(rules.size());
        allRules.set(0, rules.size());
        this.indexes = buildIndexes(maxIndexedAttributes);
        long conditionCount = rules.stream().mapToLong(r -> r.conditions().size()).sum();
        int maxConditions = rules.stream().mapToInt(RuleDefinition::specificity).max().orElse(0);
        int activeAttrs = (int) rules.stream().flatMap(r -> r.conditions().stream()).map(RuleCondition::attributeId).distinct().count();
        long compileMs = (System.nanoTime() - started) / 1_000_000;
        this.stats = new EngineStats(rules.size(), conditionCount, activeAttrs, indexes.size(),
                rules.isEmpty() ? 0 : (double) conditionCount / rules.size(), maxConditions, compileMs);
    }

    @Override
    public EvaluationResult evaluate(AttributeBag tx, boolean explain) {
        long started = System.nanoTime();
        BitSet candidates = (BitSet) allRules.clone();

        for (EqualityIndex index : indexes) {
            String actual = tx.get(index.attributeId);
            if (actual == null) continue;

            BitSet allowed = (BitSet) index.unrestricted.clone();
            int[] exact = index.byValue.get(ConditionOperator.normalize(actual));
            if (exact != null) for (int ruleIndex : exact) allowed.set(ruleIndex);
            candidates.and(allowed);
            if (candidates.isEmpty()) break;
        }

        int candidateCount = candidates.cardinality();
        RuleDefinition winner = null;
        int matchedCount = 0;
        int topRankCount = 0;
        for (int i = candidates.nextSetBit(0); i >= 0; i = candidates.nextSetBit(i + 1)) {
            RuleDefinition rule = rules.get(i);
            if (!matchesAll(rule, tx)) continue;
            matchedCount++;
            if (winner == null) {
                winner = rule;
                topRankCount = 1;
            } else {
                int cmp = compare(rule, winner);
                if (cmp > 0) {
                    winner = rule;
                    topRankCount = 1;
                } else if (sameRank(rule, winner)) {
                    topRankCount++;
                    if (rule.id() < winner.id()) winner = rule;
                }
            }
        }

        long nanos = System.nanoTime() - started;
        if (winner == null) return EvaluationResult.noMatch(candidateCount, nanos);
        List<ConditionTrace> traces = explain ? traces(winner, tx) : List.of();
        return new EvaluationResult(winner.id(), winner.name(), winner.commissionPercentage(), candidateCount,
                matchedCount, topRankCount, winner.priority(), winner.specificity(), nanos,
                topRankCount > 1 ? "MATCHED_AMBIGUOUS" : "MATCHED", traces);
    }

    @Override
    public EngineStats stats() { return stats; }

    private boolean matchesAll(RuleDefinition rule, AttributeBag tx) {
        for (RuleCondition c : rule.conditions()) if (!c.matches(tx)) return false;
        return true;
    }

    private List<ConditionTrace> traces(RuleDefinition rule, AttributeBag tx) {
        List<ConditionTrace> traces = new ArrayList<>();
        for (RuleCondition c : rule.conditions()) {
            String actual = tx.get(c.attributeId());
            String expected = c.value2() == null || c.value2().isBlank() ? c.value1() : c.value1() + " .. " + c.value2();
            traces.add(new ConditionTrace(c.attributeCode(), c.operator().name(), expected, actual, c.matches(tx)));
        }
        return traces;
    }

    private static int compare(RuleDefinition a, RuleDefinition b) {
        int p = Integer.compare(a.priority(), b.priority());
        if (p != 0) return p;
        int s = Integer.compare(a.specificity(), b.specificity());
        if (s != 0) return s;
        return Long.compare(b.id(), a.id()); // lower rule id wins
    }

    private static boolean sameRank(RuleDefinition a, RuleDefinition b) {
        return a.priority() == b.priority() && a.specificity() == b.specificity();
    }

    private List<EqualityIndex> buildIndexes(int maxIndexedAttributes) {
        if (rules.isEmpty()) return List.of();
        Map<Long, Integer> frequency = new HashMap<>();
        Map<Long, Set<String>> distinct = new HashMap<>();

        for (RuleDefinition r : rules) {
            for (RuleCondition c : r.conditions()) {
                if (!c.operator().isEqualityIndexable()) continue;
                frequency.merge(c.attributeId(), 1, Integer::sum);
                Set<String> set = distinct.computeIfAbsent(c.attributeId(), k -> new HashSet<>());
                if (c.operator() == ConditionOperator.EQ) set.add(ConditionOperator.normalize(c.value1()));
                else for (String v : ConditionOperator.split(c.value1())) set.add(ConditionOperator.normalize(v));
            }
        }

        // Prefer indexes expected to leave the smallest candidate population.
        // expectedAllowed = unrestricted rules + average posting-list size.
        List<Long> selected = new ArrayList<>(frequency.keySet());
        selected.sort(Comparator.comparingDouble(id -> {
            int restricted = frequency.getOrDefault(id, 0);
            int cardinality = Math.max(1, distinct.getOrDefault(id, Set.of()).size());
            return (rules.size() - restricted) + ((double) restricted / cardinality);
        }));
        if (selected.size() > Math.max(1, maxIndexedAttributes)) selected = selected.subList(0, Math.max(1, maxIndexedAttributes));

        List<EqualityIndex> out = new ArrayList<>(selected.size());
        for (Long attr : selected) {
            BitSet unrestricted = (BitSet) allRules.clone();
            Map<String, IntBag> builders = new HashMap<>();

            for (int i = 0; i < rules.size(); i++) {
                RuleCondition indexedCondition = null;
                for (RuleCondition c : rules.get(i).conditions()) {
                    if (c.attributeId() == attr && c.operator().isEqualityIndexable()) {
                        indexedCondition = c;
                        break;
                    }
                }
                if (indexedCondition == null) continue;
                unrestricted.clear(i);
                if (indexedCondition.operator() == ConditionOperator.EQ) {
                    add(builders, indexedCondition.value1(), i);
                } else {
                    for (String value : ConditionOperator.split(indexedCondition.value1())) add(builders, value, i);
                }
            }

            Map<String, int[]> postings = new HashMap<>(Math.max(16, builders.size() * 2));
            builders.forEach((value, bag) -> postings.put(value, bag.toArray()));
            out.add(new EqualityIndex(attr, unrestricted, Collections.unmodifiableMap(postings)));
        }
        return List.copyOf(out);
    }

    private static void add(Map<String, IntBag> map, String value, int ruleIndex) {
        map.computeIfAbsent(ConditionOperator.normalize(value), k -> new IntBag()).add(ruleIndex);
    }

    private record EqualityIndex(long attributeId, BitSet unrestricted, Map<String, int[]> byValue) {}

    private static final class IntBag {
        private int[] values = new int[8];
        private int size;
        void add(int value) {
            if (size == values.length) values = Arrays.copyOf(values, values.length * 2);
            values[size++] = value;
        }
        int[] toArray() { return Arrays.copyOf(values, size); }
    }
}
