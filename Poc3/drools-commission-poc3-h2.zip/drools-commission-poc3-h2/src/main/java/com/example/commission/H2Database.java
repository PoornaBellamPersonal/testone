package com.example.commission;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

public final class H2Database {
    private static final String USER = "sa";
    private static final String PASSWORD = "";

    private final H2BenchmarkConfig config;

    public H2Database(H2BenchmarkConfig config) {
        this.config = config;
    }

    public Connection connect() throws SQLException {
        return DriverManager.getConnection(config.jdbcUrl(), USER, PASSWORD);
    }

    public void initialize(boolean reset) throws SQLException, IOException {
        Path parent = config.databasePath().toAbsolutePath().normalize().getParent();
        if (parent != null) Files.createDirectories(parent);
        try (Connection connection = connect(); Statement statement = connection.createStatement()) {
            if (reset) statement.execute("DROP ALL OBJECTS");
            statement.execute(CommissionSql.CREATE_RULE_TABLE);
            statement.execute(CommissionSql.CREATE_TRANSACTION_TABLE);
            statement.execute(CommissionSql.CREATE_RESULT_TABLE);
            statement.execute("CREATE INDEX IF NOT EXISTS IDX_RULE_PARTITION ON COMMISSION_RULE(PARTITION_ID, RULE_ID)");
            statement.execute("CREATE INDEX IF NOT EXISTS IDX_TX_PARTITION ON COMMISSION_TRANSACTION(PARTITION_ID, TRANSACTION_ID)");
            statement.execute("CREATE INDEX IF NOT EXISTS IDX_RESULT_STATUS ON COMMISSION_RESULT(RESULT_STATUS)");
        }
    }

    public long count(String table) throws SQLException {
        if (!List.of("COMMISSION_RULE", "COMMISSION_TRANSACTION", "COMMISSION_RESULT").contains(table)) {
            throw new IllegalArgumentException("Unsupported table: " + table);
        }
        try (Connection connection = connect(); Statement statement = connection.createStatement();
             ResultSet rs = statement.executeQuery("SELECT COUNT(*) FROM " + table)) {
            rs.next();
            return rs.getLong(1);
        }
    }

    public void clearResults() throws SQLException {
        try (Connection connection = connect(); Statement statement = connection.createStatement()) {
            statement.execute("TRUNCATE TABLE COMMISSION_RESULT");
        }
    }

    public void compact() throws SQLException {
        try (Connection connection = connect(); Statement statement = connection.createStatement()) {
            statement.execute("SHUTDOWN COMPACT");
        }
    }

    public void inspect() throws SQLException {
        System.out.println("Database URL : " + config.jdbcUrl());
        System.out.printf("Rules        : %,d%n", count("COMMISSION_RULE"));
        System.out.printf("Transactions : %,d%n", count("COMMISSION_TRANSACTION"));
        System.out.printf("Results      : %,d%n%n", count("COMMISSION_RESULT"));

        try (Connection connection = connect(); Statement statement = connection.createStatement()) {
            printQuery(statement, "Sample rules", """
                    SELECT RULE_ID, PARTITION_ID, CARRIER, PRODUCT, STATE_CODE, CHANNEL_CODE,
                           PREMIUM_MIN, PREMIUM_MAX, COMMISSION_PERCENTAGE
                    FROM COMMISSION_RULE ORDER BY RULE_ID FETCH FIRST 10 ROWS ONLY
                    """);
            printQuery(statement, "Sample transactions", """
                    SELECT TRANSACTION_ID, PARTITION_ID, EXPECTED_RULE_ID, CARRIER, PRODUCT,
                           STATE_CODE, PREMIUM
                    FROM COMMISSION_TRANSACTION ORDER BY TRANSACTION_ID FETCH FIRST 10 ROWS ONLY
                    """);
            printQuery(statement, "Sample results", """
                    SELECT TRANSACTION_ID, EXPECTED_RULE_ID, MATCHED_RULE_ID,
                           COMMISSION_PERCENTAGE, RESULT_STATUS
                    FROM COMMISSION_RESULT ORDER BY TRANSACTION_ID FETCH FIRST 10 ROWS ONLY
                    """);
        }
        System.out.printf("Database file: %s (%,.2f MB)%n", config.databaseFile(), databaseSizeMb());
    }

    private static void printQuery(Statement statement, String title, String sql) throws SQLException {
        System.out.println("--- " + title + " ---");
        try (ResultSet rs = statement.executeQuery(sql)) {
            int columns = rs.getMetaData().getColumnCount();
            while (rs.next()) {
                StringBuilder row = new StringBuilder();
                for (int i = 1; i <= columns; i++) {
                    if (i > 1) row.append(" | ");
                    row.append(rs.getMetaData().getColumnLabel(i)).append('=').append(rs.getObject(i));
                }
                System.out.println(row);
            }
        }
        System.out.println();
    }

    public double databaseSizeMb() {
        try {
            return Files.exists(config.databaseFile()) ? Files.size(config.databaseFile()) / 1024.0 / 1024.0 : 0.0;
        } catch (IOException e) {
            return -1.0;
        }
    }

    public void deleteFiles() throws IOException {
        Path base = config.databasePath().toAbsolutePath().normalize();
        for (String suffix : List.of(".mv.db", ".trace.db", ".lock.db", ".temp.db")) {
            Files.deleteIfExists(Path.of(base + suffix));
        }
    }
}
