package com.example.commission;

public final class TransactionFactory {
    private TransactionFactory() {}

    public static CommissionTransaction matching(long transactionId, int ruleId) {
        RuleSpec r = RuleSpec.fromRuleId(ruleId);
        return create(transactionId, ruleId, r, r.paymentMode());
    }

    public static CommissionTransaction nonMatching(long transactionId, int sourceRuleId) {
        RuleSpec r = RuleSpec.fromRuleId(sourceRuleId);
        return create(transactionId, -1, r, "NO_MATCH");
    }

    private static CommissionTransaction create(long txId, int expectedRuleId, RuleSpec r, String paymentMode) {
        return new CommissionTransaction(
                txId,
                expectedRuleId,
                r.carrier(), r.product(), r.state(), r.channel(), r.agentType(), r.registrationType(),
                r.commissionType(), r.transactionType(), r.policyType(), r.currency(), r.planCode(),
                r.producerLevel(), r.customerSegment(), paymentMode,
                r.renewal(), r.replacement(), r.specialProgram(), r.internalBusiness(),
                midpoint(r.premiumMin(), r.premiumMax()),
                midpoint(r.faceAmountMin(), r.faceAmountMax()),
                midpoint(r.productionAmountMin(), r.productionAmountMax()),
                (r.policyDurationMin() + r.policyDurationMax()) / 2,
                (r.issueAgeMin() + r.issueAgeMax()) / 2,
                (r.effectiveEpochDayMin() + r.effectiveEpochDayMax()) / 2
        );
    }

    private static double midpoint(double min, double max) {
        return min + ((max - min) / 2.0);
    }
}
