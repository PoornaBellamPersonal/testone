package com.example.commission;

public record DbBenchmarkResult(
        long transactions,
        long matched,
        long noMatch,
        long incorrect,
        long elapsedNanos,
        long readNanos,
        long engineNanos,
        long writeNanos,
        double transactionsPerSecond,
        double p50BatchMillis,
        double p95BatchMillis,
        double p99BatchMillis,
        MemorySnapshot afterRun
) {}
