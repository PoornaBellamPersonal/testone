package com.example.commission;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public final class JdbcMappers {
    private JdbcMappers() {}

    public static void bindRule(PreparedStatement ps, RuleSpec r, int partition) throws SQLException {
        int i = 1;
        ps.setInt(i++, r.ruleId());
        ps.setInt(i++, partition);
        ps.setString(i++, r.carrier());
        ps.setString(i++, r.product());
        ps.setString(i++, r.state());
        ps.setString(i++, r.channel());
        ps.setString(i++, r.agentType());
        ps.setString(i++, r.registrationType());
        ps.setString(i++, r.commissionType());
        ps.setString(i++, r.transactionType());
        ps.setString(i++, r.policyType());
        ps.setString(i++, r.currency());
        ps.setString(i++, r.planCode());
        ps.setString(i++, r.producerLevel());
        ps.setString(i++, r.customerSegment());
        ps.setString(i++, r.paymentMode());
        ps.setBoolean(i++, r.renewal());
        ps.setBoolean(i++, r.replacement());
        ps.setBoolean(i++, r.specialProgram());
        ps.setBoolean(i++, r.internalBusiness());
        ps.setDouble(i++, r.premiumMin());
        ps.setDouble(i++, r.premiumMax());
        ps.setDouble(i++, r.faceAmountMin());
        ps.setDouble(i++, r.faceAmountMax());
        ps.setDouble(i++, r.productionAmountMin());
        ps.setDouble(i++, r.productionAmountMax());
        ps.setInt(i++, r.policyDurationMin());
        ps.setInt(i++, r.policyDurationMax());
        ps.setInt(i++, r.issueAgeMin());
        ps.setInt(i++, r.issueAgeMax());
        ps.setLong(i++, r.effectiveEpochDayMin());
        ps.setLong(i++, r.effectiveEpochDayMax());
        ps.setDouble(i, r.commissionPercentage());
    }

    public static RuleSpec mapRule(ResultSet rs) throws SQLException {
        return new RuleSpec(
                rs.getInt("RULE_ID"),
                rs.getString("CARRIER"),
                rs.getString("PRODUCT"),
                rs.getString("STATE_CODE"),
                rs.getString("CHANNEL_CODE"),
                rs.getString("AGENT_TYPE"),
                rs.getString("REGISTRATION_TYPE"),
                rs.getString("COMMISSION_TYPE"),
                rs.getString("TRANSACTION_TYPE"),
                rs.getString("POLICY_TYPE"),
                rs.getString("CURRENCY_CODE"),
                rs.getString("PLAN_CODE"),
                rs.getString("PRODUCER_LEVEL"),
                rs.getString("CUSTOMER_SEGMENT"),
                rs.getString("PAYMENT_MODE"),
                rs.getBoolean("RENEWAL"),
                rs.getBoolean("REPLACEMENT"),
                rs.getBoolean("SPECIAL_PROGRAM"),
                rs.getBoolean("INTERNAL_BUSINESS"),
                rs.getDouble("PREMIUM_MIN"),
                rs.getDouble("PREMIUM_MAX"),
                rs.getDouble("FACE_AMOUNT_MIN"),
                rs.getDouble("FACE_AMOUNT_MAX"),
                rs.getDouble("PRODUCTION_AMOUNT_MIN"),
                rs.getDouble("PRODUCTION_AMOUNT_MAX"),
                rs.getInt("POLICY_DURATION_MIN"),
                rs.getInt("POLICY_DURATION_MAX"),
                rs.getInt("ISSUE_AGE_MIN"),
                rs.getInt("ISSUE_AGE_MAX"),
                rs.getLong("EFFECTIVE_EPOCH_DAY_MIN"),
                rs.getLong("EFFECTIVE_EPOCH_DAY_MAX"),
                rs.getDouble("COMMISSION_PERCENTAGE")
        );
    }

    public static void bindTransaction(PreparedStatement ps, CommissionTransaction tx, int partition) throws SQLException {
        int i = 1;
        ps.setLong(i++, tx.getTransactionId());
        ps.setInt(i++, partition);
        ps.setInt(i++, tx.getExpectedRuleId());
        ps.setString(i++, tx.getCarrier());
        ps.setString(i++, tx.getProduct());
        ps.setString(i++, tx.getState());
        ps.setString(i++, tx.getChannel());
        ps.setString(i++, tx.getAgentType());
        ps.setString(i++, tx.getRegistrationType());
        ps.setString(i++, tx.getCommissionType());
        ps.setString(i++, tx.getTransactionType());
        ps.setString(i++, tx.getPolicyType());
        ps.setString(i++, tx.getCurrency());
        ps.setString(i++, tx.getPlanCode());
        ps.setString(i++, tx.getProducerLevel());
        ps.setString(i++, tx.getCustomerSegment());
        ps.setString(i++, tx.getPaymentMode());
        ps.setBoolean(i++, tx.isRenewal());
        ps.setBoolean(i++, tx.isReplacement());
        ps.setBoolean(i++, tx.isSpecialProgram());
        ps.setBoolean(i++, tx.isInternalBusiness());
        ps.setDouble(i++, tx.getPremium());
        ps.setDouble(i++, tx.getFaceAmount());
        ps.setDouble(i++, tx.getProductionAmount());
        ps.setInt(i++, tx.getPolicyDurationMonths());
        ps.setInt(i++, tx.getIssueAge());
        ps.setLong(i, tx.getEffectiveEpochDay());
    }

    public static CommissionTransaction mapTransaction(ResultSet rs) throws SQLException {
        return new CommissionTransaction(
                rs.getLong("TRANSACTION_ID"),
                rs.getInt("EXPECTED_RULE_ID"),
                rs.getString("CARRIER"),
                rs.getString("PRODUCT"),
                rs.getString("STATE_CODE"),
                rs.getString("CHANNEL_CODE"),
                rs.getString("AGENT_TYPE"),
                rs.getString("REGISTRATION_TYPE"),
                rs.getString("COMMISSION_TYPE"),
                rs.getString("TRANSACTION_TYPE"),
                rs.getString("POLICY_TYPE"),
                rs.getString("CURRENCY_CODE"),
                rs.getString("PLAN_CODE"),
                rs.getString("PRODUCER_LEVEL"),
                rs.getString("CUSTOMER_SEGMENT"),
                rs.getString("PAYMENT_MODE"),
                rs.getBoolean("RENEWAL"),
                rs.getBoolean("REPLACEMENT"),
                rs.getBoolean("SPECIAL_PROGRAM"),
                rs.getBoolean("INTERNAL_BUSINESS"),
                rs.getDouble("PREMIUM"),
                rs.getDouble("FACE_AMOUNT"),
                rs.getDouble("PRODUCTION_AMOUNT"),
                rs.getInt("POLICY_DURATION_MONTHS"),
                rs.getInt("ISSUE_AGE"),
                rs.getLong("EFFECTIVE_EPOCH_DAY")
        );
    }
}
