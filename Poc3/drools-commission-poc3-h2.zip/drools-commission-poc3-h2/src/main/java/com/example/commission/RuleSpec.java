package com.example.commission;

public record RuleSpec(
        int ruleId,
        String carrier,
        String product,
        String state,
        String channel,
        String agentType,
        String registrationType,
        String commissionType,
        String transactionType,
        String policyType,
        String currency,
        String planCode,
        String producerLevel,
        String customerSegment,
        String paymentMode,
        boolean renewal,
        boolean replacement,
        boolean specialProgram,
        boolean internalBusiness,
        double premiumMin,
        double premiumMax,
        double faceAmountMin,
        double faceAmountMax,
        double productionAmountMin,
        double productionAmountMax,
        int policyDurationMin,
        int policyDurationMax,
        int issueAgeMin,
        int issueAgeMax,
        long effectiveEpochDayMin,
        long effectiveEpochDayMax,
        double commissionPercentage
) {
    public static RuleSpec fromRuleId(int ruleId) {
        int[] x = RuleDimensions.exactIndexes(ruleId);
        long mixed = RuleDimensions.mixedKey(ruleId);

        int premiumBand = (int) ((mixed >>> 3) % 20);
        int faceBand = (int) ((mixed >>> 9) % 20);
        int productionBand = (int) ((mixed >>> 15) % 20);
        int durationBand = (int) ((mixed >>> 21) % 10);
        int ageBand = (int) ((mixed >>> 27) % 12);
        int effectiveYearOffset = (int) ((mixed >>> 33) % 6);

        double premiumMin = premiumBand * 50_000.0;
        double faceMin = faceBand * 250_000.0;
        double productionMin = productionBand * 100_000.0;
        int durationMin = durationBand * 12;
        int ageMin = 18 + ageBand * 4;
        long effectiveMin = 19_723L + effectiveYearOffset * 365L;

        return new RuleSpec(
                ruleId,
                RuleDimensions.CARRIERS[x[0]],
                RuleDimensions.PRODUCTS[x[1]],
                RuleDimensions.STATES[x[2]],
                RuleDimensions.CHANNELS[x[3]],
                RuleDimensions.AGENT_TYPES[x[4]],
                RuleDimensions.REGISTRATION_TYPES[x[5]],
                RuleDimensions.COMMISSION_TYPES[x[6]],
                RuleDimensions.TRANSACTION_TYPES[x[7]],
                RuleDimensions.POLICY_TYPES[x[8]],
                RuleDimensions.CURRENCIES[x[9]],
                RuleDimensions.PLAN_CODES[x[10]],
                RuleDimensions.PRODUCER_LEVELS[x[11]],
                RuleDimensions.CUSTOMER_SEGMENTS[x[12]],
                RuleDimensions.PAYMENT_MODES[x[13]],
                (mixed & 1L) == 0,
                (mixed & 2L) == 0,
                (mixed & 4L) == 0,
                (mixed & 8L) == 0,
                premiumMin, premiumMin + 49_999.99,
                faceMin, faceMin + 249_999.99,
                productionMin, productionMin + 99_999.99,
                durationMin, durationMin + 11,
                ageMin, ageMin + 3,
                effectiveMin, effectiveMin + 364,
                0.50 + (ruleId % 1500) / 100.0
        );
    }

    public int partition(int partitionCount) {
        int carrierIndex = Integer.parseInt(carrier.substring(3));
        return carrierIndex % partitionCount;
    }
}
