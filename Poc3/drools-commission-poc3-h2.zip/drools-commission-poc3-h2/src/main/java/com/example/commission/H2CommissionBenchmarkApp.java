package com.example.commission;

import java.nio.file.Files;
import java.time.Duration;

public final class H2CommissionBenchmarkApp {
    private H2CommissionBenchmarkApp() {}

    public static void main(String[] args) throws Exception {
        H2BenchmarkConfig config = H2BenchmarkConfig.fromArgs(args);
        printConfig(config);
        H2Database database = new H2Database(config);

        switch (config.mode()) {
            case CLEAN -> {
                database.deleteFiles();
                System.out.println("Deleted H2 database files for: " + config.databasePath().toAbsolutePath());
                return;
            }
            case COMPACT -> {
                database.compact();
                System.out.printf("Database compacted. Current size: %,.2f MB%n", database.databaseSizeMb());
                return;
            }
            default -> { }
        }

        long wholeRunStarted = System.nanoTime();
        database.initialize(config.resetDatabase());
        H2Seeder seeder = new H2Seeder(config, database);
        SeedResult seedResult = new SeedResult(0, 0, 0, 0);

        if (config.mode() == H2BenchmarkConfig.Mode.ALL || config.mode() == H2BenchmarkConfig.Mode.SEED) {
            seedResult = config.resetDatabase() ? seeder.reseed() : seeder.seedIfRequired();
        }

        if (config.mode() == H2BenchmarkConfig.Mode.INSPECT || config.mode() == H2BenchmarkConfig.Mode.SEED) {
            database.inspect();
            return;
        }

        validateExpectedRows(config, database);
        MemorySnapshot initial = MemorySnapshot.afterGc();
        System.out.printf("Initial heap after GC: %,.1f MB%n%n", initial.heapUsedMb());

        long runtimeStarted = System.nanoTime();
        try (DatabaseRuleSessions sessions = DatabaseRuleSessions.load(config, database)) {
            H2BatchProcessor processor = new H2BatchProcessor(config, database, sessions);
            DbBenchmarkResult result = processor.process();
            long runtimeNanos = System.nanoTime() - runtimeStarted;
            long wholeRunNanos = System.nanoTime() - wholeRunStarted;
            printResult(config, database, seedResult, sessions, result, runtimeNanos, wholeRunNanos);
            H2CsvResultWriter.append(config.csvOutput(), config, seedResult, sessions, result, database.databaseSizeMb());
            System.out.println("CSV appended to: " + config.csvOutput().toAbsolutePath());

            if (result.incorrect() > 0 || result.transactions() != config.transactionCount()) {
                throw new IllegalStateException("Correctness/count failure: processed=" + result.transactions()
                        + ", expected=" + config.transactionCount() + ", incorrect=" + result.incorrect());
            }
        }
    }

    private static void validateExpectedRows(H2BenchmarkConfig config, H2Database database) throws Exception {
        long rules = database.count("COMMISSION_RULE");
        long transactions = database.count("COMMISSION_TRANSACTION");
        if (rules != config.ruleCount() || transactions != config.transactionCount()) {
            throw new IllegalStateException("Database contains " + rules + " rules and " + transactions
                    + " transactions, but the run expects " + config.ruleCount() + " and "
                    + config.transactionCount() + ". Run mode=all/seed or use matching arguments.");
        }
    }

    private static void printConfig(H2BenchmarkConfig c) {
        System.out.println("============================================================");
        System.out.println(" Drools Commission POC #3 - FILE H2 END-TO-END");
        System.out.println("============================================================");
        System.out.printf("Mode                : %s%n", c.mode());
        System.out.printf("Commission rules    : %,d%n", c.ruleCount());
        System.out.printf("Database tx rows    : %,d%n", c.transactionCount());
        System.out.printf("Input columns       : 24%n");
        System.out.printf("Partitions/sessions : %d%n", c.partitions());
        System.out.printf("Worker threads      : %d%n", c.workerThreads());
        System.out.printf("Read batch          : %,d%n", c.readBatchSize());
        System.out.printf("Write batch         : %,d%n", c.writeBatchSize());
        System.out.printf("Seed batch          : %,d%n", c.seedBatchSize());
        System.out.printf("Reset database      : %s%n", c.resetDatabase());
        System.out.printf("Executable model    : %s%n", c.executableModel());
        System.out.printf("Beta range index    : %s%n", c.betaRangeIndex());
        System.out.printf("H2 URL              : %s%n", c.jdbcUrl());
        System.out.println("============================================================\n");
    }

    private static void printResult(
            H2BenchmarkConfig c,
            H2Database database,
            SeedResult seed,
            DatabaseRuleSessions sessions,
            DbBenchmarkResult result,
            long runtimeNanos,
            long wholeRunNanos) throws Exception {
        double elapsedSeconds = result.elapsedNanos() / 1_000_000_000.0;
        Duration projected2m = Duration.ofMillis(Math.round((2_000_000.0 / result.transactionsPerSecond()) * 1_000.0));
        long resultRows = database.count("COMMISSION_RESULT");

        System.out.println("\n====================== RESULT ==============================");
        System.out.printf("Rule DB seed          : %,d ms%n", seed.ruleSeedMillis());
        System.out.printf("Transaction DB seed   : %,d ms%n", seed.transactionSeedMillis());
        System.out.printf("Generic base build    : %,d ms%n", sessions.baseBuildMillis());
        System.out.printf("Rule facts loaded     : %,d in %,d ms%n", sessions.loadedRules(), sessions.totalRuleLoadMillis());
        System.out.printf("Max partition load    : %,d ms%n", sessions.maxPartitionRuleLoadMillis());
        System.out.printf("Heap after rules GC   : %,.1f MB%n", sessions.afterRuleLoad().heapUsedMb());
        System.out.printf("DB batch wall time    : %.3f s%n", elapsedSeconds);
        System.out.printf("End-to-end throughput : %,.2f tx/s%n", result.transactionsPerSecond());
        System.out.printf("Cumulative DB read    : %,.3f s%n", result.readNanos() / 1_000_000_000.0);
        System.out.printf("Cumulative Drools     : %,.3f s%n", result.engineNanos() / 1_000_000_000.0);
        System.out.printf("Cumulative DB write   : %,.3f s%n", result.writeNanos() / 1_000_000_000.0);
        System.out.printf("Batch p50             : %,.3f ms%n", result.p50BatchMillis());
        System.out.printf("Batch p95             : %,.3f ms%n", result.p95BatchMillis());
        System.out.printf("Batch p99             : %,.3f ms%n", result.p99BatchMillis());
        System.out.printf("Transactions read     : %,d%n", result.transactions());
        System.out.printf("Result rows written   : %,d%n", resultRows);
        System.out.printf("Matched               : %,d%n", result.matched());
        System.out.printf("No match              : %,d%n", result.noMatch());
        System.out.printf("Incorrect             : %,d%n", result.incorrect());
        System.out.printf("Heap after run GC     : %,.1f MB%n", result.afterRun().heapUsedMb());
        System.out.printf("Database file size    : %,.2f MB%n", database.databaseSizeMb());
        System.out.printf("Monthly runtime path  : %s%n", formatDuration(Duration.ofNanos(runtimeNanos)));
        System.out.printf("Complete run incl seed: %s%n", formatDuration(Duration.ofNanos(wholeRunNanos)));
        System.out.printf("Projected 2M DB path  : %s%n", formatDuration(projected2m));
        System.out.printf("2-hour target margin  : %.1fx%n", result.transactionsPerSecond() / (2_000_000.0 / 7200.0));
        System.out.println("============================================================");
        System.out.println("Note: cumulative read/engine/write times are summed across parallel workers and can exceed wall time.");
        if (Files.exists(c.databaseFile())) {
            System.out.println("Inspect with scripts\\inspect-h2.bat or scripts\\open-h2-console.bat.");
        }
    }

    private static String formatDuration(Duration duration) {
        long millis = duration.toMillis();
        long hours = millis / 3_600_000;
        long minutes = (millis % 3_600_000) / 60_000;
        long seconds = (millis % 60_000) / 1_000;
        long remainderMillis = millis % 1_000;
        return "%02d:%02d:%02d.%03d".formatted(hours, minutes, seconds, remainderMillis);
    }
}
