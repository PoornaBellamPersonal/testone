package com.example.commission;

import java.util.Arrays;

public final class RulePartitioner {
    private RulePartitioner() {}

    public static int[][] partitionRuleIds(int ruleCount, int partitions) {
        int[] counts = new int[partitions];
        for (int id = 0; id < ruleCount; id++) counts[RuleSpec.fromRuleId(id).partition(partitions)]++;
        int[][] ids = new int[partitions][];
        for (int p = 0; p < partitions; p++) ids[p] = new int[counts[p]];
        Arrays.fill(counts, 0);
        for (int id = 0; id < ruleCount; id++) {
            int p = RuleSpec.fromRuleId(id).partition(partitions);
            ids[p][counts[p]++] = id;
        }
        return ids;
    }
}
