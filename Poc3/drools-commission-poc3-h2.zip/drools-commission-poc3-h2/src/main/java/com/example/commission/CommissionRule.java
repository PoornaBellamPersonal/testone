package com.example.commission;

/**
 * A business commission row represented as data/fact, not as a compiled DRL rule.
 */
public final class CommissionRule {
    private final int ruleId;
    private final String carrier;
    private final String product;
    private final String state;
    private final String channel;
    private final String agentType;
    private final String registrationType;
    private final String commissionType;
    private final String transactionType;
    private final String policyType;
    private final String currency;
    private final String planCode;
    private final String producerLevel;
    private final String customerSegment;
    private final String paymentMode;
    private final boolean renewal;
    private final boolean replacement;
    private final boolean specialProgram;
    private final boolean internalBusiness;
    private final double premiumMin;
    private final double premiumMax;
    private final double faceAmountMin;
    private final double faceAmountMax;
    private final double productionAmountMin;
    private final double productionAmountMax;
    private final int policyDurationMin;
    private final int policyDurationMax;
    private final int issueAgeMin;
    private final int issueAgeMax;
    private final long effectiveEpochDayMin;
    private final long effectiveEpochDayMax;
    private final double commissionPercentage;

    public CommissionRule(RuleSpec r) {
        this.ruleId = r.ruleId();
        this.carrier = r.carrier();
        this.product = r.product();
        this.state = r.state();
        this.channel = r.channel();
        this.agentType = r.agentType();
        this.registrationType = r.registrationType();
        this.commissionType = r.commissionType();
        this.transactionType = r.transactionType();
        this.policyType = r.policyType();
        this.currency = r.currency();
        this.planCode = r.planCode();
        this.producerLevel = r.producerLevel();
        this.customerSegment = r.customerSegment();
        this.paymentMode = r.paymentMode();
        this.renewal = r.renewal();
        this.replacement = r.replacement();
        this.specialProgram = r.specialProgram();
        this.internalBusiness = r.internalBusiness();
        this.premiumMin = r.premiumMin();
        this.premiumMax = r.premiumMax();
        this.faceAmountMin = r.faceAmountMin();
        this.faceAmountMax = r.faceAmountMax();
        this.productionAmountMin = r.productionAmountMin();
        this.productionAmountMax = r.productionAmountMax();
        this.policyDurationMin = r.policyDurationMin();
        this.policyDurationMax = r.policyDurationMax();
        this.issueAgeMin = r.issueAgeMin();
        this.issueAgeMax = r.issueAgeMax();
        this.effectiveEpochDayMin = r.effectiveEpochDayMin();
        this.effectiveEpochDayMax = r.effectiveEpochDayMax();
        this.commissionPercentage = r.commissionPercentage();
    }

    public int getRuleId() { return ruleId; }
    public String getCarrier() { return carrier; }
    public String getProduct() { return product; }
    public String getState() { return state; }
    public String getChannel() { return channel; }
    public String getAgentType() { return agentType; }
    public String getRegistrationType() { return registrationType; }
    public String getCommissionType() { return commissionType; }
    public String getTransactionType() { return transactionType; }
    public String getPolicyType() { return policyType; }
    public String getCurrency() { return currency; }
    public String getPlanCode() { return planCode; }
    public String getProducerLevel() { return producerLevel; }
    public String getCustomerSegment() { return customerSegment; }
    public String getPaymentMode() { return paymentMode; }
    public boolean isRenewal() { return renewal; }
    public boolean isReplacement() { return replacement; }
    public boolean isSpecialProgram() { return specialProgram; }
    public boolean isInternalBusiness() { return internalBusiness; }
    public double getPremiumMin() { return premiumMin; }
    public double getPremiumMax() { return premiumMax; }
    public double getFaceAmountMin() { return faceAmountMin; }
    public double getFaceAmountMax() { return faceAmountMax; }
    public double getProductionAmountMin() { return productionAmountMin; }
    public double getProductionAmountMax() { return productionAmountMax; }
    public int getPolicyDurationMin() { return policyDurationMin; }
    public int getPolicyDurationMax() { return policyDurationMax; }
    public int getIssueAgeMin() { return issueAgeMin; }
    public int getIssueAgeMax() { return issueAgeMax; }
    public long getEffectiveEpochDayMin() { return effectiveEpochDayMin; }
    public long getEffectiveEpochDayMax() { return effectiveEpochDayMax; }
    public double getCommissionPercentage() { return commissionPercentage; }
}
