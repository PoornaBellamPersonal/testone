package com.example.commission;

public final class CommissionTransaction {
    private final long transactionId;
    private final int expectedRuleId;

    // 24 business input columns
    private final String carrier;
    private final String product;
    private final String state;
    private final String channel;
    private final String agentType;
    private final String registrationType;
    private final String commissionType;
    private final String transactionType;
    private final String policyType;
    private final String currency;
    private final String planCode;
    private final String producerLevel;
    private final String customerSegment;
    private final String paymentMode;
    private final boolean renewal;
    private final boolean replacement;
    private final boolean specialProgram;
    private final boolean internalBusiness;
    private final double premium;
    private final double faceAmount;
    private final double productionAmount;
    private final int policyDurationMonths;
    private final int issueAge;
    private final long effectiveEpochDay;

    private int matchedRuleId = -1;
    private double commissionPercentage = Double.NaN;

    public CommissionTransaction(
            long transactionId,
            int expectedRuleId,
            String carrier,
            String product,
            String state,
            String channel,
            String agentType,
            String registrationType,
            String commissionType,
            String transactionType,
            String policyType,
            String currency,
            String planCode,
            String producerLevel,
            String customerSegment,
            String paymentMode,
            boolean renewal,
            boolean replacement,
            boolean specialProgram,
            boolean internalBusiness,
            double premium,
            double faceAmount,
            double productionAmount,
            int policyDurationMonths,
            int issueAge,
            long effectiveEpochDay) {
        this.transactionId = transactionId;
        this.expectedRuleId = expectedRuleId;
        this.carrier = carrier;
        this.product = product;
        this.state = state;
        this.channel = channel;
        this.agentType = agentType;
        this.registrationType = registrationType;
        this.commissionType = commissionType;
        this.transactionType = transactionType;
        this.policyType = policyType;
        this.currency = currency;
        this.planCode = planCode;
        this.producerLevel = producerLevel;
        this.customerSegment = customerSegment;
        this.paymentMode = paymentMode;
        this.renewal = renewal;
        this.replacement = replacement;
        this.specialProgram = specialProgram;
        this.internalBusiness = internalBusiness;
        this.premium = premium;
        this.faceAmount = faceAmount;
        this.productionAmount = productionAmount;
        this.policyDurationMonths = policyDurationMonths;
        this.issueAge = issueAge;
        this.effectiveEpochDay = effectiveEpochDay;
    }

    public void applyCommission(int ruleId, double percentage) {
        this.matchedRuleId = ruleId;
        this.commissionPercentage = percentage;
    }

    public long getTransactionId() { return transactionId; }
    public int getExpectedRuleId() { return expectedRuleId; }
    public String getCarrier() { return carrier; }
    public String getProduct() { return product; }
    public String getState() { return state; }
    public String getChannel() { return channel; }
    public String getAgentType() { return agentType; }
    public String getRegistrationType() { return registrationType; }
    public String getCommissionType() { return commissionType; }
    public String getTransactionType() { return transactionType; }
    public String getPolicyType() { return policyType; }
    public String getCurrency() { return currency; }
    public String getPlanCode() { return planCode; }
    public String getProducerLevel() { return producerLevel; }
    public String getCustomerSegment() { return customerSegment; }
    public String getPaymentMode() { return paymentMode; }
    public boolean isRenewal() { return renewal; }
    public boolean isReplacement() { return replacement; }
    public boolean isSpecialProgram() { return specialProgram; }
    public boolean isInternalBusiness() { return internalBusiness; }
    public double getPremium() { return premium; }
    public double getFaceAmount() { return faceAmount; }
    public double getProductionAmount() { return productionAmount; }
    public int getPolicyDurationMonths() { return policyDurationMonths; }
    public int getIssueAge() { return issueAge; }
    public long getEffectiveEpochDay() { return effectiveEpochDay; }
    public int getMatchedRuleId() { return matchedRuleId; }
    public double getCommissionPercentage() { return commissionPercentage; }
}
