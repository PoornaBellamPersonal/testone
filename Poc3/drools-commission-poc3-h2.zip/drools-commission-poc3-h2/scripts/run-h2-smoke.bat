@echo off
setlocal
pushd "%~dp0.."
set MAVEN_OPTS=-Xms512m -Xmx4g -XX:+UseG1GC
mvn -q clean compile exec:java -Dexec.args="--mode=all --reset-db=true --rules=20000 --transactions=20000 --partitions=8 --threads=4 --read-batch=1000 --write-batch=1000 --seed-batch=2000 --db=data/commission-smoke --csv=benchmark-results-h2.csv"
popd
endlocal
