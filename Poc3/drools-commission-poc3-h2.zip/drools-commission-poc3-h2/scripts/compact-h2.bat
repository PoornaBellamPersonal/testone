@echo off
setlocal
pushd "%~dp0.."
mvn -q compile exec:java -Dexec.args="--mode=compact --db=data/commission-benchmark"
popd
endlocal
