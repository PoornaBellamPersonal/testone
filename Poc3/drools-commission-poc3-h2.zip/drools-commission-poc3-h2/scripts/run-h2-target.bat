@echo off
setlocal
pushd "%~dp0.."
set MAVEN_OPTS=-Xms1g -Xmx6g -XX:+UseG1GC
mvn -q clean compile exec:java -Dexec.args="--mode=all --reset-db=true --rules=200000 --transactions=200000 --partitions=32 --threads=8 --read-batch=2000 --write-batch=2000 --seed-batch=5000 --db=data/commission-benchmark --csv=benchmark-results-h2.csv"
popd
endlocal
