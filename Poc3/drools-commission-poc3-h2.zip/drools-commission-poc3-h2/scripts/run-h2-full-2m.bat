@echo off
setlocal
pushd "%~dp0.."
set MAVEN_OPTS=-Xms2g -Xmx8g -XX:+UseG1GC
mvn -q clean compile exec:java -Dexec.args="--mode=all --reset-db=true --rules=200000 --transactions=2000000 --partitions=32 --threads=8 --read-batch=5000 --write-batch=5000 --seed-batch=10000 --db=data/commission-2m --csv=benchmark-results-h2.csv"
popd
endlocal
