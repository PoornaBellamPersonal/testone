@echo off
setlocal
pushd "%~dp0.."
mvn -q compile exec:java -Dexec.args="--mode=inspect --db=data/commission-benchmark"
popd
endlocal
