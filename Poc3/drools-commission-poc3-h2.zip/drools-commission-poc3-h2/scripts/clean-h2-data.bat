@echo off
setlocal
pushd "%~dp0.."
mvn -q compile exec:java -Dexec.args="--mode=clean --db=data/commission-benchmark"
popd
endlocal
