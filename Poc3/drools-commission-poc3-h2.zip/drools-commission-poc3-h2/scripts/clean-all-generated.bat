@echo off
setlocal
pushd "%~dp0.."
echo This removes generated H2 databases, Maven target output, and benchmark CSV history.
if exist data rmdir /s /q data
if exist target rmdir /s /q target
if exist benchmark-results-h2.csv del /q benchmark-results-h2.csv
echo Cleanup complete.
popd
endlocal
