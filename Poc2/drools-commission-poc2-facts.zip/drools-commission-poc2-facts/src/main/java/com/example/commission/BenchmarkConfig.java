package com.example.commission;

import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

public record BenchmarkConfig(
        int ruleCount,
        long transactionCount,
        int partitions,
        int workerThreads,
        int batchSize,
        int warmupTransactions,
        double missRate,
        boolean executableModel,
        boolean betaRangeIndex,
        long seed,
        Path csvOutput
) {
    public static BenchmarkConfig fromArgs(String[] args) {
        Map<String, String> values = new HashMap<>();
        for (String arg : args) {
            if (!arg.startsWith("--") || !arg.contains("=")) {
                throw new IllegalArgumentException("Arguments must be --name=value. Invalid: " + arg);
            }
            int equals = arg.indexOf('=');
            values.put(arg.substring(2, equals), arg.substring(equals + 1));
        }

        BenchmarkConfig config = new BenchmarkConfig(
                intValue(values, "rules", 50_000),
                longValue(values, "transactions", 100_000),
                intValue(values, "partitions", 8),
                intValue(values, "threads", Math.max(1, Math.min(8, Runtime.getRuntime().availableProcessors()))),
                intValue(values, "batch", 2_000),
                intValue(values, "warmup", 10_000),
                doubleValue(values, "miss-rate", 0.0),
                boolValue(values, "executable-model", true),
                boolValue(values, "beta-range-index", true),
                longValue(values, "seed", 42L),
                Path.of(values.getOrDefault("csv", "benchmark-results-facts.csv"))
        );
        config.validate();
        return config;
    }

    private void validate() {
        if (ruleCount <= 0) throw new IllegalArgumentException("rules must be > 0");
        if (transactionCount <= 0) throw new IllegalArgumentException("transactions must be > 0");
        if (partitions <= 0 || partitions > RuleDimensions.CARRIERS.length) {
            throw new IllegalArgumentException("partitions must be between 1 and " + RuleDimensions.CARRIERS.length);
        }
        if (workerThreads <= 0) throw new IllegalArgumentException("threads must be > 0");
        if (batchSize <= 0) throw new IllegalArgumentException("batch must be > 0");
        if (warmupTransactions < 0) throw new IllegalArgumentException("warmup must be >= 0");
        if (missRate < 0.0 || missRate > 1.0) throw new IllegalArgumentException("miss-rate must be between 0 and 1");
        if (ruleCount > RuleDimensions.maxUniqueRuleCount()) {
            throw new IllegalArgumentException("Requested rule count exceeds deterministic unique rule combinations");
        }
    }

    private static int intValue(Map<String, String> m, String k, int d) {
        return Integer.parseInt(m.getOrDefault(k, Integer.toString(d)));
    }
    private static long longValue(Map<String, String> m, String k, long d) {
        return Long.parseLong(m.getOrDefault(k, Long.toString(d)));
    }
    private static double doubleValue(Map<String, String> m, String k, double d) {
        return Double.parseDouble(m.getOrDefault(k, Double.toString(d)));
    }
    private static boolean boolValue(Map<String, String> m, String k, boolean d) {
        return Boolean.parseBoolean(m.getOrDefault(k, Boolean.toString(d)));
    }
}
