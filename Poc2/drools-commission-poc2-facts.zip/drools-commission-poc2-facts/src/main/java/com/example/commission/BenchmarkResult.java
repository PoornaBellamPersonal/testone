package com.example.commission;

public record BenchmarkResult(
        long transactions,
        long matched,
        long noMatch,
        long incorrect,
        long elapsedNanos,
        double transactionsPerSecond,
        double p50BatchMillis,
        double p95BatchMillis,
        double p99BatchMillis,
        MemorySnapshot afterRun
) {}
