package com.example.commission;

import org.drools.model.codegen.ExecutableModelProject;
import org.kie.api.KieBase;
import org.kie.api.KieBaseConfiguration;
import org.kie.api.KieServices;
import org.kie.api.io.ResourceType;
import org.kie.api.runtime.KieSession;
import org.kie.internal.utils.KieHelper;

import java.util.Arrays;

/**
 * One small KieBase is shared by all partitions. Each partition has its own
 * stateful KieSession and stores only that partition's CommissionRule facts.
 */
public final class PartitionedRuleSessions implements AutoCloseable {
    private final KieBase kieBase;
    private final KieSession[] sessions;
    private final int[][] ruleIdsByPartition;
    private final long baseBuildMillis;
    private final long totalRuleLoadMillis;
    private final long maxPartitionRuleLoadMillis;
    private final MemorySnapshot afterBaseBuild;
    private final MemorySnapshot afterRuleLoad;

    private PartitionedRuleSessions(
            KieBase kieBase,
            KieSession[] sessions,
            int[][] ruleIdsByPartition,
            long baseBuildMillis,
            long totalRuleLoadMillis,
            long maxPartitionRuleLoadMillis,
            MemorySnapshot afterBaseBuild,
            MemorySnapshot afterRuleLoad) {
        this.kieBase = kieBase;
        this.sessions = sessions;
        this.ruleIdsByPartition = ruleIdsByPartition;
        this.baseBuildMillis = baseBuildMillis;
        this.totalRuleLoadMillis = totalRuleLoadMillis;
        this.maxPartitionRuleLoadMillis = maxPartitionRuleLoadMillis;
        this.afterBaseBuild = afterBaseBuild;
        this.afterRuleLoad = afterRuleLoad;
    }

    public static PartitionedRuleSessions build(BenchmarkConfig config) {
        if (config.betaRangeIndex()) {
            System.setProperty("drools.betaNodeRangeIndexEnabled", "true");
        } else {
            System.setProperty("drools.betaNodeRangeIndexEnabled", "false");
        }

        int[][] ruleIdsByPartition = partitionRuleIds(config.ruleCount(), config.partitions());
        KieServices services = KieServices.Factory.get();
        KieBaseConfiguration baseConfig = services.newKieBaseConfiguration();

        System.out.println("Building ONE generic KieBase (1 DRL rule)...");
        long buildStarted = System.nanoTime();
        KieHelper helper = new KieHelper()
                .setClassLoader(CommissionTransaction.class.getClassLoader())
                .addContent(GenericCommissionDrl.content(), ResourceType.DRL);
        KieBase base = config.executableModel()
                ? helper.build(ExecutableModelProject.class, baseConfig)
                : helper.build(baseConfig);
        long baseBuildMillis = (System.nanoTime() - buildStarted) / 1_000_000L;
        MemorySnapshot afterBaseBuild = MemorySnapshot.afterGc();
        System.out.printf("Generic KieBase built in %,d ms; heap after GC: %,.1f MB%n%n",
                baseBuildMillis, afterBaseBuild.heapUsedMb());

        KieSession[] sessions = new KieSession[config.partitions()];
        long totalLoad = 0;
        long maxLoad = 0;

        for (int p = 0; p < config.partitions(); p++) {
            int[] ids = ruleIdsByPartition[p];
            if (ids.length == 0) continue;
            System.out.printf("Loading partition %d/%d: %,d CommissionRule facts%n",
                    p + 1, config.partitions(), ids.length);
            long started = System.nanoTime();
            KieSession session = base.newKieSession();
            for (int id : ids) session.insert(new CommissionRule(RuleSpec.fromRuleId(id)));
            sessions[p] = session;
            long ms = (System.nanoTime() - started) / 1_000_000L;
            totalLoad += ms;
            maxLoad = Math.max(maxLoad, ms);
            System.out.printf("  loaded in %,d ms%n", ms);
        }

        MemorySnapshot afterRuleLoad = MemorySnapshot.afterGc();
        System.out.printf("%nAll rule facts loaded. Total load: %,d ms; max partition: %,d ms%n",
                totalLoad, maxLoad);
        System.out.printf("Heap after rule load/GC: %,.1f MB (committed %,.1f MB); non-heap: %,.1f MB%n%n",
                afterRuleLoad.heapUsedMb(), afterRuleLoad.heapCommittedMb(), afterRuleLoad.nonHeapUsedMb());

        return new PartitionedRuleSessions(
                base, sessions, ruleIdsByPartition, baseBuildMillis, totalLoad, maxLoad,
                afterBaseBuild, afterRuleLoad);
    }

    public KieBase kieBase() { return kieBase; }
    public KieSession session(int partition) { return sessions[partition]; }
    public int[] ruleIds(int partition) { return ruleIdsByPartition[partition]; }
    public int partitionCount() { return sessions.length; }
    public long baseBuildMillis() { return baseBuildMillis; }
    public long totalRuleLoadMillis() { return totalRuleLoadMillis; }
    public long maxPartitionRuleLoadMillis() { return maxPartitionRuleLoadMillis; }
    public MemorySnapshot afterBaseBuild() { return afterBaseBuild; }
    public MemorySnapshot afterRuleLoad() { return afterRuleLoad; }

    @Override
    public void close() {
        for (KieSession session : sessions) {
            if (session != null) session.dispose();
        }
    }

    private static int[][] partitionRuleIds(int ruleCount, int partitions) {
        int[] counts = new int[partitions];
        for (int id = 0; id < ruleCount; id++) counts[RuleSpec.fromRuleId(id).partition(partitions)]++;
        int[][] ids = new int[partitions][];
        for (int p = 0; p < partitions; p++) ids[p] = new int[counts[p]];
        Arrays.fill(counts, 0);
        for (int id = 0; id < ruleCount; id++) {
            int p = RuleSpec.fromRuleId(id).partition(partitions);
            ids[p][counts[p]++] = id;
        }
        return ids;
    }
}
