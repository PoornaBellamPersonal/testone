package com.example.commission;

import java.util.List;

public record PartitionResult(long transactions, long matched, long noMatch, long incorrect, List<Long> batchNanos) {}
