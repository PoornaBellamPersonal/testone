package com.example.commission;

import org.kie.api.runtime.KieSession;
import org.kie.api.runtime.rule.FactHandle;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.SplittableRandom;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public final class BenchmarkRunner {
    private final BenchmarkConfig config;
    private final PartitionedRuleSessions ruleSessions;

    public BenchmarkRunner(BenchmarkConfig config, PartitionedRuleSessions ruleSessions) {
        this.config = config;
        this.ruleSessions = ruleSessions;
    }

    public void warmup() throws Exception {
        if (config.warmupTransactions() <= 0) return;
        long count = Math.min(config.warmupTransactions(), config.transactionCount());
        System.out.printf("Warmup: %,d transactions%n", count);
        runInternal(count, config.seed() ^ 0x9E3779B97F4A7C15L, false);
    }

    public BenchmarkResult runMeasured() throws Exception {
        System.out.printf("Measured run: %,d transactions%n", config.transactionCount());
        return runInternal(config.transactionCount(), config.seed(), true);
    }

    private BenchmarkResult runInternal(long totalTransactions, long seed, boolean collectMetrics) throws Exception {
        List<Callable<PartitionResult>> tasks = createPartitionTasks(totalTransactions, seed, collectMetrics);
        ExecutorService pool = Executors.newFixedThreadPool(Math.min(config.workerThreads(), tasks.size()));
        long started = System.nanoTime();
        try {
            List<Future<PartitionResult>> futures = pool.invokeAll(tasks);
            long matched = 0, noMatch = 0, incorrect = 0;
            List<Long> batchNanos = collectMetrics ? new ArrayList<>() : Collections.emptyList();

            for (Future<PartitionResult> future : futures) {
                PartitionResult r;
                try {
                    r = future.get();
                } catch (ExecutionException e) {
                    Throwable cause = e.getCause();
                    if (cause instanceof Exception ex) throw ex;
                    throw new RuntimeException(cause);
                }
                matched += r.matched();
                noMatch += r.noMatch();
                incorrect += r.incorrect();
                if (collectMetrics) batchNanos.addAll(r.batchNanos());
            }

            long elapsed = System.nanoTime() - started;
            if (collectMetrics) Collections.sort(batchNanos);
            MemorySnapshot afterRun = collectMetrics ? MemorySnapshot.afterGc() : MemorySnapshot.capture();
            return new BenchmarkResult(
                    totalTransactions, matched, noMatch, incorrect, elapsed,
                    totalTransactions / (elapsed / 1_000_000_000.0),
                    collectMetrics ? percentileMillis(batchNanos, 0.50) : 0,
                    collectMetrics ? percentileMillis(batchNanos, 0.95) : 0,
                    collectMetrics ? percentileMillis(batchNanos, 0.99) : 0,
                    afterRun
            );
        } finally {
            pool.shutdownNow();
        }
    }

    private List<Callable<PartitionResult>> createPartitionTasks(long totalTransactions, long seed, boolean metrics) {
        List<Integer> active = new ArrayList<>();
        for (int p = 0; p < ruleSessions.partitionCount(); p++) {
            if (ruleSessions.ruleIds(p).length > 0) active.add(p);
        }

        long basePerPartition = totalTransactions / active.size();
        long remainder = totalTransactions % active.size();
        long transactionIdBase = 0;
        List<Callable<PartitionResult>> tasks = new ArrayList<>(active.size());

        for (int i = 0; i < active.size(); i++) {
            int partition = active.get(i);
            long count = basePerPartition + (i < remainder ? 1 : 0);
            long txStart = transactionIdBase;
            transactionIdBase += count;
            long partitionSeed = mix64(seed ^ ((long) partition << 32));
            tasks.add(() -> executePartition(partition, txStart, count, partitionSeed, metrics));
        }
        return tasks;
    }

    /** Each partition's stateful session is owned by exactly one task at a time. */
    private PartitionResult executePartition(int partition, long transactionIdStart, long count, long seed, boolean metrics) {
        KieSession session = ruleSessions.session(partition);
        int[] ruleIds = ruleSessions.ruleIds(partition);
        SplittableRandom random = new SplittableRandom(seed);
        long matched = 0, noMatch = 0, incorrect = 0;
        List<Long> batchNanos = metrics ? new ArrayList<>() : Collections.emptyList();

        long done = 0;
        while (done < count) {
            int size = (int) Math.min(config.batchSize(), count - done);
            List<CommissionTransaction> transactions = new ArrayList<>(size);
            FactHandle[] handles = new FactHandle[size];

            for (int i = 0; i < size; i++) {
                int ruleId = ruleIds[random.nextInt(ruleIds.length)];
                long txId = transactionIdStart + done + i;
                boolean miss = config.missRate() > 0.0 && random.nextDouble() < config.missRate();
                transactions.add(miss
                        ? TransactionFactory.nonMatching(txId, ruleId)
                        : TransactionFactory.matching(txId, ruleId));
            }

            long engineStarted = System.nanoTime();
            for (int i = 0; i < size; i++) handles[i] = session.insert(transactions.get(i));
            session.fireAllRules();
            for (FactHandle handle : handles) session.delete(handle);
            long engineElapsed = System.nanoTime() - engineStarted;
            if (metrics) batchNanos.add(engineElapsed);

            for (CommissionTransaction tx : transactions) {
                if (tx.getExpectedRuleId() < 0) {
                    if (tx.getMatchedRuleId() == -1) noMatch++; else incorrect++;
                } else if (tx.getMatchedRuleId() == tx.getExpectedRuleId()) {
                    matched++;
                } else {
                    incorrect++;
                }
            }
            done += size;
        }
        return new PartitionResult(count, matched, noMatch, incorrect, batchNanos);
    }

    private static double percentileMillis(List<Long> values, double quantile) {
        if (values.isEmpty()) return 0.0;
        int index = (int) Math.ceil(quantile * values.size()) - 1;
        index = Math.max(0, Math.min(values.size() - 1, index));
        return values.get(index) / 1_000_000.0;
    }

    private static long mix64(long z) {
        z = (z ^ (z >>> 30)) * 0xbf58476d1ce4e5b9L;
        z = (z ^ (z >>> 27)) * 0x94d049bb133111ebL;
        return z ^ (z >>> 31);
    }
}
