package com.example.commission;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.Instant;
import java.util.Locale;

public final class CsvResultWriter {
    private CsvResultWriter() {}

    public static void append(Path path, BenchmarkConfig c, PartitionedRuleSessions s, BenchmarkResult r) throws IOException {
        boolean exists = Files.exists(path);
        if (path.toAbsolutePath().getParent() != null) Files.createDirectories(path.toAbsolutePath().getParent());
        StringBuilder out = new StringBuilder();
        if (!exists) {
            out.append("timestamp,rules,transactions,partitions,threads,batch,warmup,missRate,executableModel,betaRangeIndex,")
               .append("baseBuildMs,ruleLoadMs,maxPartitionRuleLoadMs,heapAfterBaseMB,heapAfterRuleLoadMB,")
               .append("elapsedMs,tps,p50BatchMs,p95BatchMs,p99BatchMs,matched,noMatch,incorrect,heapAfterRunMB,nonHeapAfterRunMB\n");
        }
        out.append(Instant.now()).append(',')
                .append(c.ruleCount()).append(',')
                .append(c.transactionCount()).append(',')
                .append(c.partitions()).append(',')
                .append(c.workerThreads()).append(',')
                .append(c.batchSize()).append(',')
                .append(c.warmupTransactions()).append(',')
                .append(c.missRate()).append(',')
                .append(c.executableModel()).append(',')
                .append(c.betaRangeIndex()).append(',')
                .append(s.baseBuildMillis()).append(',')
                .append(s.totalRuleLoadMillis()).append(',')
                .append(s.maxPartitionRuleLoadMillis()).append(',')
                .append(fmt(s.afterBaseBuild().heapUsedMb())).append(',')
                .append(fmt(s.afterRuleLoad().heapUsedMb())).append(',')
                .append(r.elapsedNanos() / 1_000_000L).append(',')
                .append(fmt(r.transactionsPerSecond())).append(',')
                .append(fmt(r.p50BatchMillis())).append(',')
                .append(fmt(r.p95BatchMillis())).append(',')
                .append(fmt(r.p99BatchMillis())).append(',')
                .append(r.matched()).append(',')
                .append(r.noMatch()).append(',')
                .append(r.incorrect()).append(',')
                .append(fmt(r.afterRun().heapUsedMb())).append(',')
                .append(fmt(r.afterRun().nonHeapUsedMb()))
                .append('\n');
        Files.writeString(path, out.toString(), StandardCharsets.UTF_8,
                StandardOpenOption.CREATE, StandardOpenOption.APPEND);
    }

    private static String fmt(double v) { return String.format(Locale.ROOT, "%.3f", v); }
}
