package com.example.commission;

import java.time.Duration;

public final class CommissionFactsBenchmarkApp {
    private CommissionFactsBenchmarkApp() {}

    public static void main(String[] args) throws Exception {
        BenchmarkConfig config = BenchmarkConfig.fromArgs(args);
        printConfig(config);
        MemorySnapshot initial = MemorySnapshot.afterGc();
        System.out.printf("Initial heap after GC : %,.1f MB%n%n", initial.heapUsedMb());

        try (PartitionedRuleSessions sessions = PartitionedRuleSessions.build(config)) {
            BenchmarkRunner runner = new BenchmarkRunner(config, sessions);
            runner.warmup();
            BenchmarkResult result = runner.runMeasured();
            printResult(config, sessions, result);
            CsvResultWriter.append(config.csvOutput(), config, sessions, result);
            System.out.println("CSV appended to: " + config.csvOutput().toAbsolutePath());
            if (result.incorrect() > 0) {
                throw new IllegalStateException("Correctness failure: " + result.incorrect() + " unexpected results");
            }
        }
    }

    private static void printConfig(BenchmarkConfig c) {
        System.out.println("============================================================");
        System.out.println(" Drools Commission POC #2 - RULES AS FACTS");
        System.out.println("============================================================");
        System.out.printf("Commission rows    : %,d facts%n", c.ruleCount());
        System.out.printf("Compiled DRL rules : 1%n");
        System.out.printf("Transactions       : %,d%n", c.transactionCount());
        System.out.printf("Input columns      : 24%n");
        System.out.printf("Partitions/sessions: %d%n", c.partitions());
        System.out.printf("Worker threads     : %d%n", c.workerThreads());
        System.out.printf("Batch size         : %,d%n", c.batchSize());
        System.out.printf("Warmup tx          : %,d%n", c.warmupTransactions());
        System.out.printf("Miss rate          : %.2f%%%n", c.missRate() * 100.0);
        System.out.printf("Executable model   : %s%n", c.executableModel());
        System.out.printf("Beta range index   : %s%n", c.betaRangeIndex());
        System.out.println("============================================================\n");
    }

    private static void printResult(BenchmarkConfig c, PartitionedRuleSessions s, BenchmarkResult r) {
        double elapsedSeconds = r.elapsedNanos() / 1_000_000_000.0;
        Duration projected2m = Duration.ofMillis(Math.round((2_000_000.0 / r.transactionsPerSecond()) * 1000.0));
        System.out.println("\n====================== RESULT ==============================");
        System.out.printf("Generic base build     : %,d ms%n", s.baseBuildMillis());
        System.out.printf("200K-row fact load     : %,d ms%n", s.totalRuleLoadMillis());
        System.out.printf("Max partition load     : %,d ms%n", s.maxPartitionRuleLoadMillis());
        System.out.printf("Heap after base GC     : %,.1f MB%n", s.afterBaseBuild().heapUsedMb());
        System.out.printf("Heap after rules GC    : %,.1f MB%n", s.afterRuleLoad().heapUsedMb());
        System.out.printf("Processing elapsed     : %.3f s%n", elapsedSeconds);
        System.out.printf("Throughput             : %,.2f tx/s%n", r.transactionsPerSecond());
        System.out.printf("Batch p50              : %,.3f ms%n", r.p50BatchMillis());
        System.out.printf("Batch p95              : %,.3f ms%n", r.p95BatchMillis());
        System.out.printf("Batch p99              : %,.3f ms%n", r.p99BatchMillis());
        System.out.printf("Matched                : %,d%n", r.matched());
        System.out.printf("Expected no-match      : %,d%n", r.noMatch());
        System.out.printf("Incorrect              : %,d%n", r.incorrect());
        System.out.printf("Heap after run GC      : %,.1f MB%n", r.afterRun().heapUsedMb());
        System.out.printf("Non-heap after run     : %,.1f MB%n", r.afterRun().nonHeapUsedMb());
        System.out.printf("Projected 2M duration  : %s%n", formatDuration(projected2m));
        System.out.printf("2-hour target margin   : %.1fx%n", r.transactionsPerSecond() / (2_000_000.0 / 7200.0));
        System.out.println("============================================================");
        if (c.transactionCount() < 2_000_000) {
            System.out.println("Note: projection is indicative only. Run the full 2M target profile before concluding.");
        }
    }

    private static String formatDuration(Duration d) {
        long seconds = d.toSeconds();
        return "%02d:%02d:%02d".formatted(seconds / 3600, (seconds % 3600) / 60, seconds % 60);
    }
}
