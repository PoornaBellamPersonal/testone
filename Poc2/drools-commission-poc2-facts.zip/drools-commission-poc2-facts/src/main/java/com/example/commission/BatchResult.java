package com.example.commission;

public record BatchResult(int transactions, int matched, int noMatch, int incorrect, long engineNanos) {}
