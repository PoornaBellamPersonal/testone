@echo off
setlocal
REM This already loads the FULL target 200,000 commission rows, but processes only 500K tx.
set MAVEN_OPTS=-Xms2g -Xmx8g -XX:+UseG1GC -XX:+HeapDumpOnOutOfMemoryError
mvn -q -DskipTests compile exec:java -Dexec.args="--rules=200000 --transactions=500000 --partitions=32 --threads=8 --batch=2000 --warmup=20000 --beta-range-index=true --executable-model=true --csv=benchmark-results-facts.csv"
endlocal
