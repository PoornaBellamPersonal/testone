@echo off
setlocal
REM Full RFP target: 200K commission rows, 24 inputs, 2M transactions.
set MAVEN_OPTS=-Xms2g -Xmx10g -XX:+UseG1GC -XX:+HeapDumpOnOutOfMemoryError
mvn -q -DskipTests compile exec:java -Dexec.args="--rules=200000 --transactions=2000000 --partitions=32 --threads=8 --batch=5000 --warmup=50000 --beta-range-index=true --executable-model=true --csv=benchmark-results-facts.csv"
endlocal
