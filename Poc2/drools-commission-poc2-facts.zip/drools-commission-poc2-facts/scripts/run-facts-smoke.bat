@echo off
setlocal
set MAVEN_OPTS=-Xms1g -Xmx4g -XX:+UseG1GC -XX:+HeapDumpOnOutOfMemoryError
mvn -q -DskipTests compile exec:java -Dexec.args="--rules=50000 --transactions=100000 --partitions=8 --threads=4 --batch=1000 --warmup=10000 --beta-range-index=true --executable-model=true --csv=benchmark-results-facts.csv"
endlocal
