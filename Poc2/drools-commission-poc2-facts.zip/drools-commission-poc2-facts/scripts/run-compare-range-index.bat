@echo off
setlocal
set MAVEN_OPTS=-Xms2g -Xmx8g -XX:+UseG1GC

echo === Beta range index ENABLED ===
mvn -q -DskipTests compile exec:java -Dexec.args="--rules=100000 --transactions=250000 --partitions=16 --threads=8 --batch=2000 --warmup=10000 --beta-range-index=true --executable-model=true --csv=benchmark-results-facts.csv"

echo === Beta range index DISABLED ===
mvn -q -DskipTests compile exec:java -Dexec.args="--rules=100000 --transactions=250000 --partitions=16 --threads=8 --batch=2000 --warmup=10000 --beta-range-index=false --executable-model=true --csv=benchmark-results-facts.csv"
endlocal
