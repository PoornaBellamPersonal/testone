package com.ebix.cms.poc.contracts;

import java.util.List;

public record BatchCommand(
        String cycleId,
        String stageKey,
        String ruleSetKey,
        String batchId,
        int batchNo,
        List<Long> transactionIds) {
}
