package com.ebix.cms.poc.contracts;

public class RuntimeNodeStatus {
    private String nodeId;
    private String nodeType;
    private String status;
    private String address;
    private String details;

    public RuntimeNodeStatus() {
    }

    public RuntimeNodeStatus(String nodeId, String nodeType, String status, String address, String details) {
        this.nodeId = nodeId;
        this.nodeType = nodeType;
        this.status = status;
        this.address = address;
        this.details = details;
    }

    public String getNodeId() { return nodeId; }
    public void setNodeId(String nodeId) { this.nodeId = nodeId; }
    public String getNodeType() { return nodeType; }
    public void setNodeType(String nodeType) { this.nodeType = nodeType; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
    public String getDetails() { return details; }
    public void setDetails(String details) { this.details = details; }
}
