package com.ebix.cms.poc.contracts;

import java.util.List;

public record RuleEvaluationRequest(
        String cycleId,
        String batchId,
        String ruleSetKey,
        List<RuleEvaluationItem> items) {
}
