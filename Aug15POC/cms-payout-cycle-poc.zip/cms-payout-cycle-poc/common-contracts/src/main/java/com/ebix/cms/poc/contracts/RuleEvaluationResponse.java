package com.ebix.cms.poc.contracts;

import java.util.List;

public record RuleEvaluationResponse(
        String nodeId,
        String ruleSetKey,
        int processed,
        long durationMs,
        List<RuleEvaluationResult> results) {
}
