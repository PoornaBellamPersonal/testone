package com.ebix.cms.poc.contracts;

import java.util.Map;

public record RuleEvaluationResult(
        Long transactionId,
        boolean success,
        String matchedRule,
        Map<String, Object> outcome,
        String errorMessage,
        long durationMicros) {
}
