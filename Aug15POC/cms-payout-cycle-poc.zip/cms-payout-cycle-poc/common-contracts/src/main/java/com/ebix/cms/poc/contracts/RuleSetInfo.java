package com.ebix.cms.poc.contracts;

public class RuleSetInfo {
    private String key;
    private String name;
    private String description;
    private String version;

    public RuleSetInfo() {
    }

    public RuleSetInfo(String key, String name, String description, String version) {
        this.key = key;
        this.name = name;
        this.description = description;
        this.version = version;
    }

    public String getKey() { return key; }
    public void setKey(String key) { this.key = key; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getVersion() { return version; }
    public void setVersion(String version) { this.version = version; }
}
