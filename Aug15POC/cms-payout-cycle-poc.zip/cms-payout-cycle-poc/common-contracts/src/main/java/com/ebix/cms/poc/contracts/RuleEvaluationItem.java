package com.ebix.cms.poc.contracts;

import java.util.Map;

public record RuleEvaluationItem(
        Long transactionId,
        Map<String, Object> inputs) {
}
