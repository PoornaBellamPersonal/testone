package com.ebix.cms.poc.worker;

import com.ebix.cms.poc.contracts.*;
import com.ebix.cms.poc.data.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

import java.util.*;

@Service
public class BatchProcessingService {

    private final CmsTransactionRepository transactionRepository;
    private final RuleEngineNodeSelector nodeSelector;
    private final BatchWorkerPersistenceService persistenceService;

    public BatchProcessingService(
            CmsTransactionRepository transactionRepository,
            RuleEngineNodeSelector nodeSelector,
            BatchWorkerPersistenceService persistenceService) {
        this.transactionRepository = transactionRepository;
        this.nodeSelector = nodeSelector;
        this.persistenceService = persistenceService;
    }

    public void process(BatchCommand command) {
        if (!persistenceService.claim(command.batchId())) {
            return;
        }

        long started = System.nanoTime();
        String nodeUrl = nodeSelector.select(command.batchNo());

        try {
            long readStarted = System.nanoTime();
            List<CmsTransactionEntity> transactions =
                    transactionRepository.findAllById(command.transactionIds());

            Map<Long, CmsTransactionEntity> byId = new HashMap<>();
            for (CmsTransactionEntity tx : transactions) {
                byId.put(tx.getId(), tx);
            }

            List<RuleEvaluationItem> items = new ArrayList<>(command.transactionIds().size());
            for (Long id : command.transactionIds()) {
                CmsTransactionEntity tx = byId.get(id);
                if (tx == null) {
                    throw new IllegalStateException("Transaction not found: " + id);
                }
                items.add(new RuleEvaluationItem(id, toInputs(tx)));
            }
            long dbReadMs = (System.nanoTime() - readStarted) / 1_000_000;

            RuleEvaluationRequest request = new RuleEvaluationRequest(
                    command.cycleId(),
                    command.batchId(),
                    command.ruleSetKey(),
                    items);

            long ruleCallStarted = System.nanoTime();
            RuleEvaluationResponse response = RestClient.create(nodeUrl)
                    .post()
                    .uri("/api/v1/rule-sets/{ruleSetKey}/evaluate-batch", command.ruleSetKey())
                    .body(request)
                    .retrieve()
                    .body(RuleEvaluationResponse.class);

            long ruleCallMs = (System.nanoTime() - ruleCallStarted) / 1_000_000;

            if (response == null) {
                throw new IllegalStateException("Rule engine returned an empty response");
            }

            persistenceService.complete(
                    command, response, started, dbReadMs, ruleCallMs);
        } catch (Exception ex) {
            persistenceService.fail(command.batchId(), ex);
        }
    }

    private Map<String, Object> toInputs(CmsTransactionEntity tx) {
        Map<String, Object> inputs = new LinkedHashMap<>();
        inputs.put("region", tx.getRegion());
        inputs.put("product", tx.getProduct());
        inputs.put("agentLevel", tx.getAgentLevel());
        inputs.put("amount", tx.getAmount() == null ? 0d : tx.getAmount().doubleValue());
        inputs.put("residencyState", tx.getResidencyState());
        inputs.put("channelType", tx.getChannelType());
        return inputs;
    }
}
