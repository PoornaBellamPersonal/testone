package com.ebix.cms.poc.worker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jms.annotation.EnableJms;

@SpringBootApplication
@EnableJms
@EntityScan("com.ebix.cms.poc.data")
@EnableJpaRepositories("com.ebix.cms.poc.data")
public class CmsBatchWorkerApplication {
    public static void main(String[] args) {
        SpringApplication.run(CmsBatchWorkerApplication.class, args);
    }
}
