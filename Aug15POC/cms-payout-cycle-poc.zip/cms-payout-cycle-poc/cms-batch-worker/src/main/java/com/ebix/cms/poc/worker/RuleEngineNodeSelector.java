package com.ebix.cms.poc.worker;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;

@Component
public class RuleEngineNodeSelector {

    private final List<String> nodes;

    public RuleEngineNodeSelector(
            @Value("${cms.rule-engine.nodes:http://localhost:8091,http://localhost:8092}") String nodes) {
        this.nodes = Arrays.stream(nodes.split(","))
                .map(String::trim)
                .filter(s -> !s.isBlank())
                .toList();

        if (this.nodes.isEmpty()) {
            throw new IllegalArgumentException("cms.rule-engine.nodes must contain at least one URL");
        }
    }

    public String select(int batchNo) {
        return nodes.get(Math.floorMod(batchNo - 1, nodes.size()));
    }
}
