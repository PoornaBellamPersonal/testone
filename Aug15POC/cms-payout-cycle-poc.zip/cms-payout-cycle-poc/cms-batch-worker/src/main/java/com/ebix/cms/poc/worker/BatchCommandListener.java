package com.ebix.cms.poc.worker;

import com.ebix.cms.poc.contracts.BatchCommand;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

@Component
public class BatchCommandListener {

    private final BatchProcessingService processingService;

    @Value("${cms.worker.id:WORKER-01}")
    private String workerId;

    public BatchCommandListener(BatchProcessingService processingService) {
        this.processingService = processingService;
    }

    @JmsListener(destination = "${cms.jms.batch-queue:cms.payout.batch.queue}")
    public void onBatch(BatchCommand command) {
        System.out.printf("[%s] received %s stage=%s batch=%d items=%d%n",
                workerId, command.batchId(), command.stageKey(),
                command.batchNo(), command.transactionIds().size());
        processingService.process(command);
    }
}
