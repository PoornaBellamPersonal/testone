package com.ebix.cms.poc.worker;

import com.ebix.cms.poc.contracts.BatchCommand;
import com.ebix.cms.poc.contracts.RuleEvaluationResponse;
import com.ebix.cms.poc.contracts.RuleEvaluationResult;
import com.ebix.cms.poc.data.*;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@Service
public class BatchWorkerPersistenceService {

    private final CmsBatchRepository batchRepository;
    private final DecisionAuditRepository auditRepository;
    private final ObjectMapper objectMapper;

    @Value("${cms.worker.id:WORKER-01}")
    private String workerId;

    public BatchWorkerPersistenceService(
            CmsBatchRepository batchRepository,
            DecisionAuditRepository auditRepository,
            ObjectMapper objectMapper) {
        this.batchRepository = batchRepository;
        this.auditRepository = auditRepository;
        this.objectMapper = objectMapper;
    }

    @Transactional
    public boolean claim(String batchId) {
        CmsBatchEntity batch = batchRepository.findById(batchId).orElseThrow();
        if (batch.getStatus() == BatchStatus.COMPLETED) {
            return false;
        }

        Instant startedAt = Instant.now();
        batch.setStatus(BatchStatus.PROCESSING);
        batch.setWorkerId(workerId);
        batch.setAttempts(batch.getAttempts() + 1);
        batch.setStartedAt(startedAt);
        if (batch.getCreatedAt() != null) {
            batch.setQueueWaitMs(Math.max(0L, Duration.between(batch.getCreatedAt(), startedAt).toMillis()));
        }
        batch.setErrorMessage(null);
        batchRepository.save(batch);
        return true;
    }

    @Transactional
    public void complete(
            BatchCommand command,
            RuleEvaluationResponse response,
            long processingStartedNanos,
            long dbReadMs,
            long ruleCallMs)
            throws JsonProcessingException {

        CmsBatchEntity batch = batchRepository.findById(command.batchId()).orElseThrow();

        List<DecisionAuditEntity> audits = new ArrayList<>(response.results().size());
        for (RuleEvaluationResult result : response.results()) {
            DecisionAuditEntity audit = new DecisionAuditEntity();
            audit.setCycleId(command.cycleId());
            audit.setStageKey(command.stageKey());
            audit.setBatchId(command.batchId());
            audit.setTransactionId(result.transactionId());
            audit.setRuleSetKey(command.ruleSetKey());
            audit.setRuleEngineNode(response.nodeId());
            audit.setMatchedRule(result.matchedRule());
            audit.setSuccess(result.success());
            audit.setErrorMessage(result.errorMessage());
            audit.setOutcomeJson(objectMapper.writeValueAsString(result.outcome()));
            audit.setDurationMicros(result.durationMicros());
            audit.setEvaluatedAt(Instant.now());
            audits.add(audit);
        }
        long writeStarted = System.nanoTime();
        auditRepository.saveAll(audits);

        batch.setStatus(BatchStatus.COMPLETED);
        batch.setRuleEngineNode(response.nodeId());
        batch.setDbReadMs(dbReadMs);
        batch.setRuleCallMs(ruleCallMs);
        batch.setRuleEngineMs(response.durationMs());
        batch.setCompletedAt(Instant.now());
        batch.setErrorMessage(null);
        batchRepository.save(batch);

        auditRepository.flush();
        batchRepository.flush();

        batch.setDbWriteMs((System.nanoTime() - writeStarted) / 1_000_000);
        batch.setDurationMs((System.nanoTime() - processingStartedNanos) / 1_000_000);
        batchRepository.saveAndFlush(batch);
    }

    @Transactional
    public void fail(String batchId, Exception ex) {
        CmsBatchEntity batch = batchRepository.findById(batchId).orElseThrow();
        batch.setStatus(BatchStatus.FAILED);
        batch.setCompletedAt(Instant.now());
        batch.setErrorMessage(truncate(ex.getClass().getSimpleName() + ": " + ex.getMessage(), 950));
        batchRepository.save(batch);
    }

    private String truncate(String text, int max) {
        if (text == null || text.length() <= max) {
            return text;
        }
        return text.substring(0, max);
    }
}
