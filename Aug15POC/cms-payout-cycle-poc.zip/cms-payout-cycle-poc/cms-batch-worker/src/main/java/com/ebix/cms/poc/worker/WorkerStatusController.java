package com.ebix.cms.poc.worker;

import com.ebix.cms.poc.contracts.RuntimeNodeStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class WorkerStatusController {

    @Value("${cms.worker.id:WORKER-01}")
    private String workerId;

    @Value("${server.port:8085}")
    private int port;

    @GetMapping("/api/v1/node")
    public RuntimeNodeStatus node() {
        return new RuntimeNodeStatus(
                workerId,
                "BATCH_WORKER",
                "UP",
                "http://localhost:" + port,
                "JMS consumer; loads CMS transaction data and invokes rule engine");
    }
}
