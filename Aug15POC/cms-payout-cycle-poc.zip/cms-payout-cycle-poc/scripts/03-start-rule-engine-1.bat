@echo off
setlocal
set "ROOT=%~dp0.."
cd /d "%ROOT%"
title CMS POC - RE-01
echo Starting Rule Engine RE-01 on 8091...
java -jar "rule-engine-service\target\rule-engine-service-1.0.0-SNAPSHOT.jar" --server.port=8091 --rule-engine.node-id=RE-01
