@echo off
setlocal
set "ROOT=%~dp0.."
cd /d "%ROOT%"
title CMS POC - WORKER-02
echo Starting Batch Worker WORKER-02 on 8086...
java -jar "cms-batch-worker\target\cms-batch-worker-1.0.0-SNAPSHOT.jar" --server.port=8086 --cms.worker.id=WORKER-02
