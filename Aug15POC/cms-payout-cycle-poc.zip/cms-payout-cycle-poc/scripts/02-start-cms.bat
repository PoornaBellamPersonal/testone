@echo off
setlocal
set "ROOT=%~dp0.."
cd /d "%ROOT%"
title CMS POC - CMS
echo Starting CMS JSP application with embedded Camunda 7...
java -jar "cms-application\target\cms-application-1.0.0-SNAPSHOT.war"
