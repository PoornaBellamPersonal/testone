@echo off
setlocal
set "ROOT=%~dp0.."
cd /d "%ROOT%"
title CMS POC - RE-02
echo Starting Rule Engine RE-02 on 8092...
java -jar "rule-engine-service\target\rule-engine-service-1.0.0-SNAPSHOT.jar" --server.port=8092 --rule-engine.node-id=RE-02
