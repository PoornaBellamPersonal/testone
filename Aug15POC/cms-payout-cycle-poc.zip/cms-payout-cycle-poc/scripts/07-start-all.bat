@echo off
setlocal
set "SCRIPTS=%~dp0"

echo Starting CMS POC processes in separate command windows...
echo.

start "CMS POC - Infrastructure" cmd /k call "%SCRIPTS%01-start-infrastructure.bat"
timeout /t 3 /nobreak >nul

start "CMS POC - CMS" cmd /k call "%SCRIPTS%02-start-cms.bat"
timeout /t 8 /nobreak >nul

start "CMS POC - RE-01" cmd /k call "%SCRIPTS%03-start-rule-engine-1.bat"
start "CMS POC - RE-02" cmd /k call "%SCRIPTS%04-start-rule-engine-2.bat"
timeout /t 3 /nobreak >nul

start "CMS POC - WORKER-01" cmd /k call "%SCRIPTS%05-start-worker-1.bat"
start "CMS POC - WORKER-02" cmd /k call "%SCRIPTS%06-start-worker-2.bat"

echo.
echo Processes started.
echo Open http://localhost:8080/login after all windows show startup success.
echo Credentials: admin / admin
echo.
