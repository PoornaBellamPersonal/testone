@echo off
setlocal
set "ROOT=%~dp0.."
cd /d "%ROOT%"
echo Calling RE-01 Commission Rules with one sample transaction...
echo.
curl -s -X POST ^
  -H "Content-Type: application/json" ^
  --data-binary "@scripts\sample-rule-request.json" ^
  http://localhost:8091/api/v1/rule-sets/COMMISSION_RULES/evaluate-batch
echo.
echo.
echo Expected matched rule for the supplied inputs: COMM-001
