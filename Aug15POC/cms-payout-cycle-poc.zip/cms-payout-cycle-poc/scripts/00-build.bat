@echo off
setlocal
set "ROOT=%~dp0.."
cd /d "%ROOT%"
echo.
echo Building CMS Payout Cycle POC...
echo.
call mvn clean package
if errorlevel 1 (
  echo.
  echo BUILD FAILED
  exit /b 1
)
echo.
echo BUILD SUCCESSFUL
echo.
