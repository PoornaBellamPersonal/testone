@echo off
setlocal
set "ROOT=%~dp0.."
cd /d "%ROOT%"

echo IMPORTANT: Stop CMS, both workers, both rule engines and infrastructure first.
choice /M "Delete the POC H2 database under .\data"
if errorlevel 2 exit /b 0

if exist data (
  rmdir /s /q data
  echo POC data deleted.
) else (
  echo No data directory exists.
)
