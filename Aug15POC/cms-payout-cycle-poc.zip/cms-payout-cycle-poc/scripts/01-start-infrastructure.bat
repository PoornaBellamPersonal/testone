@echo off
setlocal
set "ROOT=%~dp0.."
cd /d "%ROOT%"
title CMS POC - Infrastructure
echo Starting file-backed H2 TCP server and ActiveMQ Artemis...
java -jar "poc-infrastructure\target\poc-infrastructure-1.0.0-SNAPSHOT.jar"
