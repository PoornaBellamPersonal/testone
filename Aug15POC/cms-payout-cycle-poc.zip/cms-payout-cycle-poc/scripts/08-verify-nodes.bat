@echo off
echo ============================================================
echo CMS POC node verification
echo ============================================================
echo.
echo RE-01:
curl -s http://localhost:8091/api/v1/node
echo.
echo.
echo RE-02:
curl -s http://localhost:8092/api/v1/node
echo.
echo.
echo WORKER-01:
curl -s http://localhost:8085/api/v1/node
echo.
echo.
echo WORKER-02:
curl -s http://localhost:8086/api/v1/node
echo.
echo.
echo CMS login page:
curl -s -o NUL -w "HTTP %%{http_code}\n" http://localhost:8080/login
echo.
echo H2 web console:
curl -s -o NUL -w "HTTP %%{http_code}\n" http://localhost:8082
echo.
