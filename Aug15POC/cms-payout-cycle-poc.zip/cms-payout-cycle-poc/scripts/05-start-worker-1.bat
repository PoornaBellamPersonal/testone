@echo off
setlocal
set "ROOT=%~dp0.."
cd /d "%ROOT%"
title CMS POC - WORKER-01
echo Starting Batch Worker WORKER-01 on 8085...
java -jar "cms-batch-worker\target\cms-batch-worker-1.0.0-SNAPSHOT.jar" --server.port=8085 --cms.worker.id=WORKER-01
