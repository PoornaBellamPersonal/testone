package com.ebix.cms.poc.data;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "CMS_CYCLE")
public class CmsCycleEntity {
    @Id
    @Column(name = "CYCLE_ID", length = 64)
    private String id;

    @Column(name = "CYCLE_KEY", nullable = false, unique = true, length = 100)
    private String cycleKey;

    @Column(name = "PERIOD_LABEL", length = 40)
    private String periodLabel;

    @Enumerated(EnumType.STRING)
    @Column(name = "STATUS", nullable = false, length = 20)
    private CycleStatus status;

    @Column(name = "CURRENT_STAGE", length = 40)
    private String currentStage;

    @Column(name = "TRANSACTION_COUNT", nullable = false)
    private int transactionCount;

    @Column(name = "BATCH_SIZE", nullable = false)
    private int batchSize;

    @Column(name = "STARTED_AT")
    private Instant startedAt;

    @Column(name = "COMPLETED_AT")
    private Instant completedAt;

    @Column(name = "TOTAL_DURATION_MS")
    private Long totalDurationMs;

    @Column(name = "PROCESS_INSTANCE_ID", length = 64)
    private String processInstanceId;

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getCycleKey() { return cycleKey; }
    public void setCycleKey(String cycleKey) { this.cycleKey = cycleKey; }
    public String getPeriodLabel() { return periodLabel; }
    public void setPeriodLabel(String periodLabel) { this.periodLabel = periodLabel; }
    public CycleStatus getStatus() { return status; }
    public void setStatus(CycleStatus status) { this.status = status; }
    public String getCurrentStage() { return currentStage; }
    public void setCurrentStage(String currentStage) { this.currentStage = currentStage; }
    public int getTransactionCount() { return transactionCount; }
    public void setTransactionCount(int transactionCount) { this.transactionCount = transactionCount; }
    public int getBatchSize() { return batchSize; }
    public void setBatchSize(int batchSize) { this.batchSize = batchSize; }
    public Instant getStartedAt() { return startedAt; }
    public void setStartedAt(Instant startedAt) { this.startedAt = startedAt; }
    public Instant getCompletedAt() { return completedAt; }
    public void setCompletedAt(Instant completedAt) { this.completedAt = completedAt; }
    public Long getTotalDurationMs() { return totalDurationMs; }
    public void setTotalDurationMs(Long totalDurationMs) { this.totalDurationMs = totalDurationMs; }
    public String getProcessInstanceId() { return processInstanceId; }
    public void setProcessInstanceId(String processInstanceId) { this.processInstanceId = processInstanceId; }
}
