package com.ebix.cms.poc.data;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

public interface CmsBatchItemRepository extends JpaRepository<CmsBatchItemEntity, Long> {
    @Query("select i.transactionId from CmsBatchItemEntity i where i.batchId = :batchId order by i.id")
    List<Long> findTransactionIdsByBatchId(@Param("batchId") String batchId);
}
