package com.ebix.cms.poc.data;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface DecisionAuditRepository extends JpaRepository<DecisionAuditEntity, Long> {
    List<DecisionAuditEntity> findTop100ByOrderByEvaluatedAtDesc();
    List<DecisionAuditEntity> findByTransactionIdOrderByEvaluatedAtAsc(Long transactionId);
    List<DecisionAuditEntity> findByCycleIdAndTransactionIdOrderByEvaluatedAtAsc(String cycleId, Long transactionId);
}
