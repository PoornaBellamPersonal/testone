package com.ebix.cms.poc.data;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface CmsCycleRepository extends JpaRepository<CmsCycleEntity, String> {
    List<CmsCycleEntity> findAllByOrderByStartedAtDesc();
    long countByStatus(CycleStatus status);
}
