package com.ebix.cms.poc.data;

import jakarta.persistence.*;

@Entity
@Table(name = "CMS_BATCH_ITEM",
       indexes = @Index(name = "IX_CMS_BATCH_ITEM_BATCH", columnList = "BATCH_ID"))
public class CmsBatchItemEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ITEM_ID")
    private Long id;

    @Column(name = "BATCH_ID", nullable = false, length = 80)
    private String batchId;

    @Column(name = "TRANSACTION_ID", nullable = false)
    private Long transactionId;

    public Long getId() { return id; }
    public String getBatchId() { return batchId; }
    public void setBatchId(String batchId) { this.batchId = batchId; }
    public Long getTransactionId() { return transactionId; }
    public void setTransactionId(Long transactionId) { this.transactionId = transactionId; }
}
