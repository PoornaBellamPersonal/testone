package com.ebix.cms.poc.data;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface CmsBatchRepository extends JpaRepository<CmsBatchEntity, String> {
    long countByCycleIdAndStageKeyAndStatus(String cycleId, String stageKey, BatchStatus status);
    List<CmsBatchEntity> findByCycleIdOrderByStageKeyAscBatchNoAsc(String cycleId);
    List<CmsBatchEntity> findByCycleIdAndStageKeyOrderByBatchNo(String cycleId, String stageKey);
}
