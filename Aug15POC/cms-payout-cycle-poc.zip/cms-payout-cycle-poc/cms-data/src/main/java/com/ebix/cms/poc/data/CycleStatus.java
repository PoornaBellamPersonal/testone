package com.ebix.cms.poc.data;

public enum CycleStatus {
    STARTING, RUNNING, COMPLETED, FAILED
}
