package com.ebix.cms.poc.data;

public enum StageStatus {
    PENDING, RUNNING, COMPLETED, FAILED
}
