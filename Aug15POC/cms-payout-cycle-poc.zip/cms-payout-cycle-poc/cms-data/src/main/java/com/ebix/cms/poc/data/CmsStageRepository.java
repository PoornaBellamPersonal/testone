package com.ebix.cms.poc.data;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface CmsStageRepository extends JpaRepository<CmsStageEntity, Long> {
    Optional<CmsStageEntity> findByCycleIdAndStageKey(String cycleId, String stageKey);
    List<CmsStageEntity> findByCycleIdOrderById(String cycleId);
}
