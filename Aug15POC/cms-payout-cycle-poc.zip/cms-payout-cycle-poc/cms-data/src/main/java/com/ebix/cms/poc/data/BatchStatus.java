package com.ebix.cms.poc.data;

public enum BatchStatus {
    PENDING, PROCESSING, COMPLETED, FAILED
}
