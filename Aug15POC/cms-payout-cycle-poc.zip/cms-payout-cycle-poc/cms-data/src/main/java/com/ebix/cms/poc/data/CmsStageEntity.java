package com.ebix.cms.poc.data;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "CMS_STAGE",
       uniqueConstraints = @UniqueConstraint(name = "UK_CMS_STAGE_CYCLE_STAGE", columnNames = {"CYCLE_ID","STAGE_KEY"}))
public class CmsStageEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "STAGE_ID")
    private Long id;

    @Column(name = "CYCLE_ID", nullable = false, length = 64)
    private String cycleId;

    @Column(name = "STAGE_KEY", nullable = false, length = 40)
    private String stageKey;

    @Column(name = "RULE_SET_KEY", nullable = false, length = 60)
    private String ruleSetKey;

    @Enumerated(EnumType.STRING)
    @Column(name = "STATUS", nullable = false, length = 20)
    private StageStatus status;

    @Column(name = "TOTAL_BATCHES")
    private int totalBatches;

    @Column(name = "COMPLETED_BATCHES")
    private int completedBatches;

    @Column(name = "FAILED_BATCHES")
    private int failedBatches;

    @Column(name = "STARTED_AT")
    private Instant startedAt;

    @Column(name = "COMPLETED_AT")
    private Instant completedAt;

    public Long getId() { return id; }
    public String getCycleId() { return cycleId; }
    public void setCycleId(String cycleId) { this.cycleId = cycleId; }
    public String getStageKey() { return stageKey; }
    public void setStageKey(String stageKey) { this.stageKey = stageKey; }
    public String getRuleSetKey() { return ruleSetKey; }
    public void setRuleSetKey(String ruleSetKey) { this.ruleSetKey = ruleSetKey; }
    public StageStatus getStatus() { return status; }
    public void setStatus(StageStatus status) { this.status = status; }
    public int getTotalBatches() { return totalBatches; }
    public void setTotalBatches(int totalBatches) { this.totalBatches = totalBatches; }
    public int getCompletedBatches() { return completedBatches; }
    public void setCompletedBatches(int completedBatches) { this.completedBatches = completedBatches; }
    public int getFailedBatches() { return failedBatches; }
    public void setFailedBatches(int failedBatches) { this.failedBatches = failedBatches; }
    public Instant getStartedAt() { return startedAt; }
    public void setStartedAt(Instant startedAt) { this.startedAt = startedAt; }
    public Instant getCompletedAt() { return completedAt; }
    public void setCompletedAt(Instant completedAt) { this.completedAt = completedAt; }
}
