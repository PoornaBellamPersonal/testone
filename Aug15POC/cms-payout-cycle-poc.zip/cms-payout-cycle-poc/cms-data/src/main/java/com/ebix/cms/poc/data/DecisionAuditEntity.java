package com.ebix.cms.poc.data;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "CMS_DECISION_AUDIT",
       indexes = {
           @Index(name = "IX_AUDIT_TX", columnList = "TRANSACTION_ID"),
           @Index(name = "IX_AUDIT_CYCLE", columnList = "CYCLE_ID")
       })
public class DecisionAuditEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "AUDIT_ID")
    private Long id;

    @Column(name = "CYCLE_ID", nullable = false, length = 64)
    private String cycleId;

    @Column(name = "STAGE_KEY", nullable = false, length = 40)
    private String stageKey;

    @Column(name = "BATCH_ID", nullable = false, length = 80)
    private String batchId;

    @Column(name = "TRANSACTION_ID", nullable = false)
    private Long transactionId;

    @Column(name = "RULE_SET_KEY", nullable = false, length = 60)
    private String ruleSetKey;

    @Column(name = "RULE_ENGINE_NODE", length = 60)
    private String ruleEngineNode;

    @Column(name = "MATCHED_RULE", length = 100)
    private String matchedRule;

    @Column(name = "SUCCESS")
    private boolean success;

    @Column(name = "ERROR_MESSAGE", length = 1000)
    private String errorMessage;

    @Lob
    @Column(name = "OUTCOME_JSON")
    private String outcomeJson;

    @Column(name = "DURATION_MICROS")
    private Long durationMicros;

    @Column(name = "EVALUATED_AT")
    private Instant evaluatedAt;

    public Long getId() { return id; }
    public String getCycleId() { return cycleId; }
    public void setCycleId(String cycleId) { this.cycleId = cycleId; }
    public String getStageKey() { return stageKey; }
    public void setStageKey(String stageKey) { this.stageKey = stageKey; }
    public String getBatchId() { return batchId; }
    public void setBatchId(String batchId) { this.batchId = batchId; }
    public Long getTransactionId() { return transactionId; }
    public void setTransactionId(Long transactionId) { this.transactionId = transactionId; }
    public String getRuleSetKey() { return ruleSetKey; }
    public void setRuleSetKey(String ruleSetKey) { this.ruleSetKey = ruleSetKey; }
    public String getRuleEngineNode() { return ruleEngineNode; }
    public void setRuleEngineNode(String ruleEngineNode) { this.ruleEngineNode = ruleEngineNode; }
    public String getMatchedRule() { return matchedRule; }
    public void setMatchedRule(String matchedRule) { this.matchedRule = matchedRule; }
    public boolean isSuccess() { return success; }
    public void setSuccess(boolean success) { this.success = success; }
    public String getErrorMessage() { return errorMessage; }
    public void setErrorMessage(String errorMessage) { this.errorMessage = errorMessage; }
    public String getOutcomeJson() { return outcomeJson; }
    public void setOutcomeJson(String outcomeJson) { this.outcomeJson = outcomeJson; }
    public Long getDurationMicros() { return durationMicros; }
    public void setDurationMicros(Long durationMicros) { this.durationMicros = durationMicros; }
    public Instant getEvaluatedAt() { return evaluatedAt; }
    public void setEvaluatedAt(Instant evaluatedAt) { this.evaluatedAt = evaluatedAt; }
}
