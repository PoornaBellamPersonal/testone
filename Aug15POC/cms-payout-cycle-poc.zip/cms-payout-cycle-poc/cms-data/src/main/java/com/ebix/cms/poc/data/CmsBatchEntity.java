package com.ebix.cms.poc.data;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "CMS_BATCH",
       indexes = {
           @Index(name = "IX_CMS_BATCH_CYCLE_STAGE", columnList = "CYCLE_ID,STAGE_KEY"),
           @Index(name = "IX_CMS_BATCH_STATUS", columnList = "STATUS")
       })
public class CmsBatchEntity {
    @Id
    @Column(name = "BATCH_ID", length = 80)
    private String id;

    @Column(name = "CYCLE_ID", nullable = false, length = 64)
    private String cycleId;

    @Column(name = "STAGE_KEY", nullable = false, length = 40)
    private String stageKey;

    @Column(name = "RULE_SET_KEY", nullable = false, length = 60)
    private String ruleSetKey;

    @Column(name = "BATCH_NO", nullable = false)
    private int batchNo;

    @Enumerated(EnumType.STRING)
    @Column(name = "STATUS", nullable = false, length = 20)
    private BatchStatus status;

    @Column(name = "TRANSACTION_COUNT", nullable = false)
    private int transactionCount;

    @Column(name = "WORKER_ID", length = 60)
    private String workerId;

    @Column(name = "RULE_ENGINE_NODE", length = 60)
    private String ruleEngineNode;

    @Column(name = "ATTEMPTS")
    private int attempts;

    @Column(name = "QUEUE_WAIT_MS")
    private Long queueWaitMs;

    @Column(name = "DB_READ_MS")
    private Long dbReadMs;

    @Column(name = "RULE_CALL_MS")
    private Long ruleCallMs;

    @Column(name = "RULE_ENGINE_MS")
    private Long ruleEngineMs;

    @Column(name = "DB_WRITE_MS")
    private Long dbWriteMs;

    @Column(name = "DURATION_MS")
    private Long durationMs;

    @Column(name = "ERROR_MESSAGE", length = 1000)
    private String errorMessage;

    @Column(name = "CREATED_AT")
    private Instant createdAt;

    @Column(name = "STARTED_AT")
    private Instant startedAt;

    @Column(name = "COMPLETED_AT")
    private Instant completedAt;

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getCycleId() { return cycleId; }
    public void setCycleId(String cycleId) { this.cycleId = cycleId; }
    public String getStageKey() { return stageKey; }
    public void setStageKey(String stageKey) { this.stageKey = stageKey; }
    public String getRuleSetKey() { return ruleSetKey; }
    public void setRuleSetKey(String ruleSetKey) { this.ruleSetKey = ruleSetKey; }
    public int getBatchNo() { return batchNo; }
    public void setBatchNo(int batchNo) { this.batchNo = batchNo; }
    public BatchStatus getStatus() { return status; }
    public void setStatus(BatchStatus status) { this.status = status; }
    public int getTransactionCount() { return transactionCount; }
    public void setTransactionCount(int transactionCount) { this.transactionCount = transactionCount; }
    public String getWorkerId() { return workerId; }
    public void setWorkerId(String workerId) { this.workerId = workerId; }
    public String getRuleEngineNode() { return ruleEngineNode; }
    public void setRuleEngineNode(String ruleEngineNode) { this.ruleEngineNode = ruleEngineNode; }
    public int getAttempts() { return attempts; }
    public void setAttempts(int attempts) { this.attempts = attempts; }
    public Long getQueueWaitMs() { return queueWaitMs; }
    public void setQueueWaitMs(Long queueWaitMs) { this.queueWaitMs = queueWaitMs; }
    public Long getDbReadMs() { return dbReadMs; }
    public void setDbReadMs(Long dbReadMs) { this.dbReadMs = dbReadMs; }
    public Long getRuleCallMs() { return ruleCallMs; }
    public void setRuleCallMs(Long ruleCallMs) { this.ruleCallMs = ruleCallMs; }
    public Long getRuleEngineMs() { return ruleEngineMs; }
    public void setRuleEngineMs(Long ruleEngineMs) { this.ruleEngineMs = ruleEngineMs; }
    public Long getDbWriteMs() { return dbWriteMs; }
    public void setDbWriteMs(Long dbWriteMs) { this.dbWriteMs = dbWriteMs; }
    public Long getDurationMs() { return durationMs; }
    public void setDurationMs(Long durationMs) { this.durationMs = durationMs; }
    public String getErrorMessage() { return errorMessage; }
    public void setErrorMessage(String errorMessage) { this.errorMessage = errorMessage; }
    public Instant getCreatedAt() { return createdAt; }
    public void setCreatedAt(Instant createdAt) { this.createdAt = createdAt; }
    public Instant getStartedAt() { return startedAt; }
    public void setStartedAt(Instant startedAt) { this.startedAt = startedAt; }
    public Instant getCompletedAt() { return completedAt; }
    public void setCompletedAt(Instant completedAt) { this.completedAt = completedAt; }
}
