package com.ebix.cms.poc.data;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CmsTransactionRepository extends JpaRepository<CmsTransactionEntity, Long> {
}
