package com.ebix.cms.poc.data;

import jakarta.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(name = "CMS_TRANSACTION")
public class CmsTransactionEntity {
    @Id
    @Column(name = "TRANSACTION_ID")
    private Long id;

    @Column(name = "REGION", length = 20)
    private String region;

    @Column(name = "PRODUCT", length = 30)
    private String product;

    @Column(name = "AGENT_LEVEL", length = 20)
    private String agentLevel;

    @Column(name = "AMOUNT", precision = 18, scale = 2)
    private BigDecimal amount;

    @Column(name = "RESIDENCY_STATE", length = 10)
    private String residencyState;

    @Column(name = "CHANNEL_TYPE", length = 30)
    private String channelType;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getRegion() { return region; }
    public void setRegion(String region) { this.region = region; }
    public String getProduct() { return product; }
    public void setProduct(String product) { this.product = product; }
    public String getAgentLevel() { return agentLevel; }
    public void setAgentLevel(String agentLevel) { this.agentLevel = agentLevel; }
    public BigDecimal getAmount() { return amount; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }
    public String getResidencyState() { return residencyState; }
    public void setResidencyState(String residencyState) { this.residencyState = residencyState; }
    public String getChannelType() { return channelType; }
    public void setChannelType(String channelType) { this.channelType = channelType; }
}
