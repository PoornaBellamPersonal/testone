package com.ebix.cms.poc.infra;

import org.apache.activemq.artemis.core.config.Configuration;
import org.apache.activemq.artemis.core.config.impl.ConfigurationImpl;
import org.apache.activemq.artemis.core.server.embedded.EmbeddedActiveMQ;
import org.h2.tools.Server;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.nio.file.Files;
import java.nio.file.Path;

@SpringBootApplication
public class PocInfrastructureApplication implements CommandLineRunner, DisposableBean {

    @Value("${poc.h2.tcp-port:9093}")
    private int h2TcpPort;

    @Value("${poc.h2.web-port:8082}")
    private int h2WebPort;

    @Value("${poc.h2.base-dir:./data}")
    private String h2BaseDir;

    @Value("${poc.artemis.port:61616}")
    private int artemisPort;

    private Server h2TcpServer;
    private Server h2WebServer;
    private EmbeddedActiveMQ broker;

    public static void main(String[] args) {
        SpringApplication.run(PocInfrastructureApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        Files.createDirectories(Path.of(h2BaseDir));

        h2TcpServer = Server.createTcpServer(
                "-tcp",
                "-tcpPort", String.valueOf(h2TcpPort),
                "-tcpAllowOthers",
                "-ifNotExists",
                "-baseDir", h2BaseDir).start();

        h2WebServer = Server.createWebServer(
                "-web",
                "-webPort", String.valueOf(h2WebPort),
                "-webAllowOthers").start();

        Configuration configuration = new ConfigurationImpl()
                .setName("CMS-POC-ARTEMIS")
                .setPersistenceEnabled(false)
                .setSecurityEnabled(false)
                .addAcceptorConfiguration("tcp", "tcp://0.0.0.0:" + artemisPort);

        broker = new EmbeddedActiveMQ();
        broker.setConfiguration(configuration);
        broker.start();

        System.out.println();
        System.out.println("==========================================================");
        System.out.println(" CMS POC infrastructure is UP");
        System.out.println(" H2 TCP      : tcp://localhost:" + h2TcpPort);
        System.out.println(" H2 Console  : http://localhost:" + h2WebPort);
        System.out.println(" ActiveMQ    : tcp://localhost:" + artemisPort);
        System.out.println(" H2 base dir : " + Path.of(h2BaseDir).toAbsolutePath());
        System.out.println("==========================================================");
        System.out.println();
    }

    @Override
    public void destroy() throws Exception {
        if (broker != null) {
            broker.stop();
        }
        if (h2WebServer != null) {
            h2WebServer.stop();
        }
        if (h2TcpServer != null) {
            h2TcpServer.stop();
        }
    }
}
