package com.ebix.cms.poc.ruleengine;

import com.ebix.cms.poc.contracts.*;
import jakarta.annotation.PostConstruct;
import org.camunda.bpm.dmn.engine.*;
import org.camunda.bpm.engine.variable.Variables;
import org.camunda.bpm.engine.variable.VariableMap;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import java.io.InputStream;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class DmnRuleEngineService {

    private final DmnEngine dmnEngine =
            DmnEngineConfiguration.createDefaultDmnEngineConfiguration().buildEngine();

    private final Map<String, DmnDecision> decisions = new ConcurrentHashMap<>();

    private final Map<String, RuleSetInfo> catalog = new LinkedHashMap<>();

    @Value("${rule-engine.node-id:RE-01}")
    private String nodeId;

    @Value("${rule-engine.simulated-latency-ms:0}")
    private long simulatedLatencyMs;

    @PostConstruct
    public void initialize() {
        register("COMMISSION_RULES", "Commission Rules",
                "Determines commission percentage for the sales event.",
                "1.0", "dmn/commission.dmn", "commissionDecision");

        register("TAX_RULES", "Tax Rules",
                "Determines the tax percentage for the transaction.",
                "1.0", "dmn/tax.dmn", "taxDecision");

        register("WITHHOLDING_RULES", "Withholding Rules",
                "Determines the withholding percentage.",
                "1.0", "dmn/withholding.dmn", "withholdingDecision");
    }

    private void register(String key, String name, String description, String version,
                          String resourcePath, String decisionKey) {
        try (InputStream in = new ClassPathResource(resourcePath).getInputStream()) {
            decisions.put(key, dmnEngine.parseDecision(decisionKey, in));
            catalog.put(key, new RuleSetInfo(key, name, description, version));
        } catch (Exception ex) {
            throw new IllegalStateException("Unable to load DMN " + key, ex);
        }
    }

    public List<RuleSetInfo> catalog() {
        return List.copyOf(catalog.values());
    }

    public RuleEvaluationResponse evaluate(RuleEvaluationRequest request) {
        DmnDecision decision = decisions.get(request.ruleSetKey());
        if (decision == null) {
            throw new IllegalArgumentException("Unknown rule set: " + request.ruleSetKey());
        }

        long batchStart = System.nanoTime();
        List<RuleEvaluationResult> results = new ArrayList<>(request.items().size());

        for (RuleEvaluationItem item : request.items()) {
            long started = System.nanoTime();
            try {
                VariableMap variables = Variables.createVariables();
                item.inputs().forEach(variables::putValue);

                DmnDecisionTableResult tableResult =
                        dmnEngine.evaluateDecisionTable(decision, variables);

                Map<String, Object> outcome = new LinkedHashMap<>();
                if (!tableResult.isEmpty()) {
                    outcome.putAll(tableResult.get(0).getEntryMap());
                }

                String matchedRule = Objects.toString(outcome.get("matchedRule"), "NO_MATCH");

                if (simulatedLatencyMs > 0) {
                    Thread.sleep(simulatedLatencyMs);
                }

                results.add(new RuleEvaluationResult(
                        item.transactionId(),
                        true,
                        matchedRule,
                        outcome,
                        null,
                        (System.nanoTime() - started) / 1_000));
            } catch (Exception ex) {
                results.add(new RuleEvaluationResult(
                        item.transactionId(),
                        false,
                        null,
                        Map.of(),
                        ex.getMessage(),
                        (System.nanoTime() - started) / 1_000));
            }
        }

        return new RuleEvaluationResponse(
                nodeId,
                request.ruleSetKey(),
                results.size(),
                (System.nanoTime() - batchStart) / 1_000_000,
                results);
    }

    public String nodeId() {
        return nodeId;
    }
}
