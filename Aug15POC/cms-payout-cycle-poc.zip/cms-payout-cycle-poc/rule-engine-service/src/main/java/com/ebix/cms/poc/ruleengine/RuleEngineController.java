package com.ebix.cms.poc.ruleengine;

import com.ebix.cms.poc.contracts.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1")
public class RuleEngineController {

    private final DmnRuleEngineService service;

    @Value("${server.port:8091}")
    private int port;

    public RuleEngineController(DmnRuleEngineService service) {
        this.service = service;
    }

    @GetMapping("/node")
    public RuntimeNodeStatus node() {
        return new RuntimeNodeStatus(
                service.nodeId(),
                "RULE_ENGINE",
                "UP",
                "http://localhost:" + port,
                "Camunda DMN engine; no CMS database access");
    }

    @GetMapping("/rule-sets")
    public List<RuleSetInfo> ruleSets() {
        return service.catalog();
    }

    @PostMapping("/rule-sets/{ruleSetKey}/evaluate-batch")
    public RuleEvaluationResponse evaluate(
            @PathVariable String ruleSetKey,
            @RequestBody RuleEvaluationRequest request) {

        RuleEvaluationRequest normalized = new RuleEvaluationRequest(
                request.cycleId(),
                request.batchId(),
                ruleSetKey,
                request.items());

        return service.evaluate(normalized);
    }
}
