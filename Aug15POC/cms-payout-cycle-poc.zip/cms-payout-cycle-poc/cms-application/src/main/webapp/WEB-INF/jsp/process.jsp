<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ include file="fragments/header.jsp" %>

<div class="d-flex justify-content-between mb-4">
    <div>
        <div class="small text-secondary">Process Visualizer</div>
        <h1 class="h3 mb-1">${cycle.cycleKey}</h1>
        <p class="text-secondary mb-0">POC stage view. The integrated CMS demo can link this action to the existing Camunda Process Visualizer.</p>
    </div>
    <a class="btn btn-outline-secondary" href="${pageContext.request.contextPath}/cycles/${cycle.id}">Back to Cycle</a>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body p-4">
        <div class="process-flow">
            <div class="process-step completed"><span>Start</span></div>
            <div class="process-arrow">→</div>
            <c:forEach items="${stages}" var="stage">
                <div class="process-step ${stage.status eq 'COMPLETED' ? 'completed' : (stage.status eq 'FAILED' ? 'failed' : 'running')}">
                    <div class="fw-semibold">${stage.stageKey}</div>
                    <div class="small">${stage.completedBatches}/${stage.totalBatches} batches</div>
                    <div class="small">${stage.status}</div>
                </div>
                <div class="process-arrow">→</div>
            </c:forEach>
            <div class="process-step ${cycle.status eq 'COMPLETED' ? 'completed' : (cycle.status eq 'FAILED' ? 'failed' : 'pending')}">
                <span>Statements / Complete</span>
            </div>
        </div>
        <hr class="my-4">
        <div class="small text-secondary">
            Each rule stage uses a Java <strong>Workload Partitioner</strong> to create/publish JMS batches and a Java
            <strong>Workload Supervisor</strong> to enforce the stage barrier. Tax does not start until every Commission batch is complete.
        </div>
    </div>
</div>

<%@ include file="fragments/footer.jsp" %>
