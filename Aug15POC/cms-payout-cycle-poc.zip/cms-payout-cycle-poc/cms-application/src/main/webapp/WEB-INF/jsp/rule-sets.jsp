<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ include file="fragments/header.jsp" %>

<div class="mb-4">
    <h1 class="h3 mb-1">Named Rule Sets</h1>
    <p class="text-secondary mb-0">The BPMN invokes rule-set keys; rule-engine nodes host the same decision definitions.</p>
</div>

<div class="card border-0 shadow-sm">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead><tr><th>Rule Set</th><th>Key</th><th>Version</th><th>Description</th><th>POC Stage</th></tr></thead>
            <tbody>
            <c:forEach items="${ruleSets}" var="ruleSet">
                <tr>
                    <td class="fw-semibold">${ruleSet.name}</td>
                    <td><code>${ruleSet.key}</code></td>
                    <td>${ruleSet.version}</td>
                    <td>${ruleSet.description}</td>
                    <td>
                        <c:choose>
                            <c:when test="${ruleSet.key eq 'COMMISSION_RULES'}">Commission</c:when>
                            <c:when test="${ruleSet.key eq 'TAX_RULES'}">Tax</c:when>
                            <c:when test="${ruleSet.key eq 'WITHHOLDING_RULES'}">Withholding</c:when>
                            <c:otherwise>-</c:otherwise>
                        </c:choose>
                    </td>
                </tr>
            </c:forEach>
            </tbody>
        </table>
    </div>
</div>

<div class="alert alert-info mt-4">
    This payout-cycle POC focuses on orchestration, batching and scaling. The richer rule-management functionality from the earlier Rule Management POC can be integrated into this screen later; the runtime API is already based on stable named rule-set keys.
</div>

<%@ include file="fragments/footer.jsp" %>
