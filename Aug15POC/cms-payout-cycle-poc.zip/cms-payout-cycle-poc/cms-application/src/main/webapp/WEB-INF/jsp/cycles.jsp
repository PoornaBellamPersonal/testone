<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ include file="fragments/header.jsp" %>

<div class="row g-4">
    <div class="col-xl-4">
        <div class="card border-0 shadow-sm sticky-xl-top" style="top:1rem">
            <div class="card-header bg-white py-3"><strong>Start Payout Cycle</strong></div>
            <div class="card-body">
                <form method="post" action="${pageContext.request.contextPath}/cycles/start">
                    <input type="hidden" name="${_csrf.parameterName}" value="${_csrf.token}">
                    <div class="mb-3">
                        <label class="form-label">Cycle period</label>
                        <input class="form-control" type="month" name="periodLabel" value="${defaultPeriod}" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Transactions</label>
                        <input class="form-control" type="number" name="transactionCount" min="1" max="50000" value="5000" required>
                        <div class="form-text">Functional demo: 5,000. Performance run: 50,000.</div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Batch size</label>
                        <input class="form-control" type="number" name="batchSize" min="1" value="1000" required>
                        <div class="form-text">Use 1,000 with 5K to visibly distribute five batches. Use 5,000 for larger runs.</div>
                    </div>
                    <div class="alert alert-light border small">
                        Stages run sequentially: <strong>Commission → Tax → Withholding → Statements</strong>.
                        Each rule stage waits for all of its batches before the next stage begins.
                    </div>
                    <button class="btn btn-primary w-100" type="submit">GO - Start Cycle</button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-xl-8">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div>
                <h1 class="h3 mb-1">Payout Cycles</h1>
                <p class="text-secondary mb-0">Cycle history and current process state.</p>
            </div>
        </div>

        <div class="card border-0 shadow-sm">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead><tr><th>Cycle</th><th>Transactions</th><th>Batch</th><th>Status</th><th>Stage</th><th>Duration</th><th></th></tr></thead>
                    <tbody>
                    <c:forEach items="${cycles}" var="cycle">
                        <tr>
                            <td><div class="fw-semibold">${cycle.cycleKey}</div><div class="small text-secondary">${cycle.periodLabel}</div></td>
                            <td>${cycle.transactionCount}</td>
                            <td>${cycle.batchSize}</td>
                            <td><span class="badge text-bg-secondary">${cycle.status}</span></td>
                            <td>${cycle.currentStage}</td>
                            <td><c:choose><c:when test="${not empty cycle.totalDurationMs}">${cycle.totalDurationMs} ms</c:when><c:otherwise>-</c:otherwise></c:choose></td>
                            <td><a class="btn btn-sm btn-outline-primary" href="${pageContext.request.contextPath}/cycles/${cycle.id}">Details</a></td>
                        </tr>
                    </c:forEach>
                    <c:if test="${empty cycles}">
                        <tr><td colspan="7" class="text-center text-secondary py-5">No payout cycles yet.</td></tr>
                    </c:if>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<%@ include file="fragments/footer.jsp" %>
