<%@ page contentType="text/html;charset=UTF-8" %>
<%@ include file="fragments/header.jsp" %>

<div class="mb-4">
    <h1 class="h3 mb-1">POC Architecture</h1>
    <p class="text-secondary mb-0">Production-like logical separation collapsed onto one laptop.</p>
</div>

<div class="card border-0 shadow-sm mb-4">
    <div class="card-body p-4">
        <div class="architecture-grid">
            <div class="arch-box"><strong>CMS :8080</strong><span>JSP + Bootstrap<br>Embedded Camunda 7<br>Partitioner / Supervisor .java</span></div>
            <div class="arch-arrow">→</div>
            <div class="arch-box"><strong>ActiveMQ :61616</strong><span>JMS batch queue<br>IDs only in messages</span></div>
            <div class="arch-arrow">→</div>
            <div class="arch-stack">
                <div class="arch-box"><strong>WORKER-01 :8085</strong><span>DB read → REST → DB write</span></div>
                <div class="arch-box"><strong>WORKER-02 :8086</strong><span>Competing JMS consumer</span></div>
            </div>
            <div class="arch-arrow">→</div>
            <div class="arch-stack">
                <div class="arch-box"><strong>RE-01 :8091</strong><span>Camunda DMN<br>No CMS DB access</span></div>
                <div class="arch-box"><strong>RE-02 :8092</strong><span>Same rule sets</span></div>
            </div>
        </div>
    </div>
</div>

<div class="row g-4">
    <div class="col-lg-6">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-header bg-white py-3"><strong>Standalone Technical POC</strong></div>
            <div class="card-body">
                <ul class="mb-0">
                    <li>Spring Boot launchers for development speed.</li>
                    <li>JSP + Bootstrap UI.</li>
                    <li>File-backed H2 exposed through local TCP for multiple JVMs.</li>
                    <li>Synthetic deterministic transaction data.</li>
                    <li>Two worker JVMs and two rule-engine JVMs on localhost.</li>
                </ul>
            </div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-header bg-white py-3"><strong>Integrated CMS Demo</strong></div>
            <div class="card-body">
                <ul class="mb-0">
                    <li>Existing Spring MVC CMS remains the host application.</li>
                    <li>Existing CMS JSP shell and authentication are reused.</li>
                    <li>Oracle replaces the H2 datasource/data provider.</li>
                    <li>Selective realistic CMS sales-event data is used.</li>
                    <li>Worker/rule-engine roles can move to separate machines.</li>
                </ul>
            </div>
        </div>
    </div>
</div>

<%@ include file="fragments/footer.jsp" %>
