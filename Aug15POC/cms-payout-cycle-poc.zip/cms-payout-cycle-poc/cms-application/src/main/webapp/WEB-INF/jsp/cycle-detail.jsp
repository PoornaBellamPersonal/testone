<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ include file="fragments/header.jsp" %>

<div class="d-flex flex-wrap justify-content-between gap-2 align-items-start mb-4">
    <div>
        <div class="small text-secondary">Payout Cycle</div>
        <h1 class="h3 mb-1">${cycle.cycleKey}</h1>
        <div class="text-secondary">${cycle.transactionCount} transactions · batch size ${cycle.batchSize} · process ${cycle.processInstanceId}</div>
    </div>
    <div class="d-flex gap-2">
        <a class="btn btn-outline-primary" href="${pageContext.request.contextPath}/cycles/${cycle.id}/process">View Process</a>
        <a class="btn btn-outline-secondary" href="${pageContext.request.contextPath}/performance?cycleId=${cycle.id}">Performance</a>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-sm-6 col-lg-3"><div class="metric-card"><div class="metric-label">Status</div><div class="metric-value metric-small">${cycle.status}</div></div></div>
    <div class="col-sm-6 col-lg-3"><div class="metric-card"><div class="metric-label">Current Stage</div><div class="metric-value metric-small">${cycle.currentStage}</div></div></div>
    <div class="col-sm-6 col-lg-3"><div class="metric-card"><div class="metric-label">Transactions</div><div class="metric-value">${cycle.transactionCount}</div></div></div>
    <div class="col-sm-6 col-lg-3"><div class="metric-card"><div class="metric-label">Duration</div><div class="metric-value metric-small"><c:choose><c:when test="${not empty cycle.totalDurationMs}">${cycle.totalDurationMs} ms</c:when><c:otherwise>Running</c:otherwise></c:choose></div></div></div>
</div>

<div class="card border-0 shadow-sm mb-4">
    <div class="card-header bg-white py-3"><strong>Stage Progress</strong></div>
    <div class="card-body">
        <c:forEach items="${stages}" var="stage">
            <div class="mb-4">
                <div class="d-flex justify-content-between">
                    <div><strong>${stage.stageKey}</strong> <span class="text-secondary small">${stage.ruleSetKey}</span></div>
                    <div class="small">${stage.completedBatches}/${stage.totalBatches} complete · ${stage.failedBatches} failed · ${stage.status}</div>
                </div>
                <c:set var="pct" value="${stage.totalBatches > 0 ? (stage.completedBatches * 100 / stage.totalBatches) : 0}"/>
                <div class="progress mt-2" role="progressbar">
                    <div class="progress-bar" style="width:${pct}%">${pct}%</div>
                </div>
            </div>
        </c:forEach>
        <c:if test="${empty stages}">
            <div class="text-secondary">The process is initializing.</div>
        </c:if>
    </div>
</div>

<div class="card border-0 shadow-sm mb-4">
    <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
        <strong>Batch Execution</strong>
        <input id="batchFilter" class="form-control form-control-sm table-filter" placeholder="Filter batches...">
    </div>
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0" id="batchTable">
            <thead><tr><th>Stage</th><th>Batch</th><th>Status</th><th>Records</th><th>Worker</th><th>Rule Engine</th><th>Duration</th></tr></thead>
            <tbody>
            <c:forEach items="${batches}" var="batch">
                <tr>
                    <td>${batch.stageKey}</td>
                    <td>${batch.batchNo}</td>
                    <td>${batch.status}</td>
                    <td>${batch.transactionCount}</td>
                    <td><c:out value="${batch.workerId}" default="-"/></td>
                    <td><c:out value="${batch.ruleEngineNode}" default="-"/></td>
                    <td><c:choose><c:when test="${not empty batch.durationMs}">${batch.durationMs} ms</c:when><c:otherwise>-</c:otherwise></c:choose></td>
                </tr>
            </c:forEach>
            </tbody>
        </table>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-header bg-white py-3"><strong>Transaction Journey</strong></div>
    <div class="card-body">
        <form class="row g-2 mb-3" method="get">
            <div class="col-sm-6 col-md-4">
                <input class="form-control" type="number" name="transactionId" value="${transactionId}" placeholder="Transaction ID, e.g. 1">
            </div>
            <div class="col-auto"><button class="btn btn-outline-primary" type="submit">Show Journey</button></div>
        </form>

        <c:if test="${not empty transactionId and empty journey}">
            <div class="alert alert-light border">No decision audit exists yet for transaction ${transactionId} in this cycle.</div>
        </c:if>

        <div class="row g-3">
            <c:forEach items="${journey}" var="audit">
                <div class="col-lg-4">
                    <div class="border rounded-3 p-3 h-100 bg-white">
                        <div class="small text-secondary">${audit.stageKey}</div>
                        <div class="fw-semibold">${audit.ruleSetKey}</div>
                        <div class="mt-2"><span class="badge text-bg-success">${audit.matchedRule}</span></div>
                        <div class="small mt-2">Node: ${audit.ruleEngineNode}</div>
                        <code class="small d-block mt-2 text-break">${audit.outcomeJson}</code>
                    </div>
                </div>
            </c:forEach>
        </div>
    </div>
</div>

<c:if test="${cycle.status eq 'RUNNING' or cycle.status eq 'STARTING'}">
<script>
    window.setTimeout(function () { window.location.reload(); }, 3000);
</script>
</c:if>

<%@ include file="fragments/footer.jsp" %>
