<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ include file="fragments/header.jsp" %>

<div class="d-flex flex-wrap justify-content-between gap-3 mb-4">
    <div>
        <h1 class="h3 mb-1">Decision Audit</h1>
        <p class="text-secondary mb-0">Per-transaction decisions returned by the rule-engine nodes.</p>
    </div>
    <form class="d-flex gap-2" method="get">
        <input class="form-control" type="number" name="transactionId" value="${transactionId}" placeholder="Transaction ID">
        <button class="btn btn-outline-primary" type="submit">Search</button>
        <a class="btn btn-outline-secondary" href="${pageContext.request.contextPath}/audit">Clear</a>
    </form>
</div>

<div class="card border-0 shadow-sm">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead><tr><th>Transaction</th><th>Cycle</th><th>Stage</th><th>Rule Set</th><th>Result</th><th>Matched Rule</th><th>Node</th><th>Outcome / Error</th></tr></thead>
            <tbody>
            <c:forEach items="${audits}" var="audit">
                <tr>
                    <td>${audit.transactionId}</td>
                    <td class="small">${audit.cycleId}</td>
                    <td>${audit.stageKey}</td>
                    <td><code>${audit.ruleSetKey}</code></td>
                    <td><c:choose><c:when test="${audit.success}"><span class="badge text-bg-success">SUCCESS</span></c:when><c:otherwise><span class="badge text-bg-danger">FAILED</span></c:otherwise></c:choose></td>
                    <td><c:out value="${audit.matchedRule}" default="-"/></td>
                    <td>${audit.ruleEngineNode}</td>
                    <td>
                        <c:choose>
                            <c:when test="${audit.success}"><code class="small text-break">${audit.outcomeJson}</code></c:when>
                            <c:otherwise><span class="small text-danger">${audit.errorMessage}</span></c:otherwise>
                        </c:choose>
                    </td>
                </tr>
            </c:forEach>
            <c:if test="${empty audits}">
                <tr><td colspan="8" class="text-center text-secondary py-5">No audit records found.</td></tr>
            </c:if>
            </tbody>
        </table>
    </div>
</div>

<%@ include file="fragments/footer.jsp" %>
