<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ include file="fragments/header.jsp" %>

<div class="d-flex justify-content-between align-items-start mb-4">
    <div>
        <h1 class="h3 mb-1">Dashboard</h1>
        <p class="text-secondary mb-0">Standalone technical POC for end-to-end payout cycle processing.</p>
    </div>
    <a class="btn btn-primary" href="${pageContext.request.contextPath}/cycles">Start Payout Cycle</a>
</div>

<div class="row g-3 mb-4">
    <div class="col-sm-6 col-xl-3"><div class="metric-card"><div class="metric-label">Sample Transactions</div><div class="metric-value">${transactionCount}</div></div></div>
    <div class="col-sm-6 col-xl-3"><div class="metric-card"><div class="metric-label">Cycles</div><div class="metric-value">${cycleCount}</div></div></div>
    <div class="col-sm-6 col-xl-3"><div class="metric-card"><div class="metric-label">Running</div><div class="metric-value">${runningCount}</div></div></div>
    <div class="col-sm-6 col-xl-3"><div class="metric-card"><div class="metric-label">Completed</div><div class="metric-value">${completedCount}</div></div></div>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-header bg-white py-3 d-flex justify-content-between">
        <strong>Recent Payout Cycles</strong>
        <a href="${pageContext.request.contextPath}/cycles" class="small">View all</a>
    </div>
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead><tr><th>Cycle</th><th>Period</th><th>Transactions</th><th>Status</th><th>Current Stage</th><th></th></tr></thead>
            <tbody>
            <c:forEach items="${recentCycles}" var="cycle">
                <tr>
                    <td class="fw-semibold">${cycle.cycleKey}</td>
                    <td>${cycle.periodLabel}</td>
                    <td>${cycle.transactionCount}</td>
                    <td><span class="badge text-bg-secondary">${cycle.status}</span></td>
                    <td>${cycle.currentStage}</td>
                    <td><a class="btn btn-sm btn-outline-primary" href="${pageContext.request.contextPath}/cycles/${cycle.id}">Open</a></td>
                </tr>
            </c:forEach>
            <c:if test="${empty recentCycles}">
                <tr><td colspan="6" class="text-center text-secondary py-5">No cycles yet. Start the first POC run.</td></tr>
            </c:if>
            </tbody>
        </table>
    </div>
</div>

<%@ include file="fragments/footer.jsp" %>
