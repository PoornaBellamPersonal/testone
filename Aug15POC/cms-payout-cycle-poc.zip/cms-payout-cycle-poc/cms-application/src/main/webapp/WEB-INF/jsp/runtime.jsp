<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ include file="fragments/header.jsp" %>

<div class="mb-4">
    <h1 class="h3 mb-1">Runtime Nodes</h1>
    <p class="text-secondary mb-0">Independent local processes used to demonstrate production-style logical separation on one machine.</p>
</div>

<div class="card border-0 shadow-sm">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead><tr><th>Node</th><th>Type</th><th>Status</th><th>Address</th><th>Details</th></tr></thead>
            <tbody>
            <c:forEach items="${nodes}" var="node">
                <tr>
                    <td class="fw-semibold">${node.nodeId}</td>
                    <td>${node.nodeType}</td>
                    <td>
                        <c:choose>
                            <c:when test="${node.status eq 'UP'}"><span class="badge text-bg-success">UP</span></c:when>
                            <c:otherwise><span class="badge text-bg-danger">${node.status}</span></c:otherwise>
                        </c:choose>
                    </td>
                    <td><code>${node.address}</code></td>
                    <td class="small text-secondary">${node.details}</td>
                </tr>
            </c:forEach>
            </tbody>
        </table>
    </div>
</div>

<div class="alert alert-light border mt-4 mb-0">
    For the POC, WORKER-01/02 and RE-01/02 are separate JVMs on localhost. In production, the same roles can be moved to independent VMs/containers without changing the business process contract.
</div>

<%@ include file="fragments/footer.jsp" %>
