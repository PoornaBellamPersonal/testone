<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ include file="fragments/header.jsp" %>

<div class="d-flex flex-wrap justify-content-between gap-3 mb-4">
    <div>
        <h1 class="h3 mb-1">Performance</h1>
        <p class="text-secondary mb-0">End-to-end cycle timing and rule-engine workload distribution.</p>
    </div>
    <form method="get">
        <select class="form-select" name="cycleId" onchange="this.form.submit()">
            <c:forEach items="${cycles}" var="cycle">
                <option value="${cycle.id}" ${selectedCycle.id eq cycle.id ? 'selected' : ''}>${cycle.cycleKey}</option>
            </c:forEach>
        </select>
    </form>
</div>

<c:if test="${not empty selectedCycle}">
    <div class="row g-3 mb-4">
        <div class="col-md-3"><div class="metric-card"><div class="metric-label">Transactions</div><div class="metric-value">${selectedCycle.transactionCount}</div></div></div>
        <div class="col-md-3"><div class="metric-card"><div class="metric-label">Batch Size</div><div class="metric-value">${selectedCycle.batchSize}</div></div></div>
        <div class="col-md-3"><div class="metric-card"><div class="metric-label">End-to-End</div><div class="metric-value metric-small"><c:out value="${selectedCycle.totalDurationMs}" default="-"/> ms</div></div></div>
        <div class="col-md-3"><div class="metric-card"><div class="metric-label">Status</div><div class="metric-value metric-small">${selectedCycle.status}</div></div></div>
    </div>

    <div class="card border-0 shadow-sm mb-4">
        <div class="card-header bg-white py-3"><strong>Rule Engine Distribution</strong></div>
        <div class="table-responsive">
            <table class="table align-middle mb-0">
                <thead><tr><th>Node</th><th>Batches</th><th>Transactions</th><th>Accumulated Batch Time</th></tr></thead>
                <tbody>
                <c:forEach items="${nodeMetrics}" var="metric">
                    <tr><td class="fw-semibold">${metric.node}</td><td>${metric.batches}</td><td>${metric.transactions}</td><td>${metric.durationMs} ms</td></tr>
                </c:forEach>
                <c:if test="${empty nodeMetrics}">
                    <tr><td colspan="4" class="text-center text-secondary py-4">No completed batches yet.</td></tr>
                </c:if>
                </tbody>
            </table>
        </div>
    </div>

    <div class="card border-0 shadow-sm">
        <div class="card-header bg-white py-3"><strong>Batch Timings</strong></div>
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead><tr><th>Stage</th><th>Batch</th><th>Records</th><th>Worker</th><th>RE Node</th><th>Queue</th><th>DB Read</th><th>REST</th><th>Engine</th><th>DB Write</th><th>Total</th></tr></thead>
                <tbody>
                <c:forEach items="${batches}" var="batch">
                    <tr>
                        <td>${batch.stageKey}</td>
                        <td>${batch.batchNo}</td>
                        <td>${batch.transactionCount}</td>
                        <td>${batch.workerId}</td>
                        <td>${batch.ruleEngineNode}</td>
                        <td><c:out value="${batch.queueWaitMs}" default="-"/> ms</td>
                        <td><c:out value="${batch.dbReadMs}" default="-"/> ms</td>
                        <td><c:out value="${batch.ruleCallMs}" default="-"/> ms</td>
                        <td><c:out value="${batch.ruleEngineMs}" default="-"/> ms</td>
                        <td><c:out value="${batch.dbWriteMs}" default="-"/> ms</td>
                        <td class="fw-semibold"><c:out value="${batch.durationMs}" default="-"/> ms</td>
                    </tr>
                </c:forEach>
                </tbody>
            </table>
        </div>
    </div>
</c:if>

<c:if test="${empty selectedCycle}">
    <div class="alert alert-light border">Run a payout cycle first.</div>
</c:if>

<%@ include file="fragments/footer.jsp" %>
