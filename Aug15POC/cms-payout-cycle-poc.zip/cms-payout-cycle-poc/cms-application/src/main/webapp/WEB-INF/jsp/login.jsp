<%@ page contentType="text/html;charset=UTF-8" %>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>CMS Payout POC - Login</title>
    <link href="${pageContext.request.contextPath}/webjars/bootstrap/5.3.8/css/bootstrap.min.css" rel="stylesheet">
    <link href="${pageContext.request.contextPath}/css/app.css" rel="stylesheet">
</head>
<body class="login-page">
<div class="container">
    <div class="row justify-content-center">
        <div class="col-sm-9 col-md-6 col-lg-4">
            <div class="card border-0 shadow-lg login-card">
                <div class="card-body p-4 p-md-5">
                    <div class="mb-4">
                        <div class="small text-uppercase text-secondary fw-semibold">CMS Technical POC</div>
                        <h2 class="h4 mt-1 mb-1">Payout Cycle</h2>
                        <p class="text-secondary mb-0">Sign in to start and monitor a sample cycle.</p>
                    </div>
                    <% if (request.getParameter("error") != null) { %>
                        <div class="alert alert-danger py-2">Invalid username or password.</div>
                    <% } %>
                    <% if (request.getParameter("logout") != null) { %>
                        <div class="alert alert-success py-2">Signed out.</div>
                    <% } %>
                    <form action="${pageContext.request.contextPath}/login" method="post">
                        <input type="hidden" name="${_csrf.parameterName}" value="${_csrf.token}">
                        <div class="mb-3">
                            <label class="form-label">Username</label>
                            <input class="form-control" name="username" value="admin" autocomplete="username">
                        </div>
                        <div class="mb-4">
                            <label class="form-label">Password</label>
                            <input class="form-control" type="password" name="password" value="admin" autocomplete="current-password">
                        </div>
                        <button class="btn btn-primary w-100" type="submit">Login</button>
                    </form>
                    <div class="small text-secondary mt-3">POC credentials: <strong>admin / admin</strong></div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
