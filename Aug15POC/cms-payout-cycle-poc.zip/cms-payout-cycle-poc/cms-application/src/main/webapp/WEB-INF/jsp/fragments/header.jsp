<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>CMS Payout Cycle POC</title>
    <link href="${pageContext.request.contextPath}/webjars/bootstrap/5.3.8/css/bootstrap.min.css" rel="stylesheet">
    <link href="${pageContext.request.contextPath}/css/app.css" rel="stylesheet">
</head>
<body class="bg-body-tertiary">
<nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm">
    <div class="container-fluid px-4">
        <a class="navbar-brand fw-semibold" href="${pageContext.request.contextPath}/dashboard">CMS Payout POC</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="mainNav">
            <ul class="navbar-nav me-auto">
                <li class="nav-item"><a class="nav-link" href="${pageContext.request.contextPath}/dashboard">Dashboard</a></li>
                <li class="nav-item"><a class="nav-link" href="${pageContext.request.contextPath}/cycles">Payout Cycles</a></li>
                <li class="nav-item"><a class="nav-link" href="${pageContext.request.contextPath}/rule-sets">Rule Sets</a></li>
                <li class="nav-item"><a class="nav-link" href="${pageContext.request.contextPath}/audit">Decision Audit</a></li>
                <li class="nav-item"><a class="nav-link" href="${pageContext.request.contextPath}/performance">Performance</a></li>
                <li class="nav-item"><a class="nav-link" href="${pageContext.request.contextPath}/runtime">Runtime Nodes</a></li>
                <li class="nav-item"><a class="nav-link" href="${pageContext.request.contextPath}/architecture">Architecture</a></li>
            </ul>
            <form action="${pageContext.request.contextPath}/logout" method="post" class="d-flex">
                <input type="hidden" name="${_csrf.parameterName}" value="${_csrf.token}">
                <button class="btn btn-outline-light btn-sm" type="submit">Logout</button>
            </form>
        </div>
    </div>
</nav>
<main class="container-fluid px-4 py-4">
<c:if test="${not empty success}">
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        ${success}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
</c:if>
<c:if test="${not empty error}">
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        ${error}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
</c:if>
