package com.ebix.cms.poc.cms.process;

import com.ebix.cms.poc.cms.service.CycleLifecycleService;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Component;

@Component
public class GenerateStatementsDelegate implements JavaDelegate {

    private final CycleLifecycleService lifecycleService;

    public GenerateStatementsDelegate(CycleLifecycleService lifecycleService) {
        this.lifecycleService = lifecycleService;
    }

    @Override
    public void execute(DelegateExecution execution) {
        lifecycleService.statementGeneration((String) execution.getVariable("cycleId"));
    }
}
