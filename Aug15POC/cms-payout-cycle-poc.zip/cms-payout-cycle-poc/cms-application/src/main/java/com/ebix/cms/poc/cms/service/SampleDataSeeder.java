package com.ebix.cms.poc.cms.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Component
public class SampleDataSeeder implements ApplicationRunner {

    private final JdbcTemplate jdbcTemplate;

    @Value("${poc.seed.transaction-count:50000}")
    private int targetCount;

    public SampleDataSeeder(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public void run(ApplicationArguments args) {
        Integer current = jdbcTemplate.queryForObject(
                "select count(*) from CMS_TRANSACTION", Integer.class);
        int existing = current == null ? 0 : current;

        if (existing >= targetCount) {
            System.out.println("Sample transactions already present: " + existing);
            return;
        }

        Long max = jdbcTemplate.queryForObject(
                "select coalesce(max(TRANSACTION_ID), 0) from CMS_TRANSACTION", Long.class);
        long start = (max == null ? 0 : max) + 1;

        String[] regions = {"APAC", "NA", "EMEA"};
        String[] products = {"LIFE", "ANNUITY", "HEALTH"};
        String[] levels = {"GOLD", "SILVER", "BRONZE"};
        String[] states = {"CA", "TX", "NY", "FL"};
        String[] channels = {"AGENCY", "DIRECT", "BROKER"};

        String sql = """
                insert into CMS_TRANSACTION
                (TRANSACTION_ID, REGION, PRODUCT, AGENT_LEVEL, AMOUNT, RESIDENCY_STATE, CHANNEL_TYPE)
                values (?, ?, ?, ?, ?, ?, ?)
                """;

        final int chunkSize = 1000;
        List<Object[]> batch = new ArrayList<>(chunkSize);

        for (long id = start; id <= targetCount; id++) {
            int n = (int) id;
            BigDecimal amount = BigDecimal.valueOf(5_000L + (n % 100) * 500L);
            batch.add(new Object[] {
                    id,
                    regions[n % regions.length],
                    products[n % products.length],
                    levels[n % levels.length],
                    amount,
                    states[n % states.length],
                    channels[n % channels.length]
            });

            if (batch.size() == chunkSize) {
                jdbcTemplate.batchUpdate(sql, batch);
                batch.clear();
            }
        }
        if (!batch.isEmpty()) {
            jdbcTemplate.batchUpdate(sql, batch);
        }

        System.out.println("Seeded sample CMS transactions up to: " + targetCount);
    }
}
