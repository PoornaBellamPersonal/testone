package com.ebix.cms.poc.cms.web;

import com.ebix.cms.poc.cms.service.CycleStartService;
import com.ebix.cms.poc.data.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.YearMonth;
import java.time.format.DateTimeFormatter;

@Controller
@RequestMapping("/cycles")
public class CycleController {

    private final CmsCycleRepository cycleRepository;
    private final CmsStageRepository stageRepository;
    private final CmsBatchRepository batchRepository;
    private final DecisionAuditRepository auditRepository;
    private final CycleStartService cycleStartService;

    public CycleController(
            CmsCycleRepository cycleRepository,
            CmsStageRepository stageRepository,
            CmsBatchRepository batchRepository,
            DecisionAuditRepository auditRepository,
            CycleStartService cycleStartService) {
        this.cycleRepository = cycleRepository;
        this.stageRepository = stageRepository;
        this.batchRepository = batchRepository;
        this.auditRepository = auditRepository;
        this.cycleStartService = cycleStartService;
    }

    @GetMapping
    public String cycles(Model model) {
        model.addAttribute("cycles", cycleRepository.findAllByOrderByStartedAtDesc());
        model.addAttribute("defaultPeriod", YearMonth.now().toString());
        return "cycles";
    }

    @PostMapping("/start")
    public String start(
            @RequestParam String periodLabel,
            @RequestParam(defaultValue = "5000") int transactionCount,
            @RequestParam(defaultValue = "1000") int batchSize,
            RedirectAttributes redirectAttributes) {
        try {
            String normalized = periodLabel == null || periodLabel.isBlank()
                    ? YearMonth.now().format(DateTimeFormatter.ofPattern("yyyy-MM"))
                    : periodLabel.trim();

            String cycleKey = "PAYOUT-" + normalized + "-" + System.currentTimeMillis();
            CmsCycleEntity cycle =
                    cycleStartService.start(cycleKey, normalized, transactionCount, batchSize);

            redirectAttributes.addFlashAttribute("success",
                    "Payout cycle started: " + cycle.getCycleKey());
            return "redirect:/cycles/" + cycle.getId();
        } catch (Exception ex) {
            redirectAttributes.addFlashAttribute("error", ex.getMessage());
            return "redirect:/cycles";
        }
    }

    @GetMapping("/{cycleId}")
    public String detail(
            @PathVariable String cycleId,
            @RequestParam(required = false) Long transactionId,
            Model model) {
        CmsCycleEntity cycle = cycleRepository.findById(cycleId).orElseThrow();
        model.addAttribute("cycle", cycle);
        model.addAttribute("stages", stageRepository.findByCycleIdOrderById(cycleId));
        model.addAttribute("batches", batchRepository.findByCycleIdOrderByStageKeyAscBatchNoAsc(cycleId));
        model.addAttribute("transactionId", transactionId);
        if (transactionId != null) {
            model.addAttribute("journey",
                    auditRepository.findByCycleIdAndTransactionIdOrderByEvaluatedAtAsc(
                            cycleId, transactionId));
        }
        return "cycle-detail";
    }

    @GetMapping("/{cycleId}/process")
    public String process(@PathVariable String cycleId, Model model) {
        CmsCycleEntity cycle = cycleRepository.findById(cycleId).orElseThrow();
        model.addAttribute("cycle", cycle);
        model.addAttribute("stages", stageRepository.findByCycleIdOrderById(cycleId));
        return "process";
    }
}
