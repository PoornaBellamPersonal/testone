package com.ebix.cms.poc.cms.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ArchitectureController {
    @GetMapping("/architecture")
    public String architecture() {
        return "architecture";
    }
}
