package com.ebix.cms.poc.cms.process;

import com.ebix.cms.poc.cms.service.StageSupervisionService;
import org.springframework.stereotype.Component;

@Component
public class CommissionWorkloadSupervisor extends AbstractWorkloadSupervisor {
    public CommissionWorkloadSupervisor(StageSupervisionService service) {
        super(service, "COMMISSION", "commission");
    }
}
