package com.ebix.cms.poc.cms.process;

import com.ebix.cms.poc.cms.service.StageSupervisionService;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

public abstract class AbstractWorkloadSupervisor implements JavaDelegate {

    private final StageSupervisionService supervisionService;
    private final String stageKey;
    private final String variablePrefix;

    protected AbstractWorkloadSupervisor(
            StageSupervisionService supervisionService,
            String stageKey,
            String variablePrefix) {
        this.supervisionService = supervisionService;
        this.stageKey = stageKey;
        this.variablePrefix = variablePrefix;
    }

    @Override
    public void execute(DelegateExecution execution) {
        String cycleId = (String) execution.getVariable("cycleId");
        StageSupervisionService.Outcome outcome =
                supervisionService.inspect(cycleId, stageKey);

        execution.setVariable(variablePrefix + "Complete",
                outcome == StageSupervisionService.Outcome.COMPLETE);
        execution.setVariable(variablePrefix + "Failed",
                outcome == StageSupervisionService.Outcome.FAILED);

        System.out.printf("[%s Supervisor] cycle=%s outcome=%s%n",
                stageKey, cycleId, outcome);
    }
}
