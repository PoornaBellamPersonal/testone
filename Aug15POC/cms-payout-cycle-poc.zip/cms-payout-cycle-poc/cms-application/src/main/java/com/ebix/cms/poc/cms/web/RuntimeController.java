package com.ebix.cms.poc.cms.web;

import com.ebix.cms.poc.cms.service.RuntimeStatusService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class RuntimeController {

    private final RuntimeStatusService runtimeStatusService;

    public RuntimeController(RuntimeStatusService runtimeStatusService) {
        this.runtimeStatusService = runtimeStatusService;
    }

    @GetMapping("/runtime")
    public String runtime(Model model) {
        model.addAttribute("nodes", runtimeStatusService.statuses());
        return "runtime";
    }
}
