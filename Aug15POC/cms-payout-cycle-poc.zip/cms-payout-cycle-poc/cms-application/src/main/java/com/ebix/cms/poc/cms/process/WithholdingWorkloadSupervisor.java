package com.ebix.cms.poc.cms.process;

import com.ebix.cms.poc.cms.service.StageSupervisionService;
import org.springframework.stereotype.Component;

@Component
public class WithholdingWorkloadSupervisor extends AbstractWorkloadSupervisor {
    public WithholdingWorkloadSupervisor(StageSupervisionService service) {
        super(service, "WITHHOLDING", "withholding");
    }
}
