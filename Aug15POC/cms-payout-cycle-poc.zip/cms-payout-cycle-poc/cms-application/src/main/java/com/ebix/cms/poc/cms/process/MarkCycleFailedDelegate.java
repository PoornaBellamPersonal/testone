package com.ebix.cms.poc.cms.process;

import com.ebix.cms.poc.cms.service.CycleLifecycleService;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Component;

@Component
public class MarkCycleFailedDelegate implements JavaDelegate {

    private final CycleLifecycleService lifecycleService;

    public MarkCycleFailedDelegate(CycleLifecycleService lifecycleService) {
        this.lifecycleService = lifecycleService;
    }

    @Override
    public void execute(DelegateExecution execution) {
        lifecycleService.fail((String) execution.getVariable("cycleId"));
    }
}
