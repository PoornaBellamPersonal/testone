package com.ebix.cms.poc.cms.service;

import com.ebix.cms.poc.contracts.BatchCommand;
import com.ebix.cms.poc.data.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@Service
public class BatchPlanningService {

    private final CmsCycleRepository cycleRepository;
    private final CmsStageRepository stageRepository;
    private final CmsBatchRepository batchRepository;
    private final CmsBatchItemRepository batchItemRepository;
    private final TransactionIdProvider transactionIdProvider;

    public BatchPlanningService(
            CmsCycleRepository cycleRepository,
            CmsStageRepository stageRepository,
            CmsBatchRepository batchRepository,
            CmsBatchItemRepository batchItemRepository,
            TransactionIdProvider transactionIdProvider) {
        this.cycleRepository = cycleRepository;
        this.stageRepository = stageRepository;
        this.batchRepository = batchRepository;
        this.batchItemRepository = batchItemRepository;
        this.transactionIdProvider = transactionIdProvider;
    }

    @Transactional
    public List<BatchCommand> createStageBatches(
            String cycleId, String stageKey, String ruleSetKey) {

        CmsCycleEntity cycle = cycleRepository.findById(cycleId).orElseThrow();

        if (stageRepository.findByCycleIdAndStageKey(cycleId, stageKey).isPresent()) {
            return List.of();
        }

        List<Long> transactionIds =
                transactionIdProvider.findEligibleTransactionIds(cycle.getTransactionCount());

        if (transactionIds.size() < cycle.getTransactionCount()) {
            throw new IllegalStateException(
                    "Requested " + cycle.getTransactionCount()
                    + " transactions but only " + transactionIds.size() + " are available");
        }

        int batchSize = cycle.getBatchSize();
        int totalBatches = (transactionIds.size() + batchSize - 1) / batchSize;

        CmsStageEntity stage = new CmsStageEntity();
        stage.setCycleId(cycleId);
        stage.setStageKey(stageKey);
        stage.setRuleSetKey(ruleSetKey);
        stage.setStatus(StageStatus.RUNNING);
        stage.setTotalBatches(totalBatches);
        stage.setCompletedBatches(0);
        stage.setFailedBatches(0);
        stage.setStartedAt(Instant.now());
        stageRepository.save(stage);

        cycle.setCurrentStage(stageKey);
        cycle.setStatus(CycleStatus.RUNNING);
        cycleRepository.save(cycle);

        List<BatchCommand> commands = new ArrayList<>(totalBatches);

        for (int offset = 0, batchNo = 1;
             offset < transactionIds.size();
             offset += batchSize, batchNo++) {

            List<Long> ids = new ArrayList<>(
                    transactionIds.subList(offset, Math.min(offset + batchSize, transactionIds.size())));

            String batchId = cycleId + "-" + stageKey + "-" + String.format("%04d", batchNo);

            CmsBatchEntity batch = new CmsBatchEntity();
            batch.setId(batchId);
            batch.setCycleId(cycleId);
            batch.setStageKey(stageKey);
            batch.setRuleSetKey(ruleSetKey);
            batch.setBatchNo(batchNo);
            batch.setStatus(BatchStatus.PENDING);
            batch.setTransactionCount(ids.size());
            batch.setAttempts(0);
            batch.setCreatedAt(Instant.now());
            batchRepository.save(batch);

            List<CmsBatchItemEntity> items = new ArrayList<>(ids.size());
            for (Long transactionId : ids) {
                CmsBatchItemEntity item = new CmsBatchItemEntity();
                item.setBatchId(batchId);
                item.setTransactionId(transactionId);
                items.add(item);
            }
            batchItemRepository.saveAll(items);

            commands.add(new BatchCommand(
                    cycleId, stageKey, ruleSetKey, batchId, batchNo, ids));
        }

        return commands;
    }
}
