package com.ebix.cms.poc.cms.web;

import com.ebix.cms.poc.data.DecisionAuditRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AuditController {

    private final DecisionAuditRepository auditRepository;

    public AuditController(DecisionAuditRepository auditRepository) {
        this.auditRepository = auditRepository;
    }

    @GetMapping("/audit")
    public String audit(@RequestParam(required = false) Long transactionId, Model model) {
        model.addAttribute("transactionId", transactionId);
        model.addAttribute("audits", transactionId == null
                ? auditRepository.findTop100ByOrderByEvaluatedAtDesc()
                : auditRepository.findByTransactionIdOrderByEvaluatedAtAsc(transactionId));
        return "audit";
    }
}
