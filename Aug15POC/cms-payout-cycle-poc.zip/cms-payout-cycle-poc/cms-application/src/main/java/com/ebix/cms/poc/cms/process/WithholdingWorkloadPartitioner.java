package com.ebix.cms.poc.cms.process;

import com.ebix.cms.poc.cms.service.BatchPlanningService;
import com.ebix.cms.poc.cms.service.BatchPublisher;
import org.springframework.stereotype.Component;

@Component
public class WithholdingWorkloadPartitioner extends AbstractWorkloadPartitioner {
    public WithholdingWorkloadPartitioner(
            BatchPlanningService planningService,
            BatchPublisher publisher) {
        super(planningService, publisher, "WITHHOLDING", "WITHHOLDING_RULES");
    }
}
