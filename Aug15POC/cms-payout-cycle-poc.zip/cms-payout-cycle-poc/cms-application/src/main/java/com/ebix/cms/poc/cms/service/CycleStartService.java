package com.ebix.cms.poc.cms.service;

import com.ebix.cms.poc.data.*;
import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.runtime.ProcessInstance;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Service
public class CycleStartService {

    private final CmsCycleRepository cycleRepository;
    private final RuntimeService runtimeService;

    public CycleStartService(CmsCycleRepository cycleRepository, RuntimeService runtimeService) {
        this.cycleRepository = cycleRepository;
        this.runtimeService = runtimeService;
    }

    public CmsCycleEntity start(
            String cycleKey, String periodLabel, int transactionCount, int batchSize) {

        if (transactionCount <= 0) {
            throw new IllegalArgumentException("Transaction count must be greater than zero");
        }
        if (batchSize <= 0) {
            throw new IllegalArgumentException("Batch size must be greater than zero");
        }

        CmsCycleEntity cycle = new CmsCycleEntity();
        cycle.setId(UUID.randomUUID().toString());
        cycle.setCycleKey(cycleKey);
        cycle.setPeriodLabel(periodLabel);
        cycle.setStatus(CycleStatus.STARTING);
        cycle.setCurrentStage("STARTING");
        cycle.setTransactionCount(transactionCount);
        cycle.setBatchSize(batchSize);
        cycle.setStartedAt(Instant.now());
        cycleRepository.save(cycle);

        Map<String, Object> variables = new HashMap<>();
        variables.put("cycleId", cycle.getId());
        variables.put("cycleKey", cycleKey);

        ProcessInstance instance = runtimeService.startProcessInstanceByKey(
                "cmsPayoutCycle", cycleKey, variables);

        cycle.setProcessInstanceId(instance.getProcessInstanceId());
        return cycleRepository.save(cycle);
    }
}
