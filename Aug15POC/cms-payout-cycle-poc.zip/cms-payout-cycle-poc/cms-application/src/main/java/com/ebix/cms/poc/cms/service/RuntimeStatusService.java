package com.ebix.cms.poc.cms.service;

import com.ebix.cms.poc.contracts.RuntimeNodeStatus;
import jakarta.jms.Connection;
import jakarta.jms.ConnectionFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Service
public class RuntimeStatusService {

    private final JdbcTemplate jdbcTemplate;
    private final ConnectionFactory connectionFactory;
    private final List<String> workerNodes;
    private final List<String> ruleEngineNodes;
    private final RestClient restClient;

    public RuntimeStatusService(
            JdbcTemplate jdbcTemplate,
            ConnectionFactory connectionFactory,
            @Value("${cms.worker.nodes:http://localhost:8085,http://localhost:8086}") String workerNodes,
            @Value("${cms.rule-engine.nodes:http://localhost:8091,http://localhost:8092}") String ruleEngineNodes) {
        this.jdbcTemplate = jdbcTemplate;
        this.connectionFactory = connectionFactory;
        this.workerNodes = split(workerNodes);
        this.ruleEngineNodes = split(ruleEngineNodes);

        SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
        factory.setConnectTimeout(800);
        factory.setReadTimeout(800);
        this.restClient = RestClient.builder().requestFactory(factory).build();
    }

    public List<RuntimeNodeStatus> statuses() {
        List<RuntimeNodeStatus> result = new ArrayList<>();
        result.add(new RuntimeNodeStatus("CMS", "CMS_APPLICATION", "UP",
                "http://localhost:8080", "Spring Boot POC + JSP + embedded Camunda 7"));

        result.add(checkDatabase());
        result.add(checkBroker());

        workerNodes.forEach(url -> result.add(checkHttpNode(url, "BATCH_WORKER")));
        ruleEngineNodes.forEach(url -> result.add(checkHttpNode(url, "RULE_ENGINE")));
        return result;
    }

    private RuntimeNodeStatus checkDatabase() {
        try {
            Integer value = jdbcTemplate.queryForObject("select 1", Integer.class);
            return new RuntimeNodeStatus("H2-TCP", "DATABASE",
                    value != null && value == 1 ? "UP" : "UNKNOWN",
                    "jdbc:h2:tcp://localhost:9093/./cms-poc",
                    "File-backed H2 used only by the POC");
        } catch (Exception ex) {
            return new RuntimeNodeStatus("H2-TCP", "DATABASE", "DOWN",
                    "jdbc:h2:tcp://localhost:9093/./cms-poc", ex.getMessage());
        }
    }

    private RuntimeNodeStatus checkBroker() {
        Connection connection = null;
        try {
            connection = connectionFactory.createConnection();
            connection.start();
            return new RuntimeNodeStatus("ActiveMQ", "JMS_BROKER", "UP",
                    "tcp://localhost:61616", "cms.payout.batch.queue");
        } catch (Exception ex) {
            return new RuntimeNodeStatus("ActiveMQ", "JMS_BROKER", "DOWN",
                    "tcp://localhost:61616", ex.getMessage());
        } finally {
            if (connection != null) {
                try { connection.close(); } catch (Exception ignored) { }
            }
        }
    }

    private RuntimeNodeStatus checkHttpNode(String url, String expectedType) {
        try {
            RuntimeNodeStatus node = restClient.get()
                    .uri(url + "/api/v1/node")
                    .retrieve()
                    .body(RuntimeNodeStatus.class);
            if (node == null) {
                return down(url, expectedType, "Empty status response");
            }
            return node;
        } catch (Exception ex) {
            return down(url, expectedType, ex.getClass().getSimpleName());
        }
    }

    private RuntimeNodeStatus down(String url, String type, String details) {
        return new RuntimeNodeStatus(url, type, "DOWN", url, details);
    }

    private List<String> split(String value) {
        return Arrays.stream(value.split(","))
                .map(String::trim)
                .filter(s -> !s.isBlank())
                .toList();
    }
}
