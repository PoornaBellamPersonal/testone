package com.ebix.cms.poc.cms.process;

import com.ebix.cms.poc.cms.service.BatchPlanningService;
import com.ebix.cms.poc.cms.service.BatchPublisher;
import org.springframework.stereotype.Component;

@Component
public class TaxWorkloadPartitioner extends AbstractWorkloadPartitioner {
    public TaxWorkloadPartitioner(
            BatchPlanningService planningService,
            BatchPublisher publisher) {
        super(planningService, publisher, "TAX", "TAX_RULES");
    }
}
