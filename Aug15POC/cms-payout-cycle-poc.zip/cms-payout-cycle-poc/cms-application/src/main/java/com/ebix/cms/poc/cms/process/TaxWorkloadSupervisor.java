package com.ebix.cms.poc.cms.process;

import com.ebix.cms.poc.cms.service.StageSupervisionService;
import org.springframework.stereotype.Component;

@Component
public class TaxWorkloadSupervisor extends AbstractWorkloadSupervisor {
    public TaxWorkloadSupervisor(StageSupervisionService service) {
        super(service, "TAX", "tax");
    }
}
