package com.ebix.cms.poc.cms.service;

import com.ebix.cms.poc.contracts.BatchCommand;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BatchPublisher {

    private final JmsTemplate jmsTemplate;

    @Value("${cms.jms.batch-queue:cms.payout.batch.queue}")
    private String batchQueue;

    public BatchPublisher(JmsTemplate jmsTemplate) {
        this.jmsTemplate = jmsTemplate;
    }

    public void publish(List<BatchCommand> commands) {
        for (BatchCommand command : commands) {
            jmsTemplate.convertAndSend(batchQueue, command);
        }
    }
}
