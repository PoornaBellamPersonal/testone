package com.ebix.cms.poc.cms.service;

import java.util.List;

/**
 * POC extension point. The H2 implementation selects sample transaction IDs.
 * In the integrated CMS demo this interface can be backed by existing Oracle
 * sales-event/transaction tables without changing the BPMN partitioner code.
 */
public interface TransactionIdProvider {
    List<Long> findEligibleTransactionIds(int maximum);
}
