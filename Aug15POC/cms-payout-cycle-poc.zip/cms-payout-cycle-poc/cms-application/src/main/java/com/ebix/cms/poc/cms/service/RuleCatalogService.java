package com.ebix.cms.poc.cms.service;

import com.ebix.cms.poc.contracts.RuleSetInfo;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

import java.util.Arrays;
import java.util.List;

@Service
public class RuleCatalogService {

    private final List<String> nodes;
    private final RestClient restClient;

    public RuleCatalogService(
            @Value("${cms.rule-engine.nodes:http://localhost:8091,http://localhost:8092}") String nodeList) {
        this.nodes = Arrays.stream(nodeList.split(","))
                .map(String::trim)
                .filter(s -> !s.isBlank())
                .toList();

        SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
        factory.setConnectTimeout(800);
        factory.setReadTimeout(800);
        this.restClient = RestClient.builder().requestFactory(factory).build();
    }

    public List<RuleSetInfo> load() {
        for (String node : nodes) {
            try {
                List<RuleSetInfo> ruleSets = restClient.get()
                        .uri(node + "/api/v1/rule-sets")
                        .retrieve()
                        .body(new ParameterizedTypeReference<List<RuleSetInfo>>() {});
                if (ruleSets != null) {
                    return ruleSets;
                }
            } catch (Exception ignored) {
                // Try the next local rule-engine node.
            }
        }

        return List.of(
                new RuleSetInfo("COMMISSION_RULES", "Commission Rules",
                        "Rule engine unavailable; catalog fallback", "1.0"),
                new RuleSetInfo("TAX_RULES", "Tax Rules",
                        "Rule engine unavailable; catalog fallback", "1.0"),
                new RuleSetInfo("WITHHOLDING_RULES", "Withholding Rules",
                        "Rule engine unavailable; catalog fallback", "1.0"));
    }
}
