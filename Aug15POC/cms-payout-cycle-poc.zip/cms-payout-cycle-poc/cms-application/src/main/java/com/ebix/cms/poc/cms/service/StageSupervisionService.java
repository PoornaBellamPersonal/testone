package com.ebix.cms.poc.cms.service;

import com.ebix.cms.poc.data.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;

@Service
public class StageSupervisionService {

    public enum Outcome { WAIT, COMPLETE, FAILED }

    private final CmsStageRepository stageRepository;
    private final CmsBatchRepository batchRepository;

    public StageSupervisionService(
            CmsStageRepository stageRepository,
            CmsBatchRepository batchRepository) {
        this.stageRepository = stageRepository;
        this.batchRepository = batchRepository;
    }

    @Transactional
    public Outcome inspect(String cycleId, String stageKey) {
        CmsStageEntity stage = stageRepository
                .findByCycleIdAndStageKey(cycleId, stageKey)
                .orElseThrow();

        int complete = Math.toIntExact(batchRepository.countByCycleIdAndStageKeyAndStatus(
                cycleId, stageKey, BatchStatus.COMPLETED));
        int failed = Math.toIntExact(batchRepository.countByCycleIdAndStageKeyAndStatus(
                cycleId, stageKey, BatchStatus.FAILED));

        stage.setCompletedBatches(complete);
        stage.setFailedBatches(failed);

        if (failed > 0) {
            stage.setStatus(StageStatus.FAILED);
            stage.setCompletedAt(Instant.now());
            stageRepository.save(stage);
            return Outcome.FAILED;
        }

        if (stage.getTotalBatches() > 0 && complete == stage.getTotalBatches()) {
            stage.setStatus(StageStatus.COMPLETED);
            stage.setCompletedAt(Instant.now());
            stageRepository.save(stage);
            return Outcome.COMPLETE;
        }

        stage.setStatus(StageStatus.RUNNING);
        stageRepository.save(stage);
        return Outcome.WAIT;
    }
}
