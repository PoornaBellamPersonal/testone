package com.ebix.cms.poc.cms.service;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class H2TransactionIdProvider implements TransactionIdProvider {

    private final JdbcTemplate jdbcTemplate;

    public H2TransactionIdProvider(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public List<Long> findEligibleTransactionIds(int maximum) {
        return jdbcTemplate.query(
                "select TRANSACTION_ID from CMS_TRANSACTION order by TRANSACTION_ID limit ?",
                (rs, rowNum) -> rs.getLong(1),
                maximum);
    }
}
