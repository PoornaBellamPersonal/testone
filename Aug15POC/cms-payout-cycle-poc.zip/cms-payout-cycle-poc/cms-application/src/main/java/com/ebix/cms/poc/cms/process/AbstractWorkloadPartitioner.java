package com.ebix.cms.poc.cms.process;

import com.ebix.cms.poc.contracts.BatchCommand;
import com.ebix.cms.poc.cms.service.BatchPlanningService;
import com.ebix.cms.poc.cms.service.BatchPublisher;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import java.util.List;

public abstract class AbstractWorkloadPartitioner implements JavaDelegate {

    private final BatchPlanningService planningService;
    private final BatchPublisher publisher;
    private final String stageKey;
    private final String ruleSetKey;

    protected AbstractWorkloadPartitioner(
            BatchPlanningService planningService,
            BatchPublisher publisher,
            String stageKey,
            String ruleSetKey) {
        this.planningService = planningService;
        this.publisher = publisher;
        this.stageKey = stageKey;
        this.ruleSetKey = ruleSetKey;
    }

    @Override
    public void execute(DelegateExecution execution) {
        String cycleId = (String) execution.getVariable("cycleId");
        List<BatchCommand> commands =
                planningService.createStageBatches(cycleId, stageKey, ruleSetKey);

        /*
         * The partitioner executes inside a Camunda/Spring transaction. Publishing
         * after commit prevents a fast JMS worker from reading CMS_BATCH rows before
         * those rows are visible in H2/Oracle. The production design can replace
         * this POC after-commit publisher with a transactional outbox.
         */
        if (!commands.isEmpty() && TransactionSynchronizationManager.isSynchronizationActive()) {
            TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
                @Override
                public void afterCommit() {
                    publisher.publish(commands);
                }
            });
        } else if (!commands.isEmpty()) {
            publisher.publish(commands);
        }

        execution.setVariable("currentStage", stageKey);
        execution.setVariable(stageKey.toLowerCase() + "BatchCount", commands.size());

        System.out.printf("[%s Partitioner] cycle=%s batches=%d%n",
                stageKey, cycleId, commands.size());
    }
}
