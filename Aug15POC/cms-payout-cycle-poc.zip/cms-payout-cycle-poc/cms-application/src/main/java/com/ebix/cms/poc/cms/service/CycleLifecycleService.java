package com.ebix.cms.poc.cms.service;

import com.ebix.cms.poc.data.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Duration;
import java.time.Instant;

@Service
public class CycleLifecycleService {

    private final CmsCycleRepository cycleRepository;

    public CycleLifecycleService(CmsCycleRepository cycleRepository) {
        this.cycleRepository = cycleRepository;
    }

    @Transactional
    public void initialize(String cycleId) {
        CmsCycleEntity cycle = cycleRepository.findById(cycleId).orElseThrow();
        cycle.setStatus(CycleStatus.RUNNING);
        cycle.setStartedAt(Instant.now());
        cycle.setCurrentStage("INITIALIZE");
        cycleRepository.save(cycle);
    }

    @Transactional
    public void statementGeneration(String cycleId) {
        CmsCycleEntity cycle = cycleRepository.findById(cycleId).orElseThrow();
        cycle.setCurrentStage("STATEMENT_GENERATION");
        cycleRepository.save(cycle);
    }

    @Transactional
    public void complete(String cycleId) {
        CmsCycleEntity cycle = cycleRepository.findById(cycleId).orElseThrow();
        Instant completed = Instant.now();
        cycle.setStatus(CycleStatus.COMPLETED);
        cycle.setCurrentStage("COMPLETED");
        cycle.setCompletedAt(completed);
        if (cycle.getStartedAt() != null) {
            cycle.setTotalDurationMs(Duration.between(cycle.getStartedAt(), completed).toMillis());
        }
        cycleRepository.save(cycle);
    }

    @Transactional
    public void fail(String cycleId) {
        CmsCycleEntity cycle = cycleRepository.findById(cycleId).orElseThrow();
        Instant completed = Instant.now();
        cycle.setStatus(CycleStatus.FAILED);
        cycle.setCurrentStage("FAILED");
        cycle.setCompletedAt(completed);
        if (cycle.getStartedAt() != null) {
            cycle.setTotalDurationMs(Duration.between(cycle.getStartedAt(), completed).toMillis());
        }
        cycleRepository.save(cycle);
    }
}
