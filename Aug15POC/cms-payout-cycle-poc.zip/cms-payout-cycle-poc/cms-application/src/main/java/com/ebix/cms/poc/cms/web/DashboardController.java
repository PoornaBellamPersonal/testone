package com.ebix.cms.poc.cms.web;

import com.ebix.cms.poc.data.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class DashboardController {

    private final CmsCycleRepository cycleRepository;
    private final CmsTransactionRepository transactionRepository;

    public DashboardController(
            CmsCycleRepository cycleRepository,
            CmsTransactionRepository transactionRepository) {
        this.cycleRepository = cycleRepository;
        this.transactionRepository = transactionRepository;
    }

    @GetMapping({"/", "/dashboard"})
    public String dashboard(Model model) {
        model.addAttribute("cycleCount", cycleRepository.count());
        model.addAttribute("runningCount", cycleRepository.countByStatus(CycleStatus.RUNNING));
        model.addAttribute("completedCount", cycleRepository.countByStatus(CycleStatus.COMPLETED));
        model.addAttribute("transactionCount", transactionRepository.count());
        model.addAttribute("recentCycles",
                cycleRepository.findAllByOrderByStartedAtDesc().stream().limit(5).toList());
        return "dashboard";
    }
}
