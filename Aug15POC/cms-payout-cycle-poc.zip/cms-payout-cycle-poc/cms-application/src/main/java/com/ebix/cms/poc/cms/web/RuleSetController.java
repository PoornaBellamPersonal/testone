package com.ebix.cms.poc.cms.web;

import com.ebix.cms.poc.cms.service.RuleCatalogService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class RuleSetController {

    private final RuleCatalogService catalogService;

    public RuleSetController(RuleCatalogService catalogService) {
        this.catalogService = catalogService;
    }

    @GetMapping("/rule-sets")
    public String ruleSets(Model model) {
        model.addAttribute("ruleSets", catalogService.load());
        return "rule-sets";
    }
}
