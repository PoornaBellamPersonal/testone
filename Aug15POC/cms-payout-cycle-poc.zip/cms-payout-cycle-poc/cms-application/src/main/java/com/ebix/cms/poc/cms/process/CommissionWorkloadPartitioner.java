package com.ebix.cms.poc.cms.process;

import com.ebix.cms.poc.cms.service.BatchPlanningService;
import com.ebix.cms.poc.cms.service.BatchPublisher;
import org.springframework.stereotype.Component;

@Component
public class CommissionWorkloadPartitioner extends AbstractWorkloadPartitioner {
    public CommissionWorkloadPartitioner(
            BatchPlanningService planningService,
            BatchPublisher publisher) {
        super(planningService, publisher, "COMMISSION", "COMMISSION_RULES");
    }
}
