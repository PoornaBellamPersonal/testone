package com.ebix.cms.poc.cms.web;

import com.ebix.cms.poc.data.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.*;
import java.util.stream.Collectors;

@Controller
public class PerformanceController {

    public static class NodeMetric {
        private final String node;
        private final long batches;
        private final long transactions;
        private final long durationMs;

        public NodeMetric(String node, long batches, long transactions, long durationMs) {
            this.node = node;
            this.batches = batches;
            this.transactions = transactions;
            this.durationMs = durationMs;
        }

        public String getNode() { return node; }
        public long getBatches() { return batches; }
        public long getTransactions() { return transactions; }
        public long getDurationMs() { return durationMs; }
    }

    private final CmsCycleRepository cycleRepository;
    private final CmsBatchRepository batchRepository;

    public PerformanceController(
            CmsCycleRepository cycleRepository,
            CmsBatchRepository batchRepository) {
        this.cycleRepository = cycleRepository;
        this.batchRepository = batchRepository;
    }

    @GetMapping("/performance")
    public String performance(@RequestParam(required = false) String cycleId, Model model) {
        List<CmsCycleEntity> cycles = cycleRepository.findAllByOrderByStartedAtDesc();
        model.addAttribute("cycles", cycles);

        if (cycleId == null && !cycles.isEmpty()) {
            cycleId = cycles.get(0).getId();
        }

        if (cycleId != null) {
            CmsCycleEntity cycle = cycleRepository.findById(cycleId).orElseThrow();
            List<CmsBatchEntity> batches = batchRepository.findByCycleIdOrderByStageKeyAscBatchNoAsc(cycleId);

            Map<String, List<CmsBatchEntity>> grouped = batches.stream()
                    .filter(b -> b.getRuleEngineNode() != null)
                    .collect(Collectors.groupingBy(CmsBatchEntity::getRuleEngineNode, LinkedHashMap::new, Collectors.toList()));

            List<NodeMetric> metrics = new ArrayList<>();
            grouped.forEach((node, rows) -> metrics.add(new NodeMetric(
                    node,
                    rows.size(),
                    rows.stream().mapToLong(CmsBatchEntity::getTransactionCount).sum(),
                    rows.stream().map(CmsBatchEntity::getDurationMs)
                            .filter(Objects::nonNull).mapToLong(Long::longValue).sum())));

            model.addAttribute("selectedCycle", cycle);
            model.addAttribute("batches", batches);
            model.addAttribute("nodeMetrics", metrics);
        }
        return "performance";
    }
}
