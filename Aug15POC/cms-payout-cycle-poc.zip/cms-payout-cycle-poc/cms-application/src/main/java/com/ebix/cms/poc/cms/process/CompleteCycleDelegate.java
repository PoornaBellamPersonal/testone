package com.ebix.cms.poc.cms.process;

import com.ebix.cms.poc.cms.service.CycleLifecycleService;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Component;

@Component
public class CompleteCycleDelegate implements JavaDelegate {

    private final CycleLifecycleService lifecycleService;

    public CompleteCycleDelegate(CycleLifecycleService lifecycleService) {
        this.lifecycleService = lifecycleService;
    }

    @Override
    public void execute(DelegateExecution execution) {
        lifecycleService.complete((String) execution.getVariable("cycleId"));
    }
}
