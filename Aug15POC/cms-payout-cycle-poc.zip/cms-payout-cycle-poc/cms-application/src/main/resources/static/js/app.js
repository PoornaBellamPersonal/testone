document.addEventListener("DOMContentLoaded", function () {
    const filter = document.getElementById("batchFilter");
    const table = document.getElementById("batchTable");
    if (filter && table) {
        filter.addEventListener("input", function () {
            const q = filter.value.toLowerCase();
            table.querySelectorAll("tbody tr").forEach(function (row) {
                row.style.display = row.innerText.toLowerCase().includes(q) ? "" : "none";
            });
        });
    }
});
